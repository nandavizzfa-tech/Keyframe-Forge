Put exported 3D models here:
  R6.glb
  R15.glb

These are NOT included yet — Blender wasn't available to generate them
automatically. Export them yourself from Blender:

  File > Export > glTF 2.0 (.glb/.gltf)
  Format: glTF Binary (.glb)
  Include: Selected Objects (select the rig + meshes first)

Save the result here as assets/R6.glb or assets/R15.glb.

The preview works fine with this folder empty — it just uses the built-in
box rig until real models are added. See js/model-loader.js for how
loading them in would work once they exist.
