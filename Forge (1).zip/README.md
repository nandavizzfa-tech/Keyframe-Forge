# Forge

## Structure

```
Forge/
├── index.html          <- Page shell: markup + <link>/<script> tags only
├── css/
│   └── style.css       <- All the styling (was inline <style> before)
├── js/
│   ├── main.js          <- Everything the app does: parsing, the keyframe
│   │                        densifier, UI wiring, and the box-rig preview
│   │                        (unchanged from before — just moved out of
│   │                        the HTML file)
│   └── model-loader.js  <- Scaffold for loading real R6.glb/R15.glb
│                            models later. NOT wired into main.js yet —
│                            see the comment block at the top of that file
│                            for why and what's needed to hook it up.
├── assets/
│   └── README.txt       <- Where R6.glb / R15.glb go once you export them
└── README.md            <- This file
```

## Running it

Any static file host works (this domain, GitHub Pages, Netlify, a plain
`python3 -m http.server` for local testing, etc.) — there's no build step
and no server-side code. Just upload the whole `Forge/` folder and point
the domain at `index.html`.

One thing to know: opening `index.html` directly from your filesystem
(double-clicking it, `file://...`) will work for looks/layout but the
browser may block loading `js/main.js` as a module in some browsers due to
local-file security rules. If anything looks blank, serve it over
`http://` instead (even `python3 -m http.server` in this folder is
enough) rather than opening the file directly.

## Everything still works exactly as before

This split didn't change any logic — `js/main.js` is the same code that
was inside the single HTML file's `<script>` tag, just moved. The box-rig
preview, keyframe parsing, and output generation all behave identically.

## Next step: real models instead of the box rig

`js/model-loader.js` can load a `.glb` file if one exists at
`assets/R6.glb` / `assets/R15.glb`, but it isn't connected to the
animation preview yet. Driving a real imported skeleton means matching
each Roblox part name (`Left Arm`, `UpperTorso`, etc.) to whatever
bone/node names your Blender export actually produces — which we can't
know until the file exists. Once you've exported one:

1. Drop it in `assets/` as `R6.glb` or `R15.glb`.
2. Load it once and run `ModelLoader.dumpNodeNames(model)` (see the
   function in `model-loader.js`) to print every bone/node name in your
   browser's console.
3. Fill in `BONE_NAME_MAP` in `model-loader.js` with the real names.
4. Wire `ModelLoader.load(...)` into `main.js`'s `rebuildPreviewRig()` to
   use the loaded model instead of the box rig when one is present.

Steps 3–4 are deliberately left undone rather than guessed — that's
exactly the kind of mismatch that caused most of the back-and-forth on the
box rig's rotation axes.
