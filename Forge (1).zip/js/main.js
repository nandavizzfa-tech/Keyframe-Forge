(() => {
const $ = id => document.getElementById(id);
const APP_VERSION = '1.1.0';

/* ---------- FLAGS (custom inline SVG) ---------- */
const FLAGS = {
  'en-US': (() => {
    let s = '<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/>';
    for (let i = 0; i < 7; i++) s += '<rect y="' + (i * 3.077).toFixed(3) + '" width="30" height="1.538" fill="#b22234"/>';
    s += '<rect width="12.5" height="10.77" fill="#3c3b6e"/>';
    for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++)
      s += '<circle cx="' + (2 + c * 2.8).toFixed(1) + '" cy="' + (1.9 + r * 2.3).toFixed(1) + '" r=".55" fill="#fff"/>';
    return s + '</svg>';
  })(),
  'en-GB': '<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#fff"/><rect x="12.5" width="5" height="20" fill="#ce1124"/><rect y="7.5" width="30" height="5" fill="#ce1124"/></svg>',
  'id': '<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="10" fill="#e70011"/><rect y="10" width="30" height="10" fill="#fff"/></svg>',
  'es': '<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#c60b1e"/><rect y="5" width="30" height="10" fill="#ffc400"/></svg>',
  'pt-BR': '<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="20" fill="#009b3a"/><polygon points="15,2 27,10 15,18 3,10" fill="#fedf00"/><circle cx="15" cy="10" r="4.2" fill="#002776"/><path d="M10.8 9.2Q15 7.6 19.2 11.2" stroke="#fff" stroke-width=".9" fill="none"/></svg>',
  'de': '<svg viewBox="0 0 30 20" preserveAspectRatio="none"><rect width="30" height="6.67" fill="#000"/><rect y="6.67" width="30" height="6.67" fill="#dd0000"/><rect y="13.33" width="30" height="6.67" fill="#ffce00"/></svg>'
};
const LANGS = [
  { code: 'en-US', label: 'English (US)', short: 'US' },
  { code: 'en-GB', label: 'English (England)', short: 'ENG' },
  { code: 'id', label: 'Bahasa Indonesia', short: 'ID' },
  { code: 'es', label: 'Español', short: 'ES' },
  { code: 'pt-BR', label: 'Português (Brasil)', short: 'BR' },
  { code: 'de', label: 'Deutsch', short: 'DE' }
];

/* ---------- EXPLORER ICONS (custom inline SVG) ---------- */
const I = p => '<svg viewBox="0 0 24 24" aria-hidden="true">' + p + '</svg>';
const SVC_ICONS = {
  ServerScriptService: I('<rect x="3" y="4" width="18" height="6.5" rx="1.6"/><rect x="3" y="13.5" width="18" height="6.5" rx="1.6"/><path d="M7 7.25h.01M7 16.75h.01M11 7.25h6M11 16.75h6"/>'),
  ServerStorage: I('<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/>'),
  ReplicatedStorage: I('<path d="M4 11a8 8 0 0 1 14-4.5L20 9M20 4.5V9h-4.5M20 13a8 8 0 0 1-14 4.5L4 15M4 19.5V15h4.5"/>'),
  Workspace: I('<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>'),
  ReplicatedFirst: I('<path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z"/>'),
  Lighting: I('<circle cx="12" cy="12" r="4"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>'),
  StarterPack: I('<path d="M8.5 7V5.5a3.5 3.5 0 0 1 7 0V7"/><rect x="5" y="7" width="14" height="14" rx="3.5"/><path d="M9 14h6"/>'),
  StarterGui: I('<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 8.5h18M8 21.5h8M12 18v3.5"/>'),
  StarterPlayer: I('<circle cx="12" cy="8" r="4"/><path d="M4.5 21c.5-4 3.6-6.5 7.5-6.5s7 2.5 7.5 6.5"/>')
};
const FOLDER_ICON = I('<path d="M3 7.5A2 2 0 0 1 5 5.5h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" fill="currentColor" fill-opacity=".22"/>');
const SEQ_ICON = I('<path d="M3 12h4M17 12h4"/><path d="M12 5l5 7-5 7-5-7z" style="fill:var(--acc);fill-opacity:.3;stroke:var(--acc)"/>');

/* ---------- TRANSLATIONS ---------- */
const T = {
'en-US': {
  tagline: 'Turn raw animation data into a ready-to-paste KeyframeSequence script.',
  tabData: 'Data', tabConfig: 'Config', tabOutput: 'Output',
  rawTitle: 'Raw data', rawPh: 'Paste your animation data here…',
  generate: 'Parse & generate', sample: 'Load sample', clear: 'Clear',
  destTitle: 'Destination', service: 'Service', folders: 'Folders inside the service, in order',
  addFolder: 'Add folder', noFolder: 'No folders. The sequence goes straight into the service.',
  folderPh: 'Folder name, e.g. Anim', removeFolder: 'Remove folder', pathPrev: 'Location preview',
  folderNote: 'Create these folders manually in Studio. The script only looks them up with FindFirstChild and never creates them.',
  optTitle: 'Options', seqName: 'Sequence name', seqNamePh: 'Taken from the data', priority: 'Priority', loop: 'Loop',
  outTitle: 'Output', outLabel: 'ServerScript · Luau', lines: '{n} lines',
  outPh: '-- Your script will appear here after parsing.', copy: 'Copy script', copied: 'Copied', goOutput: 'View output',
  settings: 'Settings', setupTitle: 'Interface settings', setupSub: 'Pick a theme and a language. You can change them any time.',
  theme: 'Theme', themeDark: 'Dark · Futuristic', themeLight: 'Light · Minimal',
  accentHint: 'Pick a mode and an accent color.',
  red: 'Red', blue: 'Blue', green: 'Green', orange: 'Orange', language: 'Language', done: 'Done',
  errEmpty: 'The raw data is empty. Paste it first.',
  errNoKf: 'No "[Keyframe N] t=…" lines could be read. Check that the format matches the animation dump.',
  errNum: 'Invalid number: {v}',
  warnBad: '{n} lines were not recognized and were skipped.',
  warnCount: 'The header says {a} keyframes, but {b} were read.',
  warnDur: 'The header duration ({a}s) differs from the last keyframe ({b}s).',
  warnEmpty: '{n} keyframes contain no poses.',
  chipName: 'Name', chipDur: 'Duration', chipKf: 'Keyframes', chipPose: 'Poses', chipLoop: 'Loop (data)', yes: 'Yes', no: 'No',
  madeBy: 'Made by',
  creditDesc: 'A website that converts raw animation data into a native KeyframeSequence, the raw form of a Roblox animation.',
  creditPrivacy: 'Everything runs in your browser. Your animation data is never uploaded.',
  creditFonts: 'Fonts: Orbitron and Share Tech Mono. Icons and flags: custom SVG.',
  creditDisclaimer: 'Not affiliated with, endorsed by, or sponsored by Roblox Corporation.'
},
'en-GB': {
  accentHint: 'Pick a mode and an accent colour.',
  warnBad: '{n} lines were not recognised and were skipped.'
},
'id': {
  tagline: 'Ubah data animasi mentah menjadi script KeyframeSequence siap tempel.',
  tabData: 'Data', tabConfig: 'Atur', tabOutput: 'Hasil',
  rawTitle: 'Data mentah', rawPh: 'Tempel data animasi di sini…',
  generate: 'Parse & buat', sample: 'Muat contoh', clear: 'Bersihkan',
  destTitle: 'Lokasi tujuan', service: 'Service', folders: 'Folder di dalam service, berurutan',
  addFolder: 'Tambah folder', noFolder: 'Tanpa folder. Sequence langsung masuk ke service.',
  folderPh: 'Nama folder, mis. Anim', removeFolder: 'Hapus folder', pathPrev: 'Pratinjau lokasi',
  folderNote: 'Buat folder ini secara manual di Studio. Script hanya mencarinya dengan FindFirstChild dan tidak pernah membuatnya.',
  optTitle: 'Opsi', seqName: 'Nama sequence', seqNamePh: 'Diambil dari data', priority: 'Priority', loop: 'Loop',
  outTitle: 'Hasil', outLabel: 'ServerScript · Luau', lines: '{n} baris',
  outPh: '-- Script akan muncul di sini setelah data diparse.', copy: 'Salin script', copied: 'Tersalin', goOutput: 'Lihat hasil',
  settings: 'Pengaturan', setupTitle: 'Pengaturan tampilan', setupSub: 'Pilih tema dan bahasa. Bisa diubah kapan saja.',
  theme: 'Tema', themeDark: 'Gelap · Futuristik', themeLight: 'Terang · Minimalis',
  accentHint: 'Pilih mode dan warna aksen.',
  red: 'Merah', blue: 'Biru', green: 'Hijau', orange: 'Oranye', language: 'Bahasa', done: 'Selesai',
  errEmpty: 'Data mentah masih kosong. Tempel dulu datanya.',
  errNoKf: 'Tidak ada baris "[Keyframe N] t=…" yang terbaca. Pastikan formatnya sama seperti dump animasi.',
  errNum: 'Angka tidak valid: {v}',
  warnBad: '{n} baris tidak dikenali dan dilewati.',
  warnCount: 'Header menyebut {a} keyframe, tetapi yang terbaca {b}.',
  warnDur: 'Durasi di header ({a}s) berbeda dengan keyframe terakhir ({b}s).',
  warnEmpty: '{n} keyframe tidak memiliki pose.',
  chipName: 'Nama', chipDur: 'Durasi', chipKf: 'Keyframe', chipPose: 'Pose', chipLoop: 'Loop (data)', yes: 'Ya', no: 'Tidak',
  madeBy: 'Dibuat oleh',
  creditDesc: 'Situs web untuk mengubah data mentah animasi menjadi KeyframeSequence asli, bentuk mentah dari animasi Roblox.',
  creditPrivacy: 'Semua proses berjalan di browser kamu. Data animasimu tidak pernah diunggah.',
  creditFonts: 'Font: Orbitron dan Share Tech Mono. Ikon dan bendera: SVG buatan sendiri.',
  creditDisclaimer: 'Tidak berafiliasi dengan, didukung oleh, atau disponsori oleh Roblox Corporation.'
},
'es': {
  tagline: 'Convierte datos de animación en bruto en un script KeyframeSequence listo para pegar.',
  tabData: 'Datos', tabConfig: 'Ajustes', tabOutput: 'Salida',
  rawTitle: 'Datos en bruto', rawPh: 'Pega aquí los datos de tu animación…',
  generate: 'Analizar y generar', sample: 'Cargar ejemplo', clear: 'Borrar',
  destTitle: 'Destino', service: 'Servicio', folders: 'Carpetas dentro del servicio, en orden',
  addFolder: 'Añadir carpeta', noFolder: 'Sin carpetas. La secuencia va directamente al servicio.',
  folderPh: 'Nombre de carpeta, p. ej. Anim', removeFolder: 'Quitar carpeta', pathPrev: 'Vista previa de la ubicación',
  folderNote: 'Crea estas carpetas manualmente en Studio. El script solo las busca con FindFirstChild y nunca las crea.',
  optTitle: 'Opciones', seqName: 'Nombre de la secuencia', seqNamePh: 'Tomado de los datos', priority: 'Prioridad', loop: 'Bucle',
  outTitle: 'Salida', outLabel: 'ServerScript · Luau', lines: '{n} líneas',
  outPh: '-- Tu script aparecerá aquí tras analizar los datos.', copy: 'Copiar script', copied: 'Copiado', goOutput: 'Ver salida',
  settings: 'Ajustes', setupTitle: 'Ajustes de interfaz', setupSub: 'Elige un tema y un idioma. Puedes cambiarlos cuando quieras.',
  theme: 'Tema', themeDark: 'Oscuro · Futurista', themeLight: 'Claro · Minimalista',
  accentHint: 'Elige un modo y un color de acento.',
  red: 'Rojo', blue: 'Azul', green: 'Verde', orange: 'Naranja', language: 'Idioma', done: 'Listo',
  errEmpty: 'Los datos en bruto están vacíos. Pégalos primero.',
  errNoKf: 'No se pudo leer ninguna línea "[Keyframe N] t=…". Comprueba que el formato coincida con el volcado de la animación.',
  errNum: 'Número no válido: {v}',
  warnBad: 'Se omitieron {n} líneas no reconocidas.',
  warnCount: 'El encabezado indica {a} keyframes, pero se leyeron {b}.',
  warnDur: 'La duración del encabezado ({a}s) difiere del último keyframe ({b}s).',
  warnEmpty: '{n} keyframes no contienen poses.',
  chipName: 'Nombre', chipDur: 'Duración', chipKf: 'Keyframes', chipPose: 'Poses', chipLoop: 'Bucle (datos)', yes: 'Sí', no: 'No',
  madeBy: 'Hecho por',
  creditDesc: 'Un sitio web que convierte datos de animación en bruto en una KeyframeSequence nativa, la forma en bruto de una animación de Roblox.',
  creditPrivacy: 'Todo se ejecuta en tu navegador. Tus datos de animación nunca se suben.',
  creditFonts: 'Fuentes: Orbitron y Share Tech Mono. Iconos y banderas: SVG propios.',
  creditDisclaimer: 'No está afiliado, respaldado ni patrocinado por Roblox Corporation.'
},
'pt-BR': {
  tagline: 'Transforme dados brutos de animação em um script KeyframeSequence pronto para colar.',
  tabData: 'Dados', tabConfig: 'Ajustes', tabOutput: 'Saída',
  rawTitle: 'Dados brutos', rawPh: 'Cole aqui os dados da sua animação…',
  generate: 'Analisar e gerar', sample: 'Carregar exemplo', clear: 'Limpar',
  destTitle: 'Destino', service: 'Serviço', folders: 'Pastas dentro do serviço, em ordem',
  addFolder: 'Adicionar pasta', noFolder: 'Sem pastas. A sequência vai direto para o serviço.',
  folderPh: 'Nome da pasta, ex.: Anim', removeFolder: 'Remover pasta', pathPrev: 'Prévia do local',
  folderNote: 'Crie essas pastas manualmente no Studio. O script só as procura com FindFirstChild e nunca as cria.',
  optTitle: 'Opções', seqName: 'Nome da sequência', seqNamePh: 'Obtido dos dados', priority: 'Prioridade', loop: 'Loop',
  outTitle: 'Saída', outLabel: 'ServerScript · Luau', lines: '{n} linhas',
  outPh: '-- Seu script aparecerá aqui após a análise.', copy: 'Copiar script', copied: 'Copiado', goOutput: 'Ver saída',
  settings: 'Ajustes', setupTitle: 'Configurações da interface', setupSub: 'Escolha um tema e um idioma. Você pode mudar quando quiser.',
  theme: 'Tema', themeDark: 'Escuro · Futurista', themeLight: 'Claro · Minimalista',
  accentHint: 'Escolha um modo e uma cor de destaque.',
  red: 'Vermelho', blue: 'Azul', green: 'Verde', orange: 'Laranja', language: 'Idioma', done: 'Concluir',
  errEmpty: 'Os dados brutos estão vazios. Cole-os primeiro.',
  errNoKf: 'Nenhuma linha "[Keyframe N] t=…" pôde ser lida. Verifique se o formato corresponde ao dump da animação.',
  errNum: 'Número inválido: {v}',
  warnBad: '{n} linhas não reconhecidas foram ignoradas.',
  warnCount: 'O cabeçalho indica {a} keyframes, mas {b} foram lidos.',
  warnDur: 'A duração do cabeçalho ({a}s) difere do último keyframe ({b}s).',
  warnEmpty: '{n} keyframes não têm poses.',
  chipName: 'Nome', chipDur: 'Duração', chipKf: 'Keyframes', chipPose: 'Poses', chipLoop: 'Loop (dados)', yes: 'Sim', no: 'Não',
  madeBy: 'Feito por',
  creditDesc: 'Um site que converte dados brutos de animação em uma KeyframeSequence nativa, a forma bruta de uma animação do Roblox.',
  creditPrivacy: 'Tudo roda no seu navegador. Seus dados de animação nunca são enviados.',
  creditFonts: 'Fontes: Orbitron e Share Tech Mono. Ícones e bandeiras: SVG próprios.',
  creditDisclaimer: 'Não é afiliado, endossado nem patrocinado pela Roblox Corporation.'
},
'de': {
  tagline: 'Verwandle rohe Animationsdaten in ein fertiges KeyframeSequence-Skript zum Einfügen.',
  tabData: 'Daten', tabConfig: 'Setup', tabOutput: 'Ausgabe',
  rawTitle: 'Rohdaten', rawPh: 'Füge hier deine Animationsdaten ein…',
  generate: 'Parsen & erzeugen', sample: 'Beispiel laden', clear: 'Leeren',
  destTitle: 'Ziel', service: 'Service', folders: 'Ordner im Service, der Reihe nach',
  addFolder: 'Ordner hinzufügen', noFolder: 'Keine Ordner. Die Sequenz kommt direkt in den Service.',
  folderPh: 'Ordnername, z. B. Anim', removeFolder: 'Ordner entfernen', pathPrev: 'Vorschau des Ortes',
  folderNote: 'Lege diese Ordner manuell in Studio an. Das Skript sucht sie nur mit FindFirstChild und erstellt sie nie.',
  optTitle: 'Optionen', seqName: 'Name der Sequenz', seqNamePh: 'Aus den Daten übernommen', priority: 'Priorität', loop: 'Loop',
  outTitle: 'Ausgabe', outLabel: 'ServerScript · Luau', lines: '{n} Zeilen',
  outPh: '-- Dein Skript erscheint hier nach dem Parsen.', copy: 'Skript kopieren', copied: 'Kopiert', goOutput: 'Ausgabe ansehen',
  settings: 'Einstellungen', setupTitle: 'Oberflächen-Einstellungen', setupSub: 'Wähle ein Theme und eine Sprache. Du kannst beides jederzeit ändern.',
  theme: 'Theme', themeDark: 'Dunkel · Futuristisch', themeLight: 'Hell · Minimalistisch',
  accentHint: 'Wähle einen Modus und eine Akzentfarbe.',
  red: 'Rot', blue: 'Blau', green: 'Grün', orange: 'Orange', language: 'Sprache', done: 'Fertig',
  errEmpty: 'Die Rohdaten sind leer. Füge sie zuerst ein.',
  errNoKf: 'Es konnte keine Zeile "[Keyframe N] t=…" gelesen werden. Prüfe, ob das Format zum Animations-Dump passt.',
  errNum: 'Ungültige Zahl: {v}',
  warnBad: '{n} nicht erkannte Zeilen wurden übersprungen.',
  warnCount: 'Der Header nennt {a} Keyframes, gelesen wurden aber {b}.',
  warnDur: 'Die Dauer im Header ({a}s) weicht vom letzten Keyframe ({b}s) ab.',
  warnEmpty: '{n} Keyframes enthalten keine Posen.',
  chipName: 'Name', chipDur: 'Dauer', chipKf: 'Keyframes', chipPose: 'Posen', chipLoop: 'Loop (Daten)', yes: 'Ja', no: 'Nein',
  madeBy: 'Erstellt von',
  creditDesc: 'Eine Website, die rohe Animationsdaten in eine native KeyframeSequence umwandelt, die Rohform einer Roblox-Animation.',
  creditPrivacy: 'Alles läuft in deinem Browser. Deine Animationsdaten werden nie hochgeladen.',
  creditFonts: 'Schriften: Orbitron und Share Tech Mono. Symbole und Flaggen: eigene SVGs.',
  creditDisclaimer: 'Nicht mit Roblox Corporation verbunden, von ihr unterstützt oder gesponsert.'
}
};

/* ---------- STATE ---------- */
const MODES = ['dark', 'light'];
const ACCENTS = ['red', 'blue', 'green', 'orange'];
const ACC = {
  dark: { red: '#ff2a3d', blue: '#2d8cff', green: '#22e06b', orange: '#ff8a1f' },
  light: { red: '#d81b2d', blue: '#1a5fe0', green: '#0b8a4a', orange: '#d45a00' }
};
const SERVICES = ['ServerScriptService','ServerStorage','ReplicatedStorage','Workspace','ReplicatedFirst','Lighting','StarterPack','StarterGui','StarterPlayer'];
const PRIORITIES = ['Core','Idle','Movement','Action','Action2','Action3','Action4'];
const ui = { mode: 'dark', accent: 'red', lang: 'en-US' };
const state = { parsed: null, warns: [], err: null, folders: [], nameDirty: false, loopDirty: false };

try {
  const s = JSON.parse(localStorage.getItem('kff.ui') || 'null');
  if (s) {
    if (MODES.includes(s.mode)) ui.mode = s.mode;
    if (ACCENTS.includes(s.accent)) ui.accent = s.accent;
    if (LANGS.some(l => l.code === s.lang)) ui.lang = s.lang;
  }
} catch (_) {}
function save() { try { localStorage.setItem('kff.ui', JSON.stringify(ui)); } catch (_) {} }

function t(k, p) {
  let s = (T[ui.lang] && T[ui.lang][k]) || T['en-US'][k] || k;
  if (p) s = s.replace(/\{(\w+)\}/g, (m, n) => (p[n] !== undefined ? p[n] : m));
  return s;
}
const isMobile = () => window.matchMedia('(max-width: 820px)').matches;

/* ---------- PARSER (unchanged logic) ---------- */
class AppErr extends Error { constructor(key, params) { super(key); this.key = key; this.params = params || {}; } }
const NUM = '[-+]?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?';
const RE_HEAD = /^==\s*(.+?)\s*==$/;
const RE_DUR  = /Duration:\s*([\d.]+)/i;
const RE_CNT  = /Keyframes:\s*(\d+)/i;
const RE_LOOP = /Loop:\s*(true|false)/i;
const RE_KF   = new RegExp('^\\[Keyframe[^\\]]*\\]\\s*t\\s*=\\s*(' + NUM + ')\\s*s?\\s*(?:\\((.*)\\))?\\s*$', 'i');
const RE_POSE = /^([^:]+?):\s+(.+)$/;
const RE_VAL  = new RegExp('^rot\\s+(' + NUM + ')\\s*°?\\s*axis\\(\\s*(' + NUM + ')\\s*,\\s*(' + NUM + ')\\s*,\\s*(' + NUM + ')\\s*\\)(?:\\s*pos\\(\\s*x\\s*=\\s*(' + NUM + ')\\s*,\\s*y\\s*=\\s*(' + NUM + ')\\s*,\\s*z\\s*=\\s*(' + NUM + ')\\s*\\))?\\s*$', 'i');

function clean(s) {
  if (!Number.isFinite(Number(s))) throw new AppErr('errNum', { v: s });
  return String(s).trim().replace(/^\+/, '');
}

/* ---------- DENSIFY (v1.0.6) ----------
   Roblox's docs are explicit that a joint doesn't need a Pose in every
   Keyframe ("...without needing to define every frame") — BUT they're
   equally explicit that "each Pose is parented to the Pose corresponding
   to the part it is attached to", i.e. the hierarchy path has to be
   consistent. When a descendant (e.g. the Head) has real data in a
   keyframe but its ancestor (e.g. the Torso) doesn't, we can't just skip
   the ancestor (v1.0.5) — that silently changes WHICH pose object the
   Head attaches to from one keyframe to the next, which fragments what
   should be one continuous track for that joint into several disconnected
   one-point tracks (nothing to interpolate between = hard snaps). We also
   can't fill the gap with a placeholder CFrame (v1.0.3's hold, v1.0.4's
   Weight=0) without corrupting that ancestor's OWN motion with a fake
   waypoint that isn't really part of its animation curve.

   The fix that satisfies both requirements at once: compute what the
   ancestor's real value WOULD be at that timestamp by interpolating
   between its own two nearest real keyframes — position lerped linearly,
   rotation slerped via quaternion (matching exactly how CFrame:Lerp
   itself interpolates) — and bake that in as genuine data. Every joint
   then has a real, correctly-weighted Pose at every keyframe, so the
   hierarchy is always consistent AND every value already sits exactly on
   the curve Roblox would draw anyway, so nothing about the motion
   actually changes — gaps are just filled with points already on their
   own curve rather than left as structurally-inconsistent holes. */
function axisAngleToQuat(angleDeg, axis) {
  let [x, y, z] = axis;
  let mag = Math.sqrt(x * x + y * y + z * z);
  if (mag > 0.0001) { x /= mag; y /= mag; z /= mag; } else { x = 0; y = 1; z = 0; }
  const half = (angleDeg * Math.PI / 180) / 2;
  const s = Math.sin(half);
  return { w: Math.cos(half), x: x * s, y: y * s, z: z * s };
}
function quatToAxisAngle(q) {
  let { w, x, y, z } = q;
  const mag = Math.sqrt(w * w + x * x + y * y + z * z);
  if (mag > 0.0001) { w /= mag; x /= mag; y /= mag; z /= mag; }
  const wc = Math.min(1, Math.max(-1, w));
  const angle = 2 * Math.acos(wc);
  const s = Math.sqrt(1 - wc * wc);
  let axis;
  if (s < 0.0001) axis = [0, 1, 0];
  else axis = [x / s, y / s, z / s];
  return { angle: angle * 180 / Math.PI, axis };
}
function slerpQuat(a, b, t) {
  let dot = a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z;
  let bb = b;
  if (dot < 0) { bb = { w: -b.w, x: -b.x, y: -b.y, z: -b.z }; dot = -dot; }
  if (dot > 0.9995) {
    return {
      w: a.w + (bb.w - a.w) * t, x: a.x + (bb.x - a.x) * t,
      y: a.y + (bb.y - a.y) * t, z: a.z + (bb.z - a.z) * t
    };
  }
  const theta0 = Math.acos(Math.min(1, Math.max(-1, dot)));
  const theta = theta0 * t;
  const s0 = Math.cos(theta) - dot * Math.sin(theta) / Math.sin(theta0);
  const s1 = Math.sin(theta) / Math.sin(theta0);
  return {
    w: s0 * a.w + s1 * bb.w, x: s0 * a.x + s1 * bb.x,
    y: s0 * a.y + s1 * bb.y, z: s0 * a.z + s1 * bb.z
  };
}
function round4(n) { return Math.round(n * 10000) / 10000; }

function densifyKeyframes(p) {
  const times = p.keyframes.map(k => Number(k.t));
  // path -> sorted [{t, angle, axis:[x,y,z], pos:[x,y,z]|null}]
  const tracks = {};
  p.keyframes.forEach(kf => {
    kf.poses.forEach(po => {
      if (po.idle) return;
      (tracks[po.path] ||= []).push({
        t: Number(kf.t),
        angle: Number(po.angle),
        axis: po.axis.map(Number),
        pos: po.pos ? po.pos.map(Number) : [0, 0, 0]
      });
    });
  });
  Object.keys(tracks).forEach(path => tracks[path].sort((a, b) => a.t - b.t));

  p.keyframes.forEach(kf => {
    const t = Number(kf.t);
    const hadPath = new Set(kf.poses.map(po => po.path));
    const newPoses = [];
    kf.poses.forEach(po => { if (po.idle && !(po.path in tracks)) newPoses.push(po); });
    Object.keys(tracks).forEach(path => {
      const pts = tracks[path];
      if (pts.length === 1) {
        const only = pts[0];
        newPoses.push({ path, angle: String(only.angle), axis: only.axis.map(String), pos: only.pos.map(String) });
        return;
      }
      let lo = pts[0], hi = pts[pts.length - 1];
      for (let i = 0; i < pts.length - 1; i++) {
        if (t >= pts[i].t - 1e-6 && t <= pts[i + 1].t + 1e-6) { lo = pts[i]; hi = pts[i + 1]; break; }
      }
      if (Math.abs(t - lo.t) < 1e-6) {
        newPoses.push({ path, angle: String(lo.angle), axis: lo.axis.map(String), pos: lo.pos.map(String) });
        return;
      }
      if (Math.abs(t - hi.t) < 1e-6) {
        newPoses.push({ path, angle: String(hi.angle), axis: hi.axis.map(String), pos: hi.pos.map(String) });
        return;
      }
      if (t < lo.t || t > hi.t) {
        // Outside this joint's own recorded range: hold nearest edge
        // rather than extrapolate.
        const edge = t < lo.t ? lo : hi;
        newPoses.push({ path, angle: String(edge.angle), axis: edge.axis.map(String), pos: edge.pos.map(String) });
        return;
      }
      const f = (t - lo.t) / (hi.t - lo.t);
      const qa = axisAngleToQuat(lo.angle, lo.axis);
      const qb = axisAngleToQuat(hi.angle, hi.axis);
      const q = slerpQuat(qa, qb, f);
      const { angle, axis } = quatToAxisAngle(q);
      const pos = [0, 1, 2].map(i => round4(lo.pos[i] + (hi.pos[i] - lo.pos[i]) * f));
      newPoses.push({ path, angle: String(round4(angle)), axis: axis.map(n => String(round4(n))), pos: pos.map(String) });
    });
    kf.poses = newPoses;
  });
}

function parseDump(text) {
  const p = { name: null, duration: null, declared: null, loop: null, keyframes: [] };
  const warns = [];
  let cur = null, bad = 0;
  text.replace(/\r/g, '').split('\n').forEach(raw => {
    const line = raw.trim();
    if (!line) return;
    let m;
    if ((m = line.match(RE_KF))) {
      cur = { t: clean(m[1]), name: ((m[2] || '').trim() || 'Keyframe'), poses: [] };
      p.keyframes.push(cur);
      return;
    }
    if (!cur) {
      if ((m = line.match(RE_HEAD))) { p.name = m[1]; return; }
      if ((m = line.match(RE_DUR))) p.duration = parseFloat(m[1]);
      if ((m = line.match(RE_CNT))) p.declared = parseInt(m[1], 10);
      if ((m = line.match(RE_LOOP))) p.loop = m[1].toLowerCase() === 'true';
      return;
    }
    const pm = line.match(RE_POSE);
    if (!pm) { bad++; return; }
    const path = pm[1].split('/').map(x => x.trim()).filter(Boolean).join('/');
    if (!path) { bad++; return; }
    const val = pm[2].trim();
    if (/^idle$/i.test(val)) { cur.poses.push({ path, idle: true }); return; }
    const vm = val.match(RE_VAL);
    if (!vm) { bad++; return; }
    cur.poses.push({
      path,
      angle: clean(vm[1]),
      axis: [clean(vm[2]), clean(vm[3]), clean(vm[4])],
      pos: vm[5] !== undefined ? [clean(vm[5]), clean(vm[6]), clean(vm[7])] : null
    });
  });

  if (!p.keyframes.length) throw new AppErr('errNoKf');
  if (bad) warns.push({ key: 'warnBad', params: { n: bad } });
  if (p.declared !== null && p.declared !== p.keyframes.length) warns.push({ key: 'warnCount', params: { a: p.declared, b: p.keyframes.length } });
  const lastT = Math.max(...p.keyframes.map(k => Number(k.t)));
  if (p.duration !== null && Math.abs(p.duration - lastT) > 0.005) warns.push({ key: 'warnDur', params: { a: p.duration, b: lastT } });
  const empty = p.keyframes.filter(k => !k.poses.length).length;
  if (empty) warns.push({ key: 'warnEmpty', params: { n: empty } });
  densifyKeyframes(p);
  return { parsed: p, warns };
}

/* ---------- GENERATOR ---------- */
const luaStr = s => '"' + String(s).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';

/* NOTE (v1.0.6): the logic below (only ever create a Pose when the source
   entry has real angle/axis data, nest under the nearest real ancestor)
   is unchanged from v1.0.5 — it was correct on its own. What was missing
   was upstream: DATA itself used to be sparse (a joint's path only
   appeared with real numbers on the keyframes where it was actually
   moved), so an ancestor with real data on some keyframes and none on
   others made its descendants attach to a DIFFERENT parent Pose from one
   keyframe to the next, fragmenting what should be one continuous track
   into several disconnected single-point ones (nothing to interpolate
   between = a hard snap). See the densifyKeyframes() comment near the
   top of the script: DATA is now pre-filled so every joint that's
   animated at all has real, correctly-interpolated data at every single
   keyframe, so the code below now always finds a real ancestor to nest
   under, and every hierarchy path stays consistent from start to
   finish. */
const LUA_TAIL = `
-- ===== CHECK SETTINGS AND DATA =====
local folders = FOLDERS or {}
assert(type(SEQUENCE_NAME) == "string", "[KeyframeSequence] The SEQUENCE_NAME line is missing at the top of the script.")
assert(type(SERVICE) == "string", "[KeyframeSequence] The SERVICE line is missing at the top of the script.")
assert(type(DATA) == "table" and #DATA > 0, "[KeyframeSequence] DATA is missing or empty.")
for i = 1, #DATA do
	local kf = DATA[i]
	assert(
		type(kf) == "table" and type(kf.poses) == "table",
		("[KeyframeSequence] Keyframe #%d is broken. The data was probably cut off or edited."):format(i)
	)
end

local function buildOffsetCFrame(angle, axis, pos)
	local axisVec = Vector3.new(axis[1], axis[2], axis[3])
	if axisVec.Magnitude > 0.0001 then
		axisVec = axisVec.Unit
	else
		axisVec = Vector3.new(0, 1, 0)
	end
	local posVec = pos and Vector3.new(pos[1], pos[2], pos[3]) or Vector3.new(0, 0, 0)
	return CFrame.new(posVec) * CFrame.fromAxisAngle(axisVec, math.rad(angle))
end

-- ===== FIND DESTINATION (folders must already exist) =====
local target = game:GetService(SERVICE)
for _, folderName in ipairs(folders) do
	local nextTarget = target:FindFirstChild(folderName)
	if not nextTarget then
		warn(("[KeyframeSequence] Folder '%s' was not found in %s. Create it manually first."):format(folderName, target:GetFullName()))
		return
	end
	target = nextTarget
end

-- ===== BUILD KEYFRAMESEQUENCE =====
local sequence = Instance.new("KeyframeSequence")
sequence.Name = SEQUENCE_NAME
sequence.Loop = LOOP == true
sequence.Priority = Enum.AnimationPriority.__PRI__

for _, kf in ipairs(DATA) do
	local keyframe = Instance.new("Keyframe")
	keyframe.Name = kf.name
	keyframe.Time = kf.t

	-- Only the joints THIS keyframe actually has authored angle/axis data
	-- for. A hierarchy-only entry (no angle/axis) means this joint isn't
	-- being keyed here, so it's simply not added to this table.
	local dataAt = {}
	for _, entry in ipairs(kf.poses) do
		if entry[2] then
			dataAt[entry[1]] = entry
		end
	end

	local poses = {}
	local function getPose(path)
		local existing = poses[path]
		if existing ~= nil then
			return existing or nil
		end
		local entry = dataAt[path]
		if not entry then
			-- No authored data for this joint at this keyframe: don't
			-- fabricate one. Mark as visited (false, not a Pose) so we
			-- don't re-check it, and its own track keeps interpolating
			-- smoothly between whichever real keyframes DO define it.
			poses[path] = false
			return nil
		end
		local pose = Instance.new("Pose")
		pose.Name = path:match("([^/]+)$")
		pose.CFrame = buildOffsetCFrame(entry[2], entry[3], entry[4])
		pose.Weight = 1
		pose.EasingStyle = Enum.PoseEasingStyle.Linear
		pose.EasingDirection = Enum.PoseEasingDirection.In
		poses[path] = pose
		-- Walk up to the nearest ancestor that ALSO has real data at this
		-- same keyframe; skip straight past any ancestor that doesn't,
		-- rather than inventing a stand-in for it.
		local parentPath = path:match("^(.+)/[^/]+$")
		local parentPose = parentPath and getPose(parentPath)
		pose.Parent = parentPose or keyframe
		return pose
	end

	for path in pairs(dataAt) do
		getPose(path)
	end

	keyframe.Parent = sequence
end

sequence.Parent = target
print(("[KeyframeSequence] Created '%s' in %s"):format(sequence.Name, target:GetFullName()))
`;

function generate(p, s) {
  const svc = SERVICES.includes(s.service) ? s.service : 'ServerScriptService';
  const pri = PRIORITIES.includes(s.priority) ? s.priority : 'Action';
  const lastT = Math.max(...p.keyframes.map(k => Number(k.t)));
  const L = [];
  L.push('-- Generated by KEYFRAME//FORGE v' + APP_VERSION + ' | ' + p.keyframes.length + ' keyframes | duration ' + (p.duration ?? lastT) + 's');
  L.push('local SEQUENCE_NAME = ' + luaStr(s.name));
  L.push('local SERVICE = ' + luaStr(svc));
  L.push('local FOLDERS = {' + s.folders.map(luaStr).join(', ') + '}');
  L.push('local LOOP = ' + (s.loop ? 'true' : 'false'));
  L.push('');
  L.push('-- ===== ANIMATION DATA =====');
  L.push('local DATA = {');
  p.keyframes.forEach(kf => {
    L.push('\t{t = ' + kf.t + ', name = ' + luaStr(kf.name) + ', poses = {');
    kf.poses.forEach(po => {
      if (po.idle) {
        L.push('\t\t{' + luaStr(po.path) + '},');
      } else {
        let row = '{' + luaStr(po.path) + ', ' + po.angle + ', {' + po.axis.join(', ') + '}';
        if (po.pos) row += ', {' + po.pos.join(', ') + '}';
        L.push('\t\t' + row + '},');
      }
    });
    L.push('\t}},');
  });
  L.push('}');
  return L.join('\n') + '\n' + LUA_TAIL.replace('__PRI__', pri);
}

/* ---------- UI HELPERS ---------- */
function chip(l, v) {
  const d = document.createElement('div'); d.className = 'chip';
  const a = document.createElement('small'); a.textContent = l;
  const b = document.createElement('strong'); b.textContent = v;
  d.append(a, b); return d;
}
function msg(cls, text) {
  const m = document.createElement('div'); m.className = 'msg ' + cls; m.textContent = text; return m;
}

function renderStatus() {
  const box = $('status'); box.replaceChildren();
  if (state.err) {
    box.appendChild(msg('err', '✖ ' + (state.err.key ? t(state.err.key, state.err.params) : state.err.raw)));
    return;
  }
  const p = state.parsed; if (!p) return;
  const paths = new Set();
  p.keyframes.forEach(k => k.poses.forEach(o => paths.add(o.path)));
  const lastT = Math.max(...p.keyframes.map(k => Number(k.t)));
  const chips = document.createElement('div'); chips.className = 'chips';
  chips.append(
    chip(t('chipName'), p.name || 'Animation'),
    chip(t('chipDur'), (p.duration ?? lastT) + 's'),
    chip(t('chipKf'), p.keyframes.length),
    chip(t('chipPose'), paths.size),
    chip(t('chipLoop'), p.loop === null ? '-' : (p.loop ? t('yes') : t('no')))
  );
  box.appendChild(chips);
  state.warns.forEach(w => box.appendChild(msg('warn', '⚠ ' + t(w.key, w.params))));
  const go = document.createElement('button');
  go.type = 'button'; go.className = 'btn ghost only-mobile'; go.textContent = t('goOutput') + ' →';
  go.addEventListener('click', () => setTab('output'));
  box.appendChild(go);
}

function getSettings() {
  return {
    service: $('service').value,
    folders: state.folders.map(s => s.trim()).filter(Boolean),
    name: $('seqName').value.trim() || (state.parsed && state.parsed.name) || 'Animation',
    priority: $('priority').value,
    loop: $('loop').checked
  };
}

/* Location tree: Service > folders > KeyframeSequence, with Explorer-style icons */
function updatePathPreview() {
  const s = getSettings();
  const tree = $('tree'); tree.replaceChildren();
  const rows = [{ kind: 'svc', name: s.service, icon: SVC_ICONS[s.service] || SVC_ICONS.Workspace }]
    .concat(s.folders.map(n => ({ kind: 'folder', name: n, icon: FOLDER_ICON })))
    .concat([{ kind: 'seq', name: s.name, icon: SEQ_ICON }]);
  rows.forEach((r, d) => {
    const row = document.createElement('div');
    row.className = 'tn' + (d ? ' child' : '');
    row.style.setProperty('--d', d);
    row.setAttribute('role', 'listitem');
    const ic = document.createElement('span'); ic.className = 'ti ti-' + r.kind; ic.innerHTML = r.icon;
    const lb = document.createElement('span'); lb.className = 'tl' + (r.kind === 'seq' ? ' seq' : ''); lb.textContent = r.name;
    row.append(ic, lb); tree.appendChild(row);
  });
}
function updateLines() {
  const v = $('out').value;
  $('lines').textContent = t('lines', { n: v ? v.split('\n').length : 0 });
}
function regen() {
  if (!state.parsed) return;
  $('out').value = generate(state.parsed, getSettings());
  updateLines();
  $('copy').disabled = false;
}
function refresh() { updatePathPreview(); regen(); }
function clearOutput() { $('out').value = ''; $('copy').disabled = true; updateLines(); }

function renderFolders() {
  const box = $('folders'); box.replaceChildren();
  if (!state.folders.length) {
    const e = document.createElement('div'); e.className = 'empty'; e.textContent = t('noFolder');
    box.appendChild(e); return;
  }
  state.folders.forEach((val, i) => {
    const row = document.createElement('div'); row.className = 'frow';
    const idx = document.createElement('span'); idx.className = 'fidx'; idx.textContent = String(i + 1).padStart(2, '0');
    const inp = document.createElement('input');
    inp.type = 'text'; inp.value = val; inp.placeholder = t('folderPh'); inp.spellcheck = false; inp.autocomplete = 'off';
    inp.addEventListener('input', () => { state.folders[i] = inp.value; refresh(); });
    const del = document.createElement('button');
    del.type = 'button'; del.className = 'btn ghost sm'; del.textContent = '✕'; del.title = t('removeFolder'); del.setAttribute('aria-label', t('removeFolder'));
    del.addEventListener('click', () => { state.folders.splice(i, 1); renderFolders(); refresh(); });
    row.append(idx, inp, del); box.appendChild(row);
  });
}

function run(fromBtn) {
  const txt = $('raw').value;
  if (!txt.trim()) {
    state.parsed = null; state.warns = []; state.err = { key: 'errEmpty' };
    clearOutput(); renderStatus(); updatePathPreview(); previewOnDataChanged(); return;
  }
  try {
    const { parsed, warns } = parseDump(txt);
    state.parsed = parsed; state.warns = warns; state.err = null;
    if (!state.nameDirty) $('seqName').value = parsed.name || 'Animation';
    if (!state.loopDirty && parsed.loop !== null) $('loop').checked = parsed.loop;
    renderStatus(); refresh(); previewOnDataChanged();
    if (fromBtn && isMobile() && !warns.length) setTab('output');
  } catch (e) {
    state.parsed = null; state.warns = [];
    state.err = e.key ? { key: e.key, params: e.params } : { raw: e.message };
    clearOutput(); renderStatus(); updatePathPreview(); previewOnDataChanged();
  }
}

/* ---------- TABS / TOAST / COPY ---------- */
function setTab(name) {
  document.body.dataset.tab = name;
  document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', b.dataset.go === name ? 'true' : 'false'));
  window.scrollTo({ top: 0 });
}
let toastTimer;
function toast(txt) {
  const el = $('toast'); el.textContent = txt; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 1600);
}
async function copyOut() {
  const o = $('out'); if (!o.value) return;
  try { await navigator.clipboard.writeText(o.value); }
  catch (_) { o.removeAttribute('readonly'); o.select(); document.execCommand('copy'); o.setAttribute('readonly', ''); }
  toast(t('copied'));
}

/* ---------- THEME / LANGUAGE / SETTINGS ---------- */
function applyTheme() {
  const r = document.documentElement;
  r.dataset.mode = ui.mode; r.dataset.accent = ui.accent;
  $('metaTheme').setAttribute('content', ui.mode === 'dark' ? '#050506' : '#ffffff');
  document.querySelectorAll('.sw').forEach(b => b.setAttribute('aria-pressed', (b.dataset.mode === ui.mode && b.dataset.accent === ui.accent) ? 'true' : 'false'));
}

function fillLangList(el) {
  el.replaceChildren();
  LANGS.forEach(L => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'lang-item'; b.setAttribute('role', 'option');
    b.setAttribute('aria-selected', L.code === ui.lang ? 'true' : 'false');
    const f = document.createElement('span'); f.className = 'flag'; f.innerHTML = FLAGS[L.code];
    const n = document.createElement('span'); n.textContent = L.label;
    const c = document.createElement('span'); c.className = 'chk'; c.textContent = '✓';
    b.append(f, n, c);
    b.addEventListener('click', () => { ui.lang = L.code; save(); applyLang(); closePop(); });
    el.appendChild(b);
  });
}

const EXAMPLE = '== AnimName ==\nDuration: 0.48s | Keyframes: 30\nLoop: false\n\n[Keyframe 1] t=0.00s (Keyframe)\n  HumanoidRootPart: idle\n  HumanoidRootPart/Torso: rot 94.3° axis(0.35, -0.22, -0.91)  pos(x=-0.40, y=-0.01, z=-0.98)';

function applyLang() {
  const cur = LANGS.find(l => l.code === ui.lang) || LANGS[0];
  document.documentElement.lang = cur.code;
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
  document.querySelectorAll('[data-i18n-aria]').forEach(el => { const s = t(el.dataset.i18nAria); el.setAttribute('aria-label', s); el.title = s; });
  $('raw').placeholder = t('rawPh') + '\n\n' + EXAMPLE;
  $('langFlag').innerHTML = FLAGS[cur.code];
  $('langCode').textContent = cur.short;
  fillLangList($('langList')); fillLangList($('setupLangList'));
  renderFolders(); renderStatus(); updateLines();
}

function closePop() { $('langPop').hidden = true; $('langBtn').setAttribute('aria-expanded', 'false'); }
function togglePop() {
  const open = $('langPop').hidden;
  $('langPop').hidden = !open; $('langBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
}
function openSetup() { closePop(); $('modal').hidden = false; document.body.style.overflow = 'hidden'; }
function closeSetup() { $('modal').hidden = true; document.body.style.overflow = ''; }

function buildThemes() {
  const box = $('themes'); box.replaceChildren();
  MODES.forEach(mode => {
    const g = document.createElement('div'); g.className = 'sw-group';
    const h = document.createElement('div'); h.className = 'sw-title'; h.dataset.i18n = mode === 'dark' ? 'themeDark' : 'themeLight';
    const grid = document.createElement('div'); grid.className = 'sw-grid';
    ACCENTS.forEach(a => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'sw'; b.dataset.mode = mode; b.dataset.accent = a;
      b.style.setProperty('--sb', mode === 'dark' ? '#050506' : '#ffffff');
      b.style.setProperty('--sa', ACC[mode][a]);
      const p = document.createElement('span'); p.className = 'sw-prev';
      const l = document.createElement('span'); l.dataset.i18n = a;
      b.append(p, l);
      b.addEventListener('click', () => { ui.mode = mode; ui.accent = a; applyTheme(); save(); });
      grid.appendChild(b);
    });
    g.append(h, grid); box.appendChild(g);
  });
}

/* ---------- PREVIEW (3D) ----------
   R6/R15 box-rig used to check timing and smoothness of the parsed
   keyframe data. Pivot points, mesh offsets and part sizes below are
   measured (not eyeballed) from two reference Blender rigs built to
   Roblox Studio's real stud scale, so proportions and joint placement
   line up with an actual Roblox character. Reuses the same
   axisAngleToQuat/slerpQuat math as densifyKeyframes() above so what
   you see here matches exactly what Roblox itself will interpolate. */
const ROOT_Y = 3;
const RIG_SPECS = {
  r6: [
    { name: 'Torso', parent: null, piv: [0, 0, 0], mesh: [0, 0, 0], size: [2, 2, 1], color: 0x3a6bd8 },
    { name: 'Head', parent: 'Torso', piv: [0, 1, 0], mesh: [0, 0.5, 0], size: [1.2, 1.2, 1.2], color: 0xe8b978 },
    { name: 'Left Arm', parent: 'Torso', piv: [-1, 0.5, 0], mesh: [-0.5, -0.5, 0], size: [1, 2, 1], color: 0xe8b978 },
    { name: 'Right Arm', parent: 'Torso', piv: [1, 0.5, 0], mesh: [0.5, -0.5, 0], size: [1, 2, 1], color: 0xe8b978 },
    { name: 'Left Leg', parent: 'Torso', piv: [-0.5, -1, 0], mesh: [0, -1, 0], size: [1, 2, 1], color: 0x1c2b52 },
    { name: 'Right Leg', parent: 'Torso', piv: [0.5, -1, 0], mesh: [0, -1, 0], size: [1, 2, 1], color: 0x1c2b52 }
  ],
  r15: [
    { name: 'LowerTorso', parent: null, piv: [0, -1, 0], mesh: [0, 0.2, 0], size: [2, 0.4, 1], color: 0x3a6bd8 },
    { name: 'UpperTorso', parent: 'LowerTorso', piv: [0, 0.4, 0], mesh: [0, 0.8, 0], size: [2, 1.6, 1], color: 0x3a6bd8 },
    { name: 'Head', parent: 'UpperTorso', piv: [0, 1.6, 0], mesh: [0, 0.5, 0], size: [1.2, 1.2, 1.2], color: 0xe8b978 },
    { name: 'LeftUpperArm', parent: 'UpperTorso', piv: [-1, 1.363, 0], mesh: [-0.5, -0.394, 0], size: [1, 1.169, 1], color: 0xe8b978 },
    { name: 'LeftLowerArm', parent: 'LeftUpperArm', piv: [-0.5, -0.728, 0], mesh: [0, -0.259, 0], size: [1, 1.052, 1], color: 0xe8b978 },
    { name: 'LeftHand', parent: 'LeftLowerArm', piv: [0, -0.76, 0], mesh: [0, -0.125, 0], size: [1, 0.3, 1], color: 0xe8b978 },
    { name: 'RightUpperArm', parent: 'UpperTorso', piv: [1, 1.363, 0], mesh: [0.5, -0.394, 0], size: [1, 1.169, 1], color: 0xe8b978 },
    { name: 'RightLowerArm', parent: 'RightUpperArm', piv: [0.5, -0.728, 0], mesh: [0, -0.259, 0], size: [1, 1.052, 1], color: 0xe8b978 },
    { name: 'RightHand', parent: 'RightLowerArm', piv: [0, -0.76, 0], mesh: [0, -0.125, 0], size: [1, 0.3, 1], color: 0xe8b978 },
    { name: 'LeftUpperLeg', parent: 'LowerTorso', piv: [-0.5, 0, 0], mesh: [0, -0.421, 0], size: [1, 1.217, 1], color: 0x1c2b52 },
    { name: 'LeftLowerLeg', parent: 'LeftUpperLeg', piv: [0, -0.822, 0], mesh: [0, -0.379, 0], size: [1, 1.193, 1], color: 0x1c2b52 },
    { name: 'LeftFoot', parent: 'LeftLowerLeg', piv: [0, -0.926, 0], mesh: [0, -0.102, 0], size: [1, 0.3, 1], color: 0x1c2b52 },
    { name: 'RightUpperLeg', parent: 'LowerTorso', piv: [0.5, 0, 0], mesh: [0, -0.421, 0], size: [1, 1.217, 1], color: 0x1c2b52 },
    { name: 'RightLowerLeg', parent: 'RightUpperLeg', piv: [0, -0.822, 0], mesh: [0, -0.379, 0], size: [1, 1.193, 1], color: 0x1c2b52 },
    { name: 'RightFoot', parent: 'RightLowerLeg', piv: [0, -0.926, 0], mesh: [0, -0.102, 0], size: [1, 0.3, 1], color: 0x1c2b52 }
  ]
};

function detectRigType(parsed) {
  if (!parsed) return 'r6';
  const paths = new Set();
  parsed.keyframes.forEach(kf => kf.poses.forEach(po => paths.add(po.path)));
  for (const p of paths) {
    if (/UpperTorso|LowerTorso|UpperArm|LowerArm|UpperLeg|LowerLeg|Hand|Foot/.test(p)) return 'r15';
  }
  return 'r6';
}

function tintColor(base, tint, amount) {
  const b = { r: (base >> 16) & 255, g: (base >> 8) & 255, b: base & 255 };
  const t = { r: (tint >> 16) & 255, g: (tint >> 8) & 255, b: tint & 255 };
  const mix = (a, c) => Math.round(a * (1 - amount) + c * amount);
  return (mix(b.r, t.r) << 16) | (mix(b.g, t.g) << 8) | mix(b.b, t.b);
}

function buildRig(type) {
  const spec = RIG_SPECS[type] || RIG_SPECS.r6;
  const group = new THREE.Group();
  const rootPivot = new THREE.Group();
  rootPivot.position.set(0, ROOT_Y, 0);
  group.add(rootPivot);
  const joints = { HumanoidRootPart: { pivot: rootPivot, rest: new THREE.Vector3(0, 0, 0), path: 'HumanoidRootPart' } };
  const byName = {};
  spec.forEach(node => {
    const parentInfo = node.parent ? byName[node.parent] : joints.HumanoidRootPart;
    const pivot = new THREE.Group();
    pivot.position.set(node.piv[0], node.piv[1], node.piv[2]);
    parentInfo.pivot.add(pivot);
    const geo = new THREE.BoxGeometry(node.size[0], node.size[1], node.size[2]);
    // Left/right is easy to mix up once the camera has orbited around (and
    // the head's face marker is out of view) — tint Left limbs blue and
    // Right limbs red, the common rigging-tool convention, so the side is
    // readable from any angle without having to find the face first.
    let boxColor = node.color;
    if (/^Left/.test(node.name)) boxColor = tintColor(node.color, 0x2255ff, 0.28);
    else if (/^Right/.test(node.name)) boxColor = tintColor(node.color, 0xff3322, 0.28);
    const mat = new THREE.MeshStandardMaterial({ color: boxColor, roughness: 0.65, metalness: 0.05 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(node.mesh[0], node.mesh[1], node.mesh[2]);
    pivot.add(mesh);
    // Roblox's front is -Z (LookVector). The box rig is otherwise perfectly
    // symmetric front/back, so without a visible marker there's no way to
    // tell "forward" from "sideways" just by looking at it — add a small
    // dark "face" patch on the head's front face, same as every Roblox
    // avatar has, so orientation in the preview is never ambiguous.
    if (node.name === 'Head') {
      const faceGeo = new THREE.PlaneGeometry(node.size[0] * 0.5, node.size[1] * 0.4);
      const faceMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.8 });
      const face = new THREE.Mesh(faceGeo, faceMat);
      face.position.set(node.mesh[0], node.mesh[1], node.mesh[2] - node.size[2] / 2 - 0.01);
      face.rotation.y = Math.PI; // PlaneGeometry's default normal is +Z; flip it to face -Z (forward)
      pivot.add(face);
    }
    // A plain colored box looks identical no matter how it's spun — there's
    // nothing on it to reveal a rotation, which is exactly why the "spin
    // 180 and see" tests on the legs showed no visible difference either
    // way. Paint one narrow stripe on the FRONT (-Z) face and a differently
    // placed one on the TOP (+Y) face of every limb box, so any twist or
    // flip is something you can actually see happen instead of having to
    // infer it.
    if (/^(Left|Right)\s?(Arm|Leg|UpperArm|LowerArm|Hand|UpperLeg|LowerLeg|Foot)$/.test(node.name)) {
      const stripeMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.8 });
      const front = new THREE.Mesh(new THREE.PlaneGeometry(node.size[0] * 0.9, node.size[1] * 0.15), stripeMat);
      front.position.set(node.mesh[0], node.mesh[1] + node.size[1] * 0.25, node.mesh[2] - node.size[2] / 2 - 0.01);
      front.rotation.y = Math.PI;
      pivot.add(front);
      const top = new THREE.Mesh(new THREE.PlaneGeometry(node.size[0] * 0.15, node.size[2] * 0.9), stripeMat);
      top.position.set(node.mesh[0] - node.size[0] * 0.3, node.mesh[1] + node.size[1] / 2 + 0.01, node.mesh[2]);
      top.rotation.x = -Math.PI / 2;
      pivot.add(top);
    }
    const path = (node.parent ? parentInfo.path : 'HumanoidRootPart') + '/' + node.name;
    const info = { pivot, rest: new THREE.Vector3(node.piv[0], node.piv[1], node.piv[2]), path };
    byName[node.name] = info;
    joints[path] = info;
  });
  return { group, joints };
}

// PREVIEW-ONLY axis fix: the exported "axis(x,y,z)" values in keyframe text
// are Blender's space, not Roblox's, for the LIMBS — makes sense since arm
// and leg rotations are authored on the Blender R6/R15 reference rig's
// bones. (z, y, -x) is what that conversion works out to (found by
// checking the actual "sprint" sample: it's the one that keeps a limb's
// swing dominated by front-back motion instead of side-to-side).
//
// Torso (and Head, which follows the same pattern of its own axis values)
// is NOT recorded through that same bone pipeline — computed out with the
// limb formula, the character's own forward vector came out pitched up
// ~45° (staring at the sky, not forward) and swaying hard side to side,
// which is what put the head's face-marker on the wrong side. Torso's raw
// axis values, used completely UNCONVERTED, instead give a forward vector
// that stays almost dead-level side-to-side (near-zero drift) with just
// the natural front-back nod of a running stride — so Torso/Head are left
// as-is, and only limb rotation axes get the conversion. This ONLY affects
// what gets fed to the three.js preview; the original numbers (and
// anything copied/exported) are left untouched.
function blenderToRobloxSpace(v) {
  return [v[2], v[1], -v[0]];
}
function isRootLikePath(path) {
  return /(^|\/)(Torso|Head)$/i.test(path);
}

function buildTracks(parsed) {
  const tracks = {};
  if (!parsed) return tracks;
  parsed.keyframes.forEach(kf => {
    kf.poses.forEach(po => {
      if (po.idle) return;
      const rootLike = isRootLikePath(po.path);
      (tracks[po.path] ||= []).push({
        t: Number(kf.t), angle: Number(po.angle),
        axis: rootLike ? po.axis.map(Number) : blenderToRobloxSpace(po.axis.map(Number)),
        pos: blenderToRobloxSpace(po.pos ? po.pos.map(Number) : [0, 0, 0])
      });
    });
  });
  Object.keys(tracks).forEach(p => tracks[p].sort((a, b) => a.t - b.t));
  return tracks;
}

function sampleTrack(track, tm) {
  if (!track || !track.length) return null;
  if (track.length === 1) return { q: axisAngleToQuat(track[0].angle, track[0].axis), pos: track[0].pos };
  let lo = track[0], hi = track[track.length - 1];
  for (let i = 0; i < track.length - 1; i++) {
    if (tm >= track[i].t - 1e-6 && tm <= track[i + 1].t + 1e-6) { lo = track[i]; hi = track[i + 1]; break; }
  }
  if (tm <= lo.t) return { q: axisAngleToQuat(lo.angle, lo.axis), pos: lo.pos };
  if (tm >= hi.t) return { q: axisAngleToQuat(hi.angle, hi.axis), pos: hi.pos };
  const f = (tm - lo.t) / (hi.t - lo.t);
  const q = slerpQuat(axisAngleToQuat(lo.angle, lo.axis), axisAngleToQuat(hi.angle, hi.axis), f);
  const pos = [0, 1, 2].map(i => lo.pos[i] + (hi.pos[i] - lo.pos[i]) * f);
  return { q, pos };
}

const preview = {
  inited: false, pendingRebuild: false,
  scene: null, camera: null, renderer: null, rigGroup: null,
  joints: {}, tracks: {}, duration: 0, playing: false, time: 0, lastFrame: 0,
  // Roblox forward is -Z. theta=-0.7 (the old default) parked the camera on
  // the +Z side, i.e. looking at the rig's BACK — from there, a swing that's
  // actually front-to-back projects mostly onto the screen's left-right axis,
  // which is exactly the "maju-mundur keliatan kanan-kiri" symptom. Math.PI-0.7
  // mirrors the same 3/4 elevated angle onto the -Z (front) side instead, so
  // depth motion reads as depth. Drag still orbits freely either way.
  cam: { theta: Math.PI - 0.7, phi: 1.15, dist: 9 }
};

function applyPoseToRig() {
  Object.keys(preview.joints).forEach(path => {
    if (path === 'HumanoidRootPart') return;
    const info = preview.joints[path];
    const sample = sampleTrack(preview.tracks[path], preview.time);
    if (sample) {
      info.pivot.quaternion.set(sample.q.x, sample.q.y, sample.q.z, sample.q.w);
      info.pivot.position.set(info.rest.x + sample.pos[0], info.rest.y + sample.pos[1], info.rest.z + sample.pos[2]);
    } else {
      info.pivot.quaternion.identity();
      info.pivot.position.copy(info.rest);
    }
  });
}

function updatePrevTimeLabel() {
  $('prevTime').textContent = preview.time.toFixed(2) + ' / ' + preview.duration.toFixed(2) + 's';
}

function updatePreviewCamera() {
  const { theta, phi, dist } = preview.cam;
  const tx = 0, ty = 3, tz = 0;
  preview.camera.position.set(
    tx + dist * Math.sin(phi) * Math.sin(theta),
    ty + dist * Math.cos(phi),
    tz + dist * Math.sin(phi) * Math.cos(theta)
  );
  preview.camera.lookAt(tx, ty, tz);
}

function resizePreview() {
  if (!preview.inited) return;
  const stage = $('prevStage');
  const w = stage.clientWidth, h = stage.clientHeight;
  if (!w || !h) return;
  preview.camera.aspect = w / h;
  preview.camera.updateProjectionMatrix();
  preview.renderer.setSize(w, h);
}

function rebuildPreviewRig() {
  if (!preview.inited) return;
  if (preview.rigGroup) preview.scene.remove(preview.rigGroup);
  const sel = $('rigType').value;
  const type = sel === 'auto' ? detectRigType(state.parsed) : sel;
  const { group, joints } = buildRig(type);
  preview.scene.add(group);
  preview.rigGroup = group;
  preview.joints = joints;
  preview.tracks = buildTracks(state.parsed);
  const lastT = (state.parsed && state.parsed.keyframes.length) ? Math.max(...state.parsed.keyframes.map(k => Number(k.t))) : 0;
  preview.duration = (state.parsed && state.parsed.duration) || lastT || 0;
  preview.time = 0;
  $('prevScrub').value = '0';
  applyPoseToRig();
  updatePrevTimeLabel();
}

function previewOnDataChanged() {
  if (!preview.inited) { preview.pendingRebuild = true; return; }
  rebuildPreviewRig();
}

function setPreviewPlaying(v) {
  preview.playing = v;
  $('prevPlayIcon').innerHTML = v ? '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>';
  $('prevPlay').setAttribute('aria-label', v ? 'Pause' : 'Play');
}

function previewLoop(now) {
  requestAnimationFrame(previewLoop);
  if (!preview.inited) return;
  const dt = preview.lastFrame ? Math.min(0.05, (now - preview.lastFrame) / 1000) : 0;
  preview.lastFrame = now;
  if (preview.playing && preview.duration > 0) {
    preview.time += dt;
    if (preview.time > preview.duration) preview.time -= preview.duration;
    applyPoseToRig();
    updatePrevTimeLabel();
    $('prevScrub').value = String(Math.round((preview.time / preview.duration) * 1000));
  }
  preview.renderer.render(preview.scene, preview.camera);
}

function initPreviewScene() {
  if (preview.inited) return;
  const stage = $('prevStage');
  const w = stage.clientWidth, h = stage.clientHeight;
  if (!w || !h) return;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a0a0d);
  const camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 100);
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(w, h);
  stage.appendChild(renderer.domElement);

  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const dir = new THREE.DirectionalLight(0xffffff, 0.9);
  dir.position.set(4, 8, 5);
  scene.add(dir);
  scene.add(new THREE.GridHelper(20, 20, 0x333344, 0x1c1c24));

  preview.scene = scene; preview.camera = camera; preview.renderer = renderer;
  preview.inited = true;
  updatePreviewCamera();

  let dragging = false, lastX = 0, lastY = 0;
  stage.addEventListener('pointerdown', e => { dragging = true; lastX = e.clientX; lastY = e.clientY; stage.setPointerCapture(e.pointerId); });
  stage.addEventListener('pointerup', () => { dragging = false; });
  stage.addEventListener('pointercancel', () => { dragging = false; });
  stage.addEventListener('pointermove', e => {
    if (!dragging) return;
    const dx = e.clientX - lastX, dy = e.clientY - lastY;
    lastX = e.clientX; lastY = e.clientY;
    preview.cam.theta -= dx * 0.008;
    preview.cam.phi = Math.min(2.6, Math.max(0.3, preview.cam.phi - dy * 0.008));
    updatePreviewCamera();
  });
  stage.addEventListener('wheel', e => {
    e.preventDefault();
    preview.cam.dist = Math.min(24, Math.max(3, preview.cam.dist + e.deltaY * 0.01));
    updatePreviewCamera();
  }, { passive: false });

  if (preview.pendingRebuild) { preview.pendingRebuild = false; rebuildPreviewRig(); }
  requestAnimationFrame(previewLoop);
}

function watchPreviewStage() {
  const stage = $('prevStage');
  if (!('ResizeObserver' in window)) { initPreviewScene(); return; }
  new ResizeObserver(entries => {
    const { width, height } = entries[0].contentRect;
    if (width > 0 && height > 0) {
      if (!preview.inited) initPreviewScene(); else resizePreview();
    }
  }).observe(stage);
}

$('prevPlay').addEventListener('click', () => setPreviewPlaying(!preview.playing));
$('prevScrub').addEventListener('input', () => {
  setPreviewPlaying(false);
  const frac = Number($('prevScrub').value) / 1000;
  preview.time = preview.duration > 0 ? frac * preview.duration : 0;
  applyPoseToRig();
  updatePrevTimeLabel();
});
$('rigType').addEventListener('change', () => {
  if (preview.inited) rebuildPreviewRig(); else preview.pendingRebuild = true;
});

/* ---------- SAMPLE + EVENTS ---------- */
const SAMPLE = `== SampleDash ==
Duration: 0.10s | Keyframes: 2
Loop: false

[Keyframe 1] t=0.00s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 20.0° axis(0.00, 1.00, 0.00)  pos(x=0.00, y=0.00, z=-0.50)
  HumanoidRootPart/Torso/Head: rot 10.0° axis(1.00, 0.00, 0.00)

[Keyframe 2] t=0.10s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 0.0° axis(0.00, 1.00, 0.00)  pos(x=0.00, y=0.00, z=0.00)
  HumanoidRootPart/Torso/Head: rot 0.0° axis(1.00, 0.00, 0.00)`;

$('go').addEventListener('click', () => run(true));
$('raw').addEventListener('paste', () => setTimeout(() => run(false), 0));
$('sample').addEventListener('click', () => { $('raw').value = SAMPLE; run(false); });
$('clear').addEventListener('click', () => {
  $('raw').value = ''; state.parsed = null; state.warns = []; state.err = null;
  state.nameDirty = false; state.loopDirty = false;
  $('seqName').value = ''; $('loop').checked = false;
  clearOutput(); renderStatus(); updatePathPreview(); previewOnDataChanged();
});
$('service').addEventListener('change', refresh);
$('seqName').addEventListener('input', () => { state.nameDirty = $('seqName').value !== ''; refresh(); });
$('priority').addEventListener('change', regen);
$('loop').addEventListener('change', () => { state.loopDirty = true; regen(); });
$('addFolder').addEventListener('click', () => {
  state.folders.push(''); renderFolders(); updatePathPreview();
  const ins = $('folders').querySelectorAll('input'); if (ins.length) ins[ins.length - 1].focus();
});
$('copy').addEventListener('click', copyOut);
document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => setTab(b.dataset.go)));

$('langBtn').addEventListener('click', e => { e.stopPropagation(); togglePop(); });
document.addEventListener('click', e => { if (!e.target.closest('.lang-wrap')) closePop(); });
$('settingsBtn').addEventListener('click', openSetup);
$('done').addEventListener('click', closeSetup);
$('modal').addEventListener('click', e => { if (e.target === $('modal')) closeSetup(); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closePop(); if (!$('modal').hidden) closeSetup(); }
});

/* ---------- INIT ---------- */
document.querySelectorAll('[data-ver]').forEach(el => { el.textContent = 'v' + APP_VERSION; });
buildThemes();
applyTheme();
applyLang();
updatePathPreview();
watchPreviewStage();
})();
