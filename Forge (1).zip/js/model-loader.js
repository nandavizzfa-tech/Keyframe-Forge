/* ============================================================
   model-loader.js — scaffold for swapping the box-rig preview
   for real R6/R15 .glb models, once you have them exported.

   STATUS: this file is NOT wired into main.js yet. main.js still
   builds and animates the plain box rig exactly as before —
   nothing about the working preview changes just by adding this
   file. Use it as the starting point for the next step.

   WHY IT'S NOT WIRED IN ALREADY: driving a real imported skeleton
   means mapping each Roblox part name (e.g. "Left Arm",
   "UpperTorso") to whatever bone/node names YOUR .glb actually
   has inside it (Blender's exporter names them after your Blender
   object/bone names, which we don't know until the file exists).
   Guessing that mapping blind is exactly the kind of thing that
   caused the whole back-and-forth on the box rig's axes — better
   to look at the real bone names once you export, then fill in
   BONE_NAME_MAP below.

   HOW TO GET assets/R6.glb / assets/R15.glb:
   In Blender, with Blender_R6.blend (or the R15 rig) open:
     File > Export > glTF 2.0 (.glb/.gltf)
     Format: glTF Binary (.glb)
     Include: Selected Objects (select your rig + meshes first)
   Save it as assets/R6.glb (or R15.glb) in this folder structure.
   ============================================================ */

const ModelLoader = (() => {
  let loader = null;
  function getLoader() {
    if (!loader) {
      if (typeof THREE === 'undefined' || !THREE.GLTFLoader) {
        console.warn('[model-loader] THREE.GLTFLoader not found — check the <script> tags in index.html load order.');
        return null;
      }
      loader = new THREE.GLTFLoader();
    }
    return loader;
  }

  /**
   * Try to load a .glb from `url`. Resolves to the loaded THREE.Group
   * (gltf.scene) on success, or null if the file is missing / fails to
   * load (e.g. you haven't exported it yet) — callers should treat null
   * as "fall back to the box rig", not as an error to surface to the user.
   */
  function load(url) {
    const l = getLoader();
    if (!l) return Promise.resolve(null);
    return new Promise(resolve => {
      l.load(
        url,
        gltf => resolve(gltf.scene),
        undefined,
        err => {
          console.info(`[model-loader] No usable model at ${url} yet (this is fine — falling back to the box rig).`, err);
          resolve(null);
        }
      );
    });
  }

  /**
   * Once you've exported a .glb and know its real bone/node names
   * (open the file in Blender, or console.log(model) after load() and
   * walk model.traverse(...) in the browser devtools), fill these in.
   * Left empty on purpose — do not guess.
   */
  const BONE_NAME_MAP = {
    r6: {
      // 'Torso': 'YOUR_BLENDER_BONE_NAME_HERE',
      // 'Head': '...',
      // 'Left Arm': '...', 'Right Arm': '...',
      // 'Left Leg': '...', 'Right Leg': '...',
    },
    r15: {
      // 'LowerTorso': '...', 'UpperTorso': '...', 'Head': '...',
      // 'LeftUpperArm': '...', 'LeftLowerArm': '...', 'LeftHand': '...',
      // 'RightUpperArm': '...', 'RightLowerArm': '...', 'RightHand': '...',
      // 'LeftUpperLeg': '...', 'LeftLowerLeg': '...', 'LeftFoot': '...',
      // 'RightUpperLeg': '...', 'RightLowerLeg': '...', 'RightFoot': '...',
    }
  };

  /** Logs every node/bone name in a loaded model — run this first. */
  function dumpNodeNames(model) {
    const names = [];
    model.traverse(o => names.push(`${o.type}: ${o.name}`));
    console.log(`[model-loader] ${names.length} nodes found:\n` + names.join('\n'));
    return names;
  }

  return { load, dumpNodeNames, BONE_NAME_MAP };
})();
