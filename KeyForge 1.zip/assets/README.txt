Put your own exported models here:
  R6.glb
  R15.glb

Empty on purpose — add these yourself. Export from Blender:

  File > Export > glTF 2.0 (.glb/.gltf)
  Format: glTF Binary (.glb)
  Include: Selected Objects (select the rig + meshes first)

Save the result here as assets/R6.glb or assets/R15.glb.

The preview draws ONLY these files — with this folder empty it shows
nothing and prints why under the preview. Each must be a single .glb file.
