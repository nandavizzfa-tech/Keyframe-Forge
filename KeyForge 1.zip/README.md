# KeyForge

## Structure

```
Forge/
├── index.html          <- Page shell: markup + <link>/<script> tags only
├── css/
│   └── style.css       <- All the styling (was inline <style> before)
├── js/
│   ├── main.js          <- Everything the app does: parsing, the keyframe
│   │                        densifier, UI wiring, and the .glb preview
│   │                        (unchanged from before — just moved out of
│   │                        the HTML file)
│   └── model-loader.js  <- Loads assets/*.glb and finds each Roblox part
│                            (Torso, Left Arm, ...) inside it by name
├── assets/
│   └── README.txt       <- Where R6.glb / R15.glb go once you export them
└── README.md            <- This file
```

## Running it

Any static file host works (this domain, GitHub Pages, Netlify, a plain
`python3 -m http.server` for local testing, etc.) — there's no build step
and no server-side code. Just upload the whole `Forge/` folder and point
the domain at `index.html`.

Tip: open it over `http://` (your domain, or `python3 -m http.server` locally)
rather than double-clicking `index.html` — browsers block loading the .glb
from a `file://` page.

## What changed vs. the single-file version

The parsing, densifier and output generation are unchanged from the single-file version.

## The preview uses only your .glb files

`rebuildPreviewRig()` in `js/main.js` loads `assets/R6.glb` or
`assets/R15.glb` (matching the selected rig type). There is no fallback
model: if the file can't be loaded, nothing is drawn and the reason is
printed under the preview (red line starting with `Model (build 10):`).

What that line can tell you:

- `no file at assets/R6.glb (server said 404)` — not uploaded, or wrong
  folder/filename (case matters on most hosts: `R6.glb`, not `r6.glb`).
- `came back as a web page, not a model` — the host is answering with an
  error/blocked page instead of the file.
- `exists but couldn't be read as a GLB` — it must be ONE `.glb` file.
  Sketchfab often gives a `.zip` with `.gltf` + `.bin` + textures; pick
  the "glTF Binary (.glb)" download instead.
- `loaded ... but N parts didn't match a node` — the model loaded and is
  visible, but some Roblox part names (`Torso`, `Left Arm`, ...) weren't
  found in it. Open "Node names inside the model" under the preview to
  see what your file actually calls them, then map them in
  `BONE_NAME_MAP` in `js/model-loader.js`. Matching already ignores case,
  spaces, `_` and `.`, so `Left_Arm` / `LeftArm` / `left arm` all match
  `Left Arm` without any mapping.

Models that aren't roughly 5 studs tall are auto-scaled to fit and stood
on the grid; the status line says by how much. Keyframe position offsets
are compensated for that scale.

The `build N` number in that line changes with every release. If it's
missing or older than the zip you just uploaded, your browser is showing
a cached copy: hard-reload, or open the page with `?v=N` on the end.

Debug only: adding `?box=1` to the URL draws the old built-in box rig.

## Build 1

- Animation tweaks (applied to the generated script and the preview): mirror left/right, seamless loop, remove duplicate keyframes, speed multiplier, choose which parts are included.
- Copy and Download .lua buttons.
- Preview: scrubber, previous/next keyframe, speed 0.25x-2x, loop range. R15 is marked WIP.
- History (clock icon in the header): raw data + generated script, stored in this browser only. Entries older than 30 days are compressed and must be opened with "Open". Max 100 entries.
- 15 languages with search; 8 themes (Dark·Futuristic / Light·Minimal x Red, Blue, Green, Orange); custom dropdowns; wavy flags.
- Sample data: SampleWalk.
