/* ============================================================
   model-loader.js — loads assets/R6.glb / assets/R15.glb and finds
   the nodes inside it by Roblox part name.

   The preview uses ONLY these files. If a model can't be loaded, the
   preview shows the reason on the page (see #prevModelStatus in
   main.js) instead of silently drawing something else.
   ============================================================ */

const ModelLoader = (() => {
  let loader = null;
  function getLoader() {
    if (!loader) {
      if (typeof THREE === 'undefined' || !THREE.GLTFLoader) {
        console.warn('[model-loader] THREE.GLTFLoader not found — check the <script> tags in index.html load order.');
        return null;
      }
      loader = new THREE.GLTFLoader();
      // Sketchfab (and some Blender) exports can be Draco-compressed;
      // without this decoder those files fail to parse.
      if (THREE.DRACOLoader) {
        const draco = new THREE.DRACOLoader();
        draco.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.4.1/');
        loader.setDRACOLoader(draco);
      }
    }
    return loader;
  }

  /** Resolves to the loaded THREE.Group, or null on any failure. */
  function load(url) {
    return loadWithStatus(url).then(r => r.model);
  }

  /**
   * Same as load(), plus a short human-readable reason on failure, for
   * showing ON THE PAGE (the browser console isn't always reachable,
   * e.g. testing on a phone).
   */
  function loadWithStatus(url) {
    const l = getLoader();
    if (!l) return Promise.resolve({ model: null, status: 'THREE.GLTFLoader missing — check <script> tags in index.html' });
    return new Promise(resolve => {
      l.load(
        url,
        gltf => resolve({ model: gltf.scene, status: `loaded ${url}` }),
        undefined,
        err => {
          const detail = (err && err.message) ? err.message : '';
          // A HEAD request tells apart "not there" from "there but unreadable".
          fetch(url, { method: 'HEAD', cache: 'no-store' }).then(res => {
            const type = res.headers.get('content-type') || '';
            let reason;
            if (!res.ok) {
              reason = `no file at ${url} (server said ${res.status}) — check it's uploaded at exactly that path`;
            } else if (/text\/html/i.test(type)) {
              reason = `${url} came back as a web page, not a model — the host is serving a 404/blocked page instead of the file`;
            } else {
              reason = `${url} exists but couldn't be read as a GLB${detail ? ' (' + detail + ')' : ''} — it must be a single .glb, not a .zip or .gltf + .bin`;
            }
            console.info('[model-loader] ' + reason, err);
            resolve({ model: null, status: reason });
          }).catch(() => {
            resolve({ model: null, status: `couldn't reach ${url} at all (network or CORS)` });
          });
        }
      );
    });
  }

  /**
   * Roblox part name (e.g. "Left Arm") -> node name in YOUR file, for
   * when they don't already match. Matching already ignores case,
   * spaces, underscores and dots, so "Left Arm", "Left_Arm", "LeftArm"
   * and "left.arm" all find each other without an entry here.
   */
  const BONE_NAME_MAP = {
    r6: {
      // 'Torso': 'YOUR_NODE_NAME',
    },
    r15: {
      // 'UpperTorso': 'YOUR_NODE_NAME',
    }
  };

  function norm(s) { return String(s).toLowerCase().replace(/[^a-z0-9]/g, ''); }

  /**
   * Find a node by name. three.js rewrites spaces in node names to "_"
   * when it loads a GLB, so an exact lookup for "Left Arm" misses a node
   * that was exported as "Left Arm" — hence the tolerant match. If a bone
   * and a mesh share a name, the bone wins (it's what drives the skin).
   */
  function findNode(root, name) {
    const target = norm(name);
    let firstMatch = null, boneMatch = null;
    root.traverse(o => {
      if (!o.name || norm(o.name) !== target) return;
      if (!firstMatch) firstMatch = o;
      if (!boneMatch && o.isBone) boneMatch = o;
    });
    return boneMatch || firstMatch;
  }

  /** "Type: name" for every named node — shown on the page when parts don't match. */
  function listNodeNames(model) {
    const out = [];
    model.traverse(o => { if (o.name) out.push(`${o.type}: ${o.name}`); });
    return out;
  }

  return { load, loadWithStatus, findNode, listNodeNames, BONE_NAME_MAP };
})();
