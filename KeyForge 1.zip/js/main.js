(() => {
const $ = id => document.getElementById(id);
const APP_VERSION = '1';

/* ---------- FLAGS (custom inline SVG) ---------- */
const sv = b => '<svg viewBox="0 0 30 20" preserveAspectRatio="none">' + b + '</svg>';
const rc = (x, y, w, h, f) => '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + f + '"/>';
const dot = (cx, cy, r, f) => '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + f + '"/>';
const H = c => sv(c.map((f, i) => rc(0, (i * 20 / c.length).toFixed(2), 30, (20 / c.length + .05).toFixed(2), f)).join(''));
const V = c => sv(c.map((f, i) => rc((i * 30 / c.length).toFixed(2), 0, (30 / c.length + .05).toFixed(2), 20, f)).join(''));
const star = (cx, cy, r, f) => '<polygon fill="' + f + '" points="' + [...Array(10).keys()].map(i => { const a = Math.PI / 5 * i - Math.PI / 2, R = i % 2 ? r * .4 : r; return (cx + R * Math.cos(a)).toFixed(2) + ',' + (cy + R * Math.sin(a)).toFixed(2); }).join(' ') + '"/>';
const bars = (n, a, b, cw, ch, cf, extra) => { let s = ''; for (let i = 0; i < n; i++) s += rc(0, (i * 20 / n).toFixed(2), 30, (20 / n + .05).toFixed(2), i % 2 ? b : a); return sv(s + rc(0, 0, cw, ch, cf) + extra); };
const FLAGS = {
  'en-US': (() => { let x = ''; for (let r = 0; r < 5; r++) for (let c = 0; c < 6; c++) x += dot((1.4 + c * 2.05).toFixed(2), (1.3 + r * 1.95).toFixed(2), .5, '#fff'); return bars(13, '#b22234', '#fff', 13, 10.77, '#3c3b6e', x); })(),
  'en-GB': sv(rc(0, 0, 30, 20, '#fff') + rc(12.5, 0, 5, 20, '#ce1124') + rc(0, 7.5, 30, 5, '#ce1124')),
  'id': H(['#e70011', '#fff']),
  'ms': bars(14, '#cc0001', '#fff', 15, 10, '#010066', dot(6, 5, 3.4, '#fc0') + dot(7, 5, 2.8, '#010066') + star(10.8, 5, 2.3, '#fc0')),
  'fil': H(['#0038a8', '#ce1126']).replace('</svg>', '<polygon points="0,0 13,10 0,20" fill="#fff"/>' + dot(3.6, 10, 1.6, '#fcd116') + '</svg>'),
  'es': sv(rc(0, 0, 30, 20, '#c60b1e') + rc(0, 5, 30, 10, '#ffc400')),
  'pt-BR': sv(rc(0, 0, 30, 20, '#009b3a') + '<polygon points="15,2 27,10 15,18 3,10" fill="#fedf00"/>' + dot(15, 10, 4.2, '#002776') + '<path d="M10.8 9.2Q15 7.6 19.2 11.2" stroke="#fff" stroke-width=".9" fill="none"/>'),
  'fr': V(['#0055a4', '#fff', '#ef4135']),
  'de': H(['#000', '#dd0000', '#ffce00']),
  'it': V(['#009246', '#fff', '#ce2b37']),
  'nl': H(['#ae1c28', '#fff', '#21468b']),
  'pl': H(['#fff', '#dc143c']),
  'ru': H(['#fff', '#0039a6', '#d52b1e']),
  'tr': sv(rc(0, 0, 30, 20, '#e30a17') + dot(11, 10, 5, '#fff') + dot(12.4, 10, 4, '#e30a17') + star(15.4, 10, 2.4, '#fff')),
  'ar': H(['#ce1126', '#fff', '#000']).replace('</svg>', dot(15, 10, 1.8, '#c09300') + '</svg>'),
  'hi': H(['#ff9933', '#fff', '#138808']).replace('</svg>', '<circle cx="15" cy="10" r="2.4" fill="none" stroke="#000080" stroke-width=".5"/></svg>'),
  'th': sv(rc(0, 0, 30, 3.4, '#a51931') + rc(0, 3.3, 30, 3.4, '#f4f5f8') + rc(0, 6.6, 30, 6.8, '#2d2a4a') + rc(0, 13.3, 30, 3.4, '#f4f5f8') + rc(0, 16.6, 30, 3.4, '#a51931')),
  'vi': sv(rc(0, 0, 30, 20, '#da251d') + star(15, 10.6, 6, '#ff0')),
  'ja': sv(rc(0, 0, 30, 20, '#fff') + dot(15, 10, 6, '#bc002d')),
  'ko': sv(rc(0, 0, 30, 20, '#fff') + '<path d="M9 10A6 6 0 0 1 21 10Z" fill="#cd2e3a"/><path d="M21 10A6 6 0 0 1 9 10Z" fill="#0047a0"/>' + rc(2.5, 2.5, 4, .9, '#000') + rc(23.5, 2.5, 4, .9, '#000') + rc(2.5, 16.6, 4, .9, '#000') + rc(23.5, 16.6, 4, .9, '#000')),
  'zh-CN': sv(rc(0, 0, 30, 20, '#de2910') + star(5, 5.2, 3.2, '#ffde00') + star(10, 2.4, 1, '#ffde00') + star(12, 4.6, 1, '#ffde00') + star(12, 7.4, 1, '#ffde00') + star(10, 9.4, 1, '#ffde00'))
};
const LANGS_ALL = [
  { code: 'en-US', label: 'English (US)', en: 'English (US)', short: 'US' },
  { code: 'en-GB', label: 'English (England)', en: 'English (England)', short: 'ENG' },
  { code: 'id', label: 'Bahasa Indonesia', en: 'Indonesian', short: 'ID' },
  { code: 'ms', label: 'Bahasa Melayu', en: 'Malay', short: 'MS' },
  { code: 'fil', label: 'Filipino', en: 'Filipino', short: 'FIL' },
  { code: 'es', label: 'Español', en: 'Spanish', short: 'ES' },
  { code: 'pt-BR', label: 'Português (Brasil)', en: 'Portuguese', short: 'BR' },
  { code: 'fr', label: 'Français', en: 'French', short: 'FR' },
  { code: 'de', label: 'Deutsch', en: 'German', short: 'DE' },
  { code: 'it', label: 'Italiano', en: 'Italian', short: 'IT' },
  { code: 'nl', label: 'Nederlands', en: 'Dutch', short: 'NL' },
  { code: 'pl', label: 'Polski', en: 'Polish', short: 'PL' },
  { code: 'ru', label: 'Русский', en: 'Russian', short: 'RU' },
  { code: 'tr', label: 'Türkçe', en: 'Turkish', short: 'TR' },
  { code: 'ar', label: 'العربية', en: 'Arabic', short: 'AR', rtl: true },
  { code: 'hi', label: 'हिन्दी', en: 'Hindi', short: 'HI' },
  { code: 'th', label: 'ไทย', en: 'Thai', short: 'TH' },
  { code: 'vi', label: 'Tiếng Việt', en: 'Vietnamese', short: 'VI' },
  { code: 'ja', label: '日本語', en: 'Japanese', short: 'JA' },
  { code: 'ko', label: '한국어', en: 'Korean', short: 'KO' },
  { code: 'zh-CN', label: '中文 (简体)', en: 'Chinese', short: 'ZH' }
];

/* ---------- EXPLORER ICONS (custom inline SVG) ---------- */
const I = p => '<svg viewBox="0 0 24 24" aria-hidden="true">' + p + '</svg>';
const SVC_ICONS = {
  ServerScriptService: I('<rect x="3" y="4" width="18" height="6.5" rx="1.6"/><rect x="3" y="13.5" width="18" height="6.5" rx="1.6"/><path d="M7 7.25h.01M7 16.75h.01M11 7.25h6M11 16.75h6"/>'),
  ServerStorage: I('<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"/>'),
  ReplicatedStorage: I('<path d="M4 11a8 8 0 0 1 14-4.5L20 9M20 4.5V9h-4.5M20 13a8 8 0 0 1-14 4.5L4 15M4 19.5V15h4.5"/>'),
  Workspace: I('<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>'),
  ReplicatedFirst: I('<path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z"/>'),
  Lighting: I('<circle cx="12" cy="12" r="4"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>'),
  StarterPack: I('<path d="M8.5 7V5.5a3.5 3.5 0 0 1 7 0V7"/><rect x="5" y="7" width="14" height="14" rx="3.5"/><path d="M9 14h6"/>'),
  StarterGui: I('<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 8.5h18M8 21.5h8M12 18v3.5"/>'),
  StarterPlayer: I('<circle cx="12" cy="8" r="4"/><path d="M4.5 21c.5-4 3.6-6.5 7.5-6.5s7 2.5 7.5 6.5"/>')
};
const FOLDER_ICON = I('<path d="M3 7.5A2 2 0 0 1 5 5.5h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" fill="currentColor" fill-opacity=".22"/>');
const SEQ_ICON = I('<path d="M3 12h4M17 12h4"/><path d="M12 5l5 7-5 7-5-7z" style="fill:var(--acc);fill-opacity:.3;stroke:var(--acc)"/>');

/* ---------- TRANSLATIONS ---------- */
const T = {
'en-US': {
  rigAuto: 'Auto-detect', rigR6: 'R6', rigR15: 'R15', rigWipBadge: 'WIP',
  rigWipNote: 'R15 support is a work in progress — nothing to set up on your end, just check back later.',
  prevDragHint: 'Drag = rotate · Scroll = zoom',
  prevAssetsNote: 'Preview loads straight from your own assets/R6.glb.',
  tagline: 'Turn raw animation data into a ready-to-paste KeyframeSequence script.',
  tabData: 'Data', tabConfig: 'Config', tabOutput: 'Output',
  rawTitle: 'Raw data', rawPh: 'Paste your animation data here…',
  generate: 'Parse & generate', sample: 'Load sample', clear: 'Clear',
  destTitle: 'Destination', service: 'Service', folders: 'Folders inside the service, in order',
  addFolder: 'Add folder', noFolder: 'No folders. The sequence goes straight into the service.',
  folderPh: 'Folder name, e.g. Anim', removeFolder: 'Remove folder', pathPrev: 'Location preview',
  folderNote: 'Create these folders manually in Studio. The script only looks them up with FindFirstChild and never creates them.',
  optTitle: 'Options', seqName: 'Sequence name', seqNamePh: 'Taken from the data', priority: 'Priority', loop: 'Loop',
  outTitle: 'Output', outLabel: 'ServerScript · Luau', lines: '{n} lines',
  outPh: '-- Your script will appear here after parsing.', copy: 'Copy script', copied: 'Copied', goOutput: 'View output',
  settings: 'Settings', setupTitle: 'Interface settings', setupSub: 'Pick a theme and a language. You can change them any time.',
  theme: 'Theme', themeDark: 'Dark · Futuristic', themeLight: 'Light · Minimal',
  accentHint: 'Pick a mode and an accent color.',
  red: 'Red', blue: 'Blue', green: 'Green', orange: 'Orange', language: 'Language', done: 'Done',
  errEmpty: 'The raw data is empty. Paste it first.',
  errNoKf: 'No "[Keyframe N] t=…" lines could be read. Check that the format matches the animation dump.',
  errNum: 'Invalid number: {v}',
  warnBad: '{n} lines were not recognized and were skipped.',
  warnCount: 'The header says {a} keyframes, but {b} were read.',
  warnDur: 'The header duration ({a}s) differs from the last keyframe ({b}s).',
  warnEmpty: '{n} keyframes contain no poses.',
  chipName: 'Name', chipDur: 'Duration', chipKf: 'Keyframes', chipPose: 'Poses', chipLoop: 'Loop (data)', yes: 'Yes', no: 'No',
  madeBy: 'Made by',
  creditDesc: 'A website that converts raw animation data into a native KeyframeSequence, the raw form of a Roblox animation.',
  creditPrivacy: 'Everything runs in your browser. Your animation data is never uploaded.',
  creditFonts: 'Fonts: Orbitron and Share Tech Mono. Icons and flags: custom SVG.',
  creditDisclaimer: 'Not affiliated with, endorsed by, or sponsored by Roblox Corporation.'
},
'en-GB': {
  accentHint: 'Pick a mode and an accent colour.',
  warnBad: '{n} lines were not recognised and were skipped.'
},
'id': {
  rigAuto: 'Deteksi otomatis', rigR6: 'R6', rigR15: 'R15', rigWipBadge: 'WIP',
  rigWipNote: 'Dukungan R15 masih dalam pengembangan — nggak perlu kamu siapkan apa-apa, cek lagi nanti.',
  prevDragHint: 'Drag = putar · Scroll = zoom',
  prevAssetsNote: 'Preview diambil langsung dari assets/R6.glb milikmu.',
  tagline: 'Ubah data animasi mentah menjadi script KeyframeSequence siap tempel.',
  tabData: 'Data', tabConfig: 'Atur', tabOutput: 'Hasil',
  rawTitle: 'Data mentah', rawPh: 'Tempel data animasi di sini…',
  generate: 'Parse & buat', sample: 'Muat contoh', clear: 'Bersihkan',
  destTitle: 'Lokasi tujuan', service: 'Service', folders: 'Folder di dalam service, berurutan',
  addFolder: 'Tambah folder', noFolder: 'Tanpa folder. Sequence langsung masuk ke service.',
  folderPh: 'Nama folder, mis. Anim', removeFolder: 'Hapus folder', pathPrev: 'Pratinjau lokasi',
  folderNote: 'Buat folder ini secara manual di Studio. Script hanya mencarinya dengan FindFirstChild dan tidak pernah membuatnya.',
  optTitle: 'Opsi', seqName: 'Nama sequence', seqNamePh: 'Diambil dari data', priority: 'Priority', loop: 'Loop',
  outTitle: 'Hasil', outLabel: 'ServerScript · Luau', lines: '{n} baris',
  outPh: '-- Script akan muncul di sini setelah data diparse.', copy: 'Salin script', copied: 'Tersalin', goOutput: 'Lihat hasil',
  settings: 'Pengaturan', setupTitle: 'Pengaturan tampilan', setupSub: 'Pilih tema dan bahasa. Bisa diubah kapan saja.',
  theme: 'Tema', themeDark: 'Gelap · Futuristik', themeLight: 'Terang · Minimalis',
  accentHint: 'Pilih mode dan warna aksen.',
  red: 'Merah', blue: 'Biru', green: 'Hijau', orange: 'Oranye', language: 'Bahasa', done: 'Selesai',
  errEmpty: 'Data mentah masih kosong. Tempel dulu datanya.',
  errNoKf: 'Tidak ada baris "[Keyframe N] t=…" yang terbaca. Pastikan formatnya sama seperti dump animasi.',
  errNum: 'Angka tidak valid: {v}',
  warnBad: '{n} baris tidak dikenali dan dilewati.',
  warnCount: 'Header menyebut {a} keyframe, tetapi yang terbaca {b}.',
  warnDur: 'Durasi di header ({a}s) berbeda dengan keyframe terakhir ({b}s).',
  warnEmpty: '{n} keyframe tidak memiliki pose.',
  chipName: 'Nama', chipDur: 'Durasi', chipKf: 'Keyframe', chipPose: 'Pose', chipLoop: 'Loop (data)', yes: 'Ya', no: 'Tidak',
  madeBy: 'Dibuat oleh',
  creditDesc: 'Situs web untuk mengubah data mentah animasi menjadi KeyframeSequence asli, bentuk mentah dari animasi Roblox.',
  creditPrivacy: 'Semua proses berjalan di browser kamu. Data animasimu tidak pernah diunggah.',
  creditFonts: 'Font: Orbitron dan Share Tech Mono. Ikon dan bendera: SVG buatan sendiri.',
  creditDisclaimer: 'Tidak berafiliasi dengan, didukung oleh, atau disponsori oleh Roblox Corporation.'
},
'es': {
  rigAuto: 'Detección automática', rigR6: 'R6', rigR15: 'R15', rigWipBadge: 'WIP',
  rigWipNote: 'El soporte de R15 sigue en desarrollo — no necesitas preparar nada, vuelve a comprobarlo más tarde.',
  prevDragHint: 'Arrastrar = girar · Rueda = zoom',
  prevAssetsNote: 'La vista previa se carga directamente desde tu assets/R6.glb.',
  tagline: 'Convierte datos de animación en bruto en un script KeyframeSequence listo para pegar.',
  tabData: 'Datos', tabConfig: 'Ajustes', tabOutput: 'Salida',
  rawTitle: 'Datos en bruto', rawPh: 'Pega aquí los datos de tu animación…',
  generate: 'Analizar y generar', sample: 'Cargar ejemplo', clear: 'Borrar',
  destTitle: 'Destino', service: 'Servicio', folders: 'Carpetas dentro del servicio, en orden',
  addFolder: 'Añadir carpeta', noFolder: 'Sin carpetas. La secuencia va directamente al servicio.',
  folderPh: 'Nombre de carpeta, p. ej. Anim', removeFolder: 'Quitar carpeta', pathPrev: 'Vista previa de la ubicación',
  folderNote: 'Crea estas carpetas manualmente en Studio. El script solo las busca con FindFirstChild y nunca las crea.',
  optTitle: 'Opciones', seqName: 'Nombre de la secuencia', seqNamePh: 'Tomado de los datos', priority: 'Prioridad', loop: 'Bucle',
  outTitle: 'Salida', outLabel: 'ServerScript · Luau', lines: '{n} líneas',
  outPh: '-- Tu script aparecerá aquí tras analizar los datos.', copy: 'Copiar script', copied: 'Copiado', goOutput: 'Ver salida',
  settings: 'Ajustes', setupTitle: 'Ajustes de interfaz', setupSub: 'Elige un tema y un idioma. Puedes cambiarlos cuando quieras.',
  theme: 'Tema', themeDark: 'Oscuro · Futurista', themeLight: 'Claro · Minimalista',
  accentHint: 'Elige un modo y un color de acento.',
  red: 'Rojo', blue: 'Azul', green: 'Verde', orange: 'Naranja', language: 'Idioma', done: 'Listo',
  errEmpty: 'Los datos en bruto están vacíos. Pégalos primero.',
  errNoKf: 'No se pudo leer ninguna línea "[Keyframe N] t=…". Comprueba que el formato coincida con el volcado de la animación.',
  errNum: 'Número no válido: {v}',
  warnBad: 'Se omitieron {n} líneas no reconocidas.',
  warnCount: 'El encabezado indica {a} keyframes, pero se leyeron {b}.',
  warnDur: 'La duración del encabezado ({a}s) difiere del último keyframe ({b}s).',
  warnEmpty: '{n} keyframes no contienen poses.',
  chipName: 'Nombre', chipDur: 'Duración', chipKf: 'Keyframes', chipPose: 'Poses', chipLoop: 'Bucle (datos)', yes: 'Sí', no: 'No',
  madeBy: 'Hecho por',
  creditDesc: 'Un sitio web que convierte datos de animación en bruto en una KeyframeSequence nativa, la forma en bruto de una animación de Roblox.',
  creditPrivacy: 'Todo se ejecuta en tu navegador. Tus datos de animación nunca se suben.',
  creditFonts: 'Fuentes: Orbitron y Share Tech Mono. Iconos y banderas: SVG propios.',
  creditDisclaimer: 'No está afiliado, respaldado ni patrocinado por Roblox Corporation.'
},
'pt-BR': {
  rigAuto: 'Detecção automática', rigR6: 'R6', rigR15: 'R15', rigWipBadge: 'WIP',
  rigWipNote: 'O suporte a R15 ainda está em desenvolvimento — você não precisa preparar nada, volte a conferir depois.',
  prevDragHint: 'Arrastar = girar · Rolagem = zoom',
  prevAssetsNote: 'A prévia carrega direto do seu assets/R6.glb.',
  tagline: 'Transforme dados brutos de animação em um script KeyframeSequence pronto para colar.',
  tabData: 'Dados', tabConfig: 'Ajustes', tabOutput: 'Saída',
  rawTitle: 'Dados brutos', rawPh: 'Cole aqui os dados da sua animação…',
  generate: 'Analisar e gerar', sample: 'Carregar exemplo', clear: 'Limpar',
  destTitle: 'Destino', service: 'Serviço', folders: 'Pastas dentro do serviço, em ordem',
  addFolder: 'Adicionar pasta', noFolder: 'Sem pastas. A sequência vai direto para o serviço.',
  folderPh: 'Nome da pasta, ex.: Anim', removeFolder: 'Remover pasta', pathPrev: 'Prévia do local',
  folderNote: 'Crie essas pastas manualmente no Studio. O script só as procura com FindFirstChild e nunca as cria.',
  optTitle: 'Opções', seqName: 'Nome da sequência', seqNamePh: 'Obtido dos dados', priority: 'Prioridade', loop: 'Loop',
  outTitle: 'Saída', outLabel: 'ServerScript · Luau', lines: '{n} linhas',
  outPh: '-- Seu script aparecerá aqui após a análise.', copy: 'Copiar script', copied: 'Copiado', goOutput: 'Ver saída',
  settings: 'Ajustes', setupTitle: 'Configurações da interface', setupSub: 'Escolha um tema e um idioma. Você pode mudar quando quiser.',
  theme: 'Tema', themeDark: 'Escuro · Futurista', themeLight: 'Claro · Minimalista',
  accentHint: 'Escolha um modo e uma cor de destaque.',
  red: 'Vermelho', blue: 'Azul', green: 'Verde', orange: 'Laranja', language: 'Idioma', done: 'Concluir',
  errEmpty: 'Os dados brutos estão vazios. Cole-os primeiro.',
  errNoKf: 'Nenhuma linha "[Keyframe N] t=…" pôde ser lida. Verifique se o formato corresponde ao dump da animação.',
  errNum: 'Número inválido: {v}',
  warnBad: '{n} linhas não reconhecidas foram ignoradas.',
  warnCount: 'O cabeçalho indica {a} keyframes, mas {b} foram lidos.',
  warnDur: 'A duração do cabeçalho ({a}s) difere do último keyframe ({b}s).',
  warnEmpty: '{n} keyframes não têm poses.',
  chipName: 'Nome', chipDur: 'Duração', chipKf: 'Keyframes', chipPose: 'Poses', chipLoop: 'Loop (dados)', yes: 'Sim', no: 'Não',
  madeBy: 'Feito por',
  creditDesc: 'Um site que converte dados brutos de animação em uma KeyframeSequence nativa, a forma bruta de uma animação do Roblox.',
  creditPrivacy: 'Tudo roda no seu navegador. Seus dados de animação nunca são enviados.',
  creditFonts: 'Fontes: Orbitron e Share Tech Mono. Ícones e bandeiras: SVG próprios.',
  creditDisclaimer: 'Não é afiliado, endossado nem patrocinado pela Roblox Corporation.'
},
'de': {
  rigAuto: 'Automatische Erkennung', rigR6: 'R6', rigR15: 'R15', rigWipBadge: 'WIP',
  rigWipNote: 'Die R15-Unterstützung ist noch in Arbeit — du musst nichts einrichten, schau später einfach noch mal vorbei.',
  prevDragHint: 'Ziehen = drehen · Scrollen = Zoom',
  prevAssetsNote: 'Die Vorschau lädt direkt aus deiner eigenen assets/R6.glb.',
  tagline: 'Verwandle rohe Animationsdaten in ein fertiges KeyframeSequence-Skript zum Einfügen.',
  tabData: 'Daten', tabConfig: 'Setup', tabOutput: 'Ausgabe',
  rawTitle: 'Rohdaten', rawPh: 'Füge hier deine Animationsdaten ein…',
  generate: 'Parsen & erzeugen', sample: 'Beispiel laden', clear: 'Leeren',
  destTitle: 'Ziel', service: 'Service', folders: 'Ordner im Service, der Reihe nach',
  addFolder: 'Ordner hinzufügen', noFolder: 'Keine Ordner. Die Sequenz kommt direkt in den Service.',
  folderPh: 'Ordnername, z. B. Anim', removeFolder: 'Ordner entfernen', pathPrev: 'Vorschau des Ortes',
  folderNote: 'Lege diese Ordner manuell in Studio an. Das Skript sucht sie nur mit FindFirstChild und erstellt sie nie.',
  optTitle: 'Optionen', seqName: 'Name der Sequenz', seqNamePh: 'Aus den Daten übernommen', priority: 'Priorität', loop: 'Loop',
  outTitle: 'Ausgabe', outLabel: 'ServerScript · Luau', lines: '{n} Zeilen',
  outPh: '-- Dein Skript erscheint hier nach dem Parsen.', copy: 'Skript kopieren', copied: 'Kopiert', goOutput: 'Ausgabe ansehen',
  settings: 'Einstellungen', setupTitle: 'Oberflächen-Einstellungen', setupSub: 'Wähle ein Theme und eine Sprache. Du kannst beides jederzeit ändern.',
  theme: 'Theme', themeDark: 'Dunkel · Futuristisch', themeLight: 'Hell · Minimalistisch',
  accentHint: 'Wähle einen Modus und eine Akzentfarbe.',
  red: 'Rot', blue: 'Blau', green: 'Grün', orange: 'Orange', language: 'Sprache', done: 'Fertig',
  errEmpty: 'Die Rohdaten sind leer. Füge sie zuerst ein.',
  errNoKf: 'Es konnte keine Zeile "[Keyframe N] t=…" gelesen werden. Prüfe, ob das Format zum Animations-Dump passt.',
  errNum: 'Ungültige Zahl: {v}',
  warnBad: '{n} nicht erkannte Zeilen wurden übersprungen.',
  warnCount: 'Der Header nennt {a} Keyframes, gelesen wurden aber {b}.',
  warnDur: 'Die Dauer im Header ({a}s) weicht vom letzten Keyframe ({b}s) ab.',
  warnEmpty: '{n} Keyframes enthalten keine Posen.',
  chipName: 'Name', chipDur: 'Dauer', chipKf: 'Keyframes', chipPose: 'Posen', chipLoop: 'Loop (Daten)', yes: 'Ja', no: 'Nein',
  madeBy: 'Erstellt von',
  creditDesc: 'Eine Website, die rohe Animationsdaten in eine native KeyframeSequence umwandelt, die Rohform einer Roblox-Animation.',
  creditPrivacy: 'Alles läuft in deinem Browser. Deine Animationsdaten werden nie hochgeladen.',
  creditFonts: 'Schriften: Orbitron und Share Tech Mono. Symbole und Flaggen: eigene SVGs.',
  creditDisclaimer: 'Nicht mit Roblox Corporation verbunden, von ihr unterstützt oder gesponsert.'
}
};

/* ---------- EXTRA TRANSLATIONS ---------- */
Object.entries({
  'en-US': { searchLang: 'Search language…', noLang: 'No language found', expandLang: 'Expand', resetName: 'Reset to data name' },
  'id': { searchLang: 'Cari bahasa…', noLang: 'Bahasa tidak ditemukan', expandLang: 'Perbesar', resetName: 'Kembalikan ke nama dari data' },
  'es': { searchLang: 'Buscar idioma…', noLang: 'No se encontró ningún idioma', expandLang: 'Ampliar', resetName: 'Restaurar nombre de los datos' },
  'pt-BR': { searchLang: 'Buscar idioma…', noLang: 'Nenhum idioma encontrado', expandLang: 'Ampliar', resetName: 'Restaurar nome dos dados' },
  'de': { searchLang: 'Sprache suchen…', noLang: 'Keine Sprache gefunden', expandLang: 'Vergrößern', resetName: 'Auf Datennamen zurücksetzen' }
}).forEach(([k, v]) => Object.assign(T[k], v));
const KEYS = 'rigAuto rigWipNote prevDragHint tagline tabData tabConfig tabOutput rawTitle rawPh generate sample clear destTitle folders addFolder noFolder folderPh removeFolder pathPrev folderNote optTitle seqName seqNamePh outTitle lines outPh copy copied goOutput settings setupTitle setupSub theme themeDark themeLight accentHint red blue green orange language done errEmpty errNoKf errNum warnBad warnCount warnDur warnEmpty chipName chipDur chipKf chipPose chipLoop yes no madeBy creditDesc creditPrivacy creditFonts creditDisclaimer searchLang noLang expandLang resetName preview'.split(' ');
const addLang = (code, vals, over) => { const o = {}; KEYS.forEach((k, i) => o[k] = vals[i]); T[code] = Object.assign(o, over || {}); };
Object.entries({ 'en-US': 'Preview', 'id': 'Pratinjau', 'es': 'Vista previa', 'pt-BR': 'Prévia', 'de': 'Vorschau' }).forEach(([k, v]) => { T[k].preview = v; });
addLang('ms', ['Kesan automatik', 'Sokongan R15 masih dalam pembangunan — tiada apa yang perlu disediakan, semak semula nanti.', 'Seret = putar · Tatal = zum', 'Tukar data animasi mentah kepada skrip KeyframeSequence yang sedia untuk ditampal.', 'Data', 'Tetapan', 'Output', 'Data mentah', 'Tampal data animasi anda di sini…', 'Parse & jana', 'Muat contoh', 'Kosongkan', 'Destinasi', 'Folder dalam service, mengikut susunan', 'Tambah folder', 'Tiada folder. Sequence terus masuk ke service.', 'Nama folder, cth. Anim', 'Buang folder', 'Pratonton lokasi', 'Cipta folder ini secara manual dalam Studio. Skrip hanya mencarinya dengan FindFirstChild dan tidak pernah mencipta.', 'Pilihan', 'Nama sequence', 'Diambil daripada data', 'Output', '{n} baris', '-- Skrip anda akan muncul di sini selepas data diparse.', 'Salin skrip', 'Disalin', 'Lihat output', 'Tetapan', 'Tetapan antara muka', 'Pilih tema dan bahasa. Boleh ditukar bila-bila masa.', 'Tema', 'Gelap · Futuristik', 'Cerah · Minimalis', 'Pilih mod dan warna aksen.', 'Merah', 'Biru', 'Hijau', 'Oren', 'Bahasa', 'Siap', 'Data mentah kosong. Tampal dahulu.', 'Tiada baris "[Keyframe N] t=…" dapat dibaca. Pastikan format sama seperti dump animasi.', 'Nombor tidak sah: {v}', '{n} baris tidak dikenali dan dilangkau.', 'Header menyatakan {a} keyframe, tetapi {b} dibaca.', 'Tempoh header ({a}s) berbeza daripada keyframe terakhir ({b}s).', '{n} keyframe tidak mengandungi pose.', 'Nama', 'Tempoh', 'Keyframe', 'Pose', 'Loop (data)', 'Ya', 'Tidak', 'Dibuat oleh', 'Laman web yang menukar data animasi mentah kepada KeyframeSequence asli, bentuk mentah animasi Roblox.', 'Semuanya berjalan dalam pelayar anda. Data animasi anda tidak pernah dimuat naik.', 'Fon: Orbitron dan Share Tech Mono. Ikon dan bendera: SVG buatan sendiri.', 'Tidak berafiliasi dengan, disokong oleh, atau ditaja oleh Roblox Corporation.', 'Cari bahasa…', 'Bahasa tidak ditemui', 'Besarkan', 'Pulihkan nama daripada data', 'Pratonton']);
addLang('fil', ['Awtomatikong tuklasin', 'Ang suporta sa R15 ay ginagawa pa — wala kang kailangang ihanda, balikan na lang mamaya.', 'I-drag = ikot · Scroll = zoom', 'I-convert ang raw na animation data sa KeyframeSequence script na handa nang i-paste.', 'Data', 'Setting', 'Output', 'Raw na data', 'I-paste dito ang animation data mo…', 'I-parse at gumawa', 'Mag-load ng sample', 'Burahin', 'Destinasyon', 'Mga folder sa loob ng service, ayon sa pagkakasunod', 'Magdagdag ng folder', 'Walang folder. Diretso sa service ang sequence.', 'Pangalan ng folder, hal. Anim', 'Alisin ang folder', 'Preview ng lokasyon', 'Gawin mo mismo ang mga folder na ito sa Studio. Hinahanap lang ito ng script gamit ang FindFirstChild at hindi ito gumagawa.', 'Mga opsyon', 'Pangalan ng sequence', 'Kinuha mula sa data', 'Output', '{n} linya', '-- Lalabas dito ang script mo pagkatapos i-parse.', 'Kopyahin ang script', 'Nakopya', 'Tingnan ang output', 'Setting', 'Mga setting ng interface', 'Pumili ng tema at wika. Puwede mong palitan anumang oras.', 'Tema', 'Madilim · Futuristic', 'Maliwanag · Minimalist', 'Pumili ng mode at accent color.', 'Pula', 'Asul', 'Berde', 'Kahel', 'Wika', 'Tapos na', 'Walang laman ang raw na data. I-paste muna.', 'Walang nabasang linyang "[Keyframe N] t=…". Tiyaking kapareho ng animation dump ang format.', 'Di-wastong numero: {v}', '{n} linyang hindi nakilala ang nilaktawan.', 'Sabi ng header ay {a} keyframe, pero {b} ang nabasa.', 'Ang tagal sa header ({a}s) ay iba sa huling keyframe ({b}s).', '{n} keyframe ang walang pose.', 'Pangalan', 'Tagal', 'Keyframe', 'Pose', 'Loop (data)', 'Oo', 'Hindi', 'Ginawa ni', 'Isang website na nagko-convert ng raw na animation data tungo sa native na KeyframeSequence, ang raw na anyo ng Roblox animation.', 'Lahat ay tumatakbo sa browser mo. Hindi kailanman ina-upload ang animation data mo.', 'Mga font: Orbitron at Share Tech Mono. Mga icon at bandila: sariling SVG.', 'Hindi kaanib, inendorso, o sinponsoran ng Roblox Corporation.', 'Maghanap ng wika…', 'Walang nahanap na wika', 'Palakihin', 'Ibalik sa pangalan mula sa data', 'Preview']);
addLang('fr', ['Détection auto', 'La prise en charge de R15 est en cours de développement — rien à préparer, revenez plus tard.', 'Glisser = tourner · Molette = zoom', 'Transformez des données d’animation brutes en script KeyframeSequence prêt à coller.', 'Données', 'Réglages', 'Sortie', 'Données brutes', 'Collez ici vos données d’animation…', 'Analyser et générer', 'Charger un exemple', 'Effacer', 'Destination', 'Dossiers dans le service, dans l’ordre', 'Ajouter un dossier', 'Aucun dossier. La séquence va directement dans le service.', 'Nom du dossier, p. ex. Anim', 'Retirer le dossier', 'Aperçu de l’emplacement', 'Créez ces dossiers manuellement dans Studio. Le script ne fait que les chercher avec FindFirstChild et ne les crée jamais.', 'Options', 'Nom de la séquence', 'Repris des données', 'Sortie', '{n} lignes', '-- Votre script apparaîtra ici après l’analyse.', 'Copier le script', 'Copié', 'Voir la sortie', 'Réglages', 'Réglages de l’interface', 'Choisissez un thème et une langue. Modifiables à tout moment.', 'Thème', 'Sombre · Futuriste', 'Clair · Minimaliste', 'Choisissez un mode et une couleur d’accent.', 'Rouge', 'Bleu', 'Vert', 'Orange', 'Langue', 'Terminé', 'Les données brutes sont vides. Collez-les d’abord.', 'Aucune ligne "[Keyframe N] t=…" lisible. Vérifiez que le format correspond au dump d’animation.', 'Nombre invalide : {v}', '{n} lignes non reconnues ont été ignorées.', 'L’en-tête indique {a} keyframes, mais {b} ont été lues.', 'La durée de l’en-tête ({a}s) diffère du dernier keyframe ({b}s).', '{n} keyframes ne contiennent aucune pose.', 'Nom', 'Durée', 'Keyframes', 'Poses', 'Boucle (données)', 'Oui', 'Non', 'Créé par', 'Un site qui convertit des données d’animation brutes en KeyframeSequence native, la forme brute d’une animation Roblox.', 'Tout s’exécute dans votre navigateur. Vos données d’animation ne sont jamais envoyées.', 'Polices : Orbitron et Share Tech Mono. Icônes et drapeaux : SVG maison.', 'Non affilié à Roblox Corporation, ni approuvé ou sponsorisé par elle.', 'Rechercher une langue…', 'Aucune langue trouvée', 'Agrandir', 'Rétablir le nom des données', 'Aperçu'], { priority: 'Priorité', loop: 'Boucle' });
addLang('it', ['Rilevamento automatico', 'Il supporto R15 è ancora in sviluppo — non devi preparare nulla, ricontrolla più tardi.', 'Trascina = ruota · Scorri = zoom', 'Trasforma i dati grezzi di animazione in uno script KeyframeSequence pronto da incollare.', 'Dati', 'Opzioni', 'Output', 'Dati grezzi', 'Incolla qui i dati dell’animazione…', 'Analizza e genera', 'Carica esempio', 'Cancella', 'Destinazione', 'Cartelle nel service, in ordine', 'Aggiungi cartella', 'Nessuna cartella. La sequenza va direttamente nel service.', 'Nome cartella, es. Anim', 'Rimuovi cartella', 'Anteprima posizione', 'Crea queste cartelle manualmente in Studio. Lo script le cerca solo con FindFirstChild e non le crea mai.', 'Opzioni', 'Nome sequenza', 'Preso dai dati', 'Output', '{n} righe', '-- Il tuo script apparirà qui dopo l’analisi.', 'Copia script', 'Copiato', 'Vedi output', 'Impostazioni', 'Impostazioni interfaccia', 'Scegli un tema e una lingua. Puoi cambiarli quando vuoi.', 'Tema', 'Scuro · Futuristico', 'Chiaro · Minimalista', 'Scegli una modalità e un colore d’accento.', 'Rosso', 'Blu', 'Verde', 'Arancione', 'Lingua', 'Fatto', 'I dati grezzi sono vuoti. Incollali prima.', 'Nessuna riga "[Keyframe N] t=…" leggibile. Controlla che il formato corrisponda al dump dell’animazione.', 'Numero non valido: {v}', '{n} righe non riconosciute sono state ignorate.', 'L’intestazione indica {a} keyframe, ma ne sono stati letti {b}.', 'La durata nell’intestazione ({a}s) differisce dall’ultimo keyframe ({b}s).', '{n} keyframe non contengono pose.', 'Nome', 'Durata', 'Keyframe', 'Pose', 'Loop (dati)', 'Sì', 'No', 'Creato da', 'Un sito che converte dati grezzi di animazione in una KeyframeSequence nativa, la forma grezza di un’animazione Roblox.', 'Tutto gira nel tuo browser. I dati dell’animazione non vengono mai caricati.', 'Font: Orbitron e Share Tech Mono. Icone e bandiere: SVG personalizzati.', 'Non affiliato, approvato né sponsorizzato da Roblox Corporation.', 'Cerca lingua…', 'Nessuna lingua trovata', 'Ingrandisci', 'Ripristina nome dai dati', 'Anteprima'], { priority: 'Priorità' });
addLang('tr', ['Otomatik algıla', 'R15 desteği geliştirme aşamasında — hazırlaman gereken bir şey yok, sonra tekrar bak.', 'Sürükle = döndür · Kaydır = yakınlaştır', 'Ham animasyon verisini yapıştırmaya hazır bir KeyframeSequence betiğine dönüştür.', 'Veri', 'Ayarlar', 'Çıktı', 'Ham veri', 'Animasyon verini buraya yapıştır…', 'Ayrıştır ve oluştur', 'Örnek yükle', 'Temizle', 'Hedef', 'Service içindeki klasörler, sırayla', 'Klasör ekle', 'Klasör yok. Sequence doğrudan service içine gider.', 'Klasör adı, örn. Anim', 'Klasörü kaldır', 'Konum önizlemesi', 'Bu klasörleri Studio’da elle oluştur. Betik onları yalnızca FindFirstChild ile arar, asla oluşturmaz.', 'Seçenekler', 'Sequence adı', 'Veriden alındı', 'Çıktı', '{n} satır', '-- Betiğin ayrıştırmadan sonra burada görünecek.', 'Betiği kopyala', 'Kopyalandı', 'Çıktıyı gör', 'Ayarlar', 'Arayüz ayarları', 'Bir tema ve dil seç. İstediğin zaman değiştirebilirsin.', 'Tema', 'Koyu · Fütüristik', 'Açık · Minimalist', 'Bir mod ve vurgu rengi seç.', 'Kırmızı', 'Mavi', 'Yeşil', 'Turuncu', 'Dil', 'Tamam', 'Ham veri boş. Önce yapıştır.', '"[Keyframe N] t=…" satırı okunamadı. Biçimin animasyon dökümüyle aynı olduğundan emin ol.', 'Geçersiz sayı: {v}', '{n} tanınmayan satır atlandı.', 'Başlık {a} keyframe diyor, ama {b} okundu.', 'Başlıktaki süre ({a}s) son keyframe’den ({b}s) farklı.', '{n} keyframe pose içermiyor.', 'Ad', 'Süre', 'Keyframe', 'Pose', 'Loop (veri)', 'Evet', 'Hayır', 'Yapan', 'Ham animasyon verisini yerel bir KeyframeSequence’e, yani Roblox animasyonunun ham haline çeviren bir web sitesi.', 'Her şey tarayıcında çalışır. Animasyon verin asla yüklenmez.', 'Yazı tipleri: Orbitron ve Share Tech Mono. Simgeler ve bayraklar: özel SVG.', 'Roblox Corporation ile bağlantılı değildir; onaylanmamış veya desteklenmemiştir.', 'Dil ara…', 'Dil bulunamadı', 'Büyüt', 'Veriden gelen ada sıfırla', 'Önizleme'], { priority: 'Öncelik' });
addLang('ru', ['Автоопределение', 'Поддержка R15 в разработке — готовить ничего не нужно, загляните позже.', 'Перетаскивание = вращение · Колесо = зум', 'Превращайте сырые данные анимации в готовый к вставке скрипт KeyframeSequence.', 'Данные', 'Настройки', 'Результат', 'Сырые данные', 'Вставьте сюда данные анимации…', 'Разобрать и создать', 'Загрузить пример', 'Очистить', 'Назначение', 'Папки внутри service по порядку', 'Добавить папку', 'Папок нет. Sequence попадёт прямо в service.', 'Имя папки, напр. Anim', 'Удалить папку', 'Предпросмотр места', 'Создайте эти папки вручную в Studio. Скрипт только ищет их через FindFirstChild и никогда не создаёт.', 'Параметры', 'Имя sequence', 'Берётся из данных', 'Результат', 'Строк: {n}', '-- Ваш скрипт появится здесь после разбора.', 'Копировать скрипт', 'Скопировано', 'Смотреть результат', 'Настройки', 'Настройки интерфейса', 'Выберите тему и язык. Их можно менять в любой момент.', 'Тема', 'Тёмная · Футуристичная', 'Светлая · Минимализм', 'Выберите режим и акцентный цвет.', 'Красный', 'Синий', 'Зелёный', 'Оранжевый', 'Язык', 'Готово', 'Сырые данные пусты. Сначала вставьте их.', 'Не удалось прочитать ни одной строки "[Keyframe N] t=…". Проверьте, что формат совпадает с дампом анимации.', 'Недопустимое число: {v}', 'Нераспознанных строк пропущено: {n}.', 'В заголовке указано keyframe: {a}, а прочитано: {b}.', 'Длительность в заголовке ({a}с) отличается от последнего keyframe ({b}с).', 'Keyframe без поз: {n}.', 'Имя', 'Длительность', 'Keyframe', 'Позы', 'Loop (данные)', 'Да', 'Нет', 'Автор', 'Сайт, который превращает сырые данные анимации в нативную KeyframeSequence — сырую форму анимации Roblox.', 'Всё работает в вашем браузере. Данные анимации никогда не загружаются.', 'Шрифты: Orbitron и Share Tech Mono. Иконки и флаги: собственные SVG.', 'Не связан с Roblox Corporation, не одобрен и не спонсируется ею.', 'Поиск языка…', 'Язык не найден', 'Увеличить', 'Вернуть имя из данных', 'Предпросмотр'], { priority: 'Приоритет', loop: 'Цикл' });
addLang('ja', ['自動検出', 'R15 対応は開発中です。準備は不要なので、後でまた確認してください。', 'ドラッグ = 回転 · スクロール = ズーム', '生のアニメーションデータを、そのまま貼り付けられる KeyframeSequence スクリプトに変換します。', 'データ', '設定', '出力', '生データ', 'ここにアニメーションデータを貼り付け…', '解析して生成', 'サンプルを読み込む', 'クリア', '保存先', 'service 内のフォルダ(順番通り)', 'フォルダを追加', 'フォルダなし。sequence は service 直下に入ります。', 'フォルダ名(例: Anim)', 'フォルダを削除', '場所のプレビュー', 'これらのフォルダは Studio で手動で作成してください。スクリプトは FindFirstChild で探すだけで、作成はしません。', 'オプション', 'Sequence 名', 'データから取得', '出力', '{n} 行', '-- 解析後、ここにスクリプトが表示されます。', 'スクリプトをコピー', 'コピーしました', '出力を見る', '設定', 'インターフェース設定', 'テーマと言語を選んでください。いつでも変更できます。', 'テーマ', 'ダーク · 未来的', 'ライト · ミニマル', 'モードとアクセントカラーを選択。', '赤', '青', '緑', 'オレンジ', '言語', '完了', '生データが空です。先に貼り付けてください。', '"[Keyframe N] t=…" の行を読み取れませんでした。アニメーションダンプと同じ形式か確認してください。', '無効な数値: {v}', '認識できない {n} 行をスキップしました。', 'ヘッダーでは {a} キーフレームですが、{b} 個が読み取られました。', 'ヘッダーの長さ({a}s)が最後のキーフレーム({b}s)と異なります。', '{n} 個のキーフレームにポーズがありません。', '名前', '長さ', 'キーフレーム', 'ポーズ', 'Loop(データ)', 'はい', 'いいえ', '作者', '生のアニメーションデータを、Roblox アニメーションの生の形であるネイティブな KeyframeSequence に変換するサイトです。', 'すべてブラウザ内で動作します。アニメーションデータはアップロードされません。', 'フォント: Orbitron、Share Tech Mono。アイコンと国旗: 自作 SVG。', 'Roblox Corporation とは提携・承認・後援の関係にありません。', '言語を検索…', '言語が見つかりません', '拡大', 'データの名前に戻す', 'プレビュー'], { priority: '優先度', loop: 'ループ' });
addLang("vi", ["Tự động nhận diện", "Hỗ trợ R15 đang được phát triển — bạn không cần chuẩn bị gì, hãy quay lại sau.", "Kéo = xoay · Cuộn = thu phóng", "Biến dữ liệu animation thô thành script KeyframeSequence sẵn sàng để dán.", "Dữ liệu", "Cài đặt", "Kết quả", "Dữ liệu thô", "Dán dữ liệu animation của bạn vào đây…", "Phân tích & tạo", "Tải mẫu", "Xóa", "Đích đến", "Các thư mục trong service, theo thứ tự", "Thêm thư mục", "Không có thư mục. Sequence nằm thẳng trong service.", "Tên thư mục, vd. Anim", "Xóa thư mục", "Xem trước vị trí", "Hãy tự tạo các thư mục này trong Studio. Script chỉ tìm chúng bằng FindFirstChild và không bao giờ tạo.", "Tùy chọn", "Tên sequence", "Lấy từ dữ liệu", "Kết quả", "{n} dòng", "-- Script của bạn sẽ hiện ở đây sau khi phân tích.", "Sao chép script", "Đã sao chép", "Xem kết quả", "Cài đặt", "Cài đặt giao diện", "Chọn chủ đề và ngôn ngữ. Bạn có thể đổi bất cứ lúc nào.", "Chủ đề", "Tối · Tương lai", "Sáng · Tối giản", "Chọn chế độ và màu nhấn.", "Đỏ", "Xanh dương", "Xanh lá", "Cam", "Ngôn ngữ", "Xong", "Dữ liệu thô đang trống. Hãy dán vào trước.", "Không đọc được dòng \"[Keyframe N] t=…\" nào. Kiểm tra định dạng có giống bản dump animation không.", "Số không hợp lệ: {v}", "Đã bỏ qua {n} dòng không nhận diện được.", "Header ghi {a} keyframe, nhưng chỉ đọc được {b}.", "Thời lượng ở header ({a}s) khác keyframe cuối ({b}s).", "{n} keyframe không có pose.", "Tên", "Thời lượng", "Keyframe", "Pose", "Loop (dữ liệu)", "Có", "Không", "Tạo bởi", "Trang web chuyển dữ liệu animation thô thành KeyframeSequence gốc, dạng thô của animation Roblox.", "Mọi thứ chạy trong trình duyệt của bạn. Dữ liệu animation không bao giờ được tải lên.", "Phông chữ: Orbitron và Share Tech Mono. Biểu tượng và cờ: SVG tự thiết kế.", "Không liên kết, không được Roblox Corporation chứng thực hay tài trợ.", "Tìm ngôn ngữ…", "Không tìm thấy ngôn ngữ", "Phóng to", "Đặt lại tên từ dữ liệu", "Xem trước"], {"priority": "Ưu tiên", "loop": "Lặp"});
addLang("ko", ["자동 감지", "R15 지원은 개발 중입니다. 준비할 것은 없으니 나중에 다시 확인해 주세요.", "드래그 = 회전 · 스크롤 = 확대", "원시 애니메이션 데이터를 바로 붙여넣을 수 있는 KeyframeSequence 스크립트로 변환합니다.", "데이터", "설정", "출력", "원시 데이터", "여기에 애니메이션 데이터를 붙여넣으세요…", "분석 및 생성", "샘플 불러오기", "지우기", "대상 위치", "service 안의 폴더(순서대로)", "폴더 추가", "폴더 없음. sequence가 service 바로 아래에 들어갑니다.", "폴더 이름 (예: Anim)", "폴더 삭제", "위치 미리보기", "이 폴더들은 Studio에서 직접 만들어야 합니다. 스크립트는 FindFirstChild로 찾기만 하고 만들지 않습니다.", "옵션", "Sequence 이름", "데이터에서 가져옴", "출력", "{n}줄", "-- 분석 후 여기에 스크립트가 표시됩니다.", "스크립트 복사", "복사됨", "출력 보기", "설정", "인터페이스 설정", "테마와 언어를 선택하세요. 언제든 바꿀 수 있습니다.", "테마", "다크 · 미래적", "라이트 · 미니멀", "모드와 강조 색상을 선택하세요.", "빨강", "파랑", "초록", "주황", "언어", "완료", "원시 데이터가 비어 있습니다. 먼저 붙여넣으세요.", "\"[Keyframe N] t=…\" 줄을 읽지 못했습니다. 애니메이션 덤프와 같은 형식인지 확인하세요.", "잘못된 숫자: {v}", "인식할 수 없는 {n}줄을 건너뛰었습니다.", "헤더에는 키프레임 {a}개로 되어 있지만 {b}개를 읽었습니다.", "헤더의 길이({a}s)가 마지막 키프레임({b}s)과 다릅니다.", "포즈가 없는 키프레임이 {n}개 있습니다.", "이름", "길이", "키프레임", "포즈", "Loop(데이터)", "예", "아니요", "제작", "원시 애니메이션 데이터를 Roblox 애니메이션의 원시 형태인 네이티브 KeyframeSequence로 변환하는 사이트입니다.", "모든 작업은 브라우저에서 실행됩니다. 애니메이션 데이터는 업로드되지 않습니다.", "글꼴: Orbitron, Share Tech Mono. 아이콘과 국기: 자체 제작 SVG.", "Roblox Corporation과 제휴, 승인, 후원 관계가 없습니다.", "언어 검색…", "언어를 찾을 수 없음", "확대", "데이터 이름으로 되돌리기", "미리보기"], {"priority": "우선순위", "loop": "반복"});
Object.assign(T['en-US'], {'download': 'Download .lua', 'histTitle': 'History', 'histEmpty': 'No saved animations yet.', 'histSearch': 'Search animations…', 'histOpen': 'Open', 'histDelete': 'Delete', 'histClear': 'Clear all', 'histCompressed': 'Compressed', 'histKf': '{n} keyframes', 'histOpened': 'Opened from history', 'histConfirm': 'Delete all history?', 'fxTitle': 'Animation tweaks', 'fxMirror': 'Mirror left/right', 'fxSeamless': 'Seamless loop', 'fxDedupe': 'Remove duplicate keyframes', 'fxSpeed': 'Speed ×', 'fxParts': 'Included parts', 'fxKf': 'Keyframes: {a} → {b}', 'prevFrom': 'From', 'prevTo': 'To'});
Object.assign(T['id'], {'download': 'Unduh .lua', 'histTitle': 'Riwayat', 'histEmpty': 'Belum ada animasi tersimpan.', 'histSearch': 'Cari animasi…', 'histOpen': 'Buka', 'histDelete': 'Hapus', 'histClear': 'Hapus semua', 'histCompressed': 'Terkompres', 'histKf': '{n} keyframe', 'histOpened': 'Dibuka dari riwayat', 'histConfirm': 'Hapus semua riwayat?', 'fxTitle': 'Ubahan animasi', 'fxMirror': 'Cermin kiri/kanan', 'fxSeamless': 'Loop mulus', 'fxDedupe': 'Hapus keyframe duplikat', 'fxSpeed': 'Kecepatan ×', 'fxParts': 'Part yang dipakai', 'fxKf': 'Keyframe: {a} → {b}', 'prevFrom': 'Dari', 'prevTo': 'Sampai'});
Object.assign(T['es'], {'download': 'Descargar .lua', 'histTitle': 'Historial', 'histEmpty': 'Aún no hay animaciones guardadas.', 'histSearch': 'Buscar animaciones…', 'histOpen': 'Abrir', 'histDelete': 'Eliminar', 'histClear': 'Borrar todo', 'histCompressed': 'Comprimido', 'histKf': '{n} keyframes', 'histOpened': 'Abierto desde el historial', 'histConfirm': '¿Borrar todo el historial?', 'fxTitle': 'Ajustes de animación', 'fxMirror': 'Espejo izquierda/derecha', 'fxSeamless': 'Bucle sin cortes', 'fxDedupe': 'Quitar keyframes duplicados', 'fxSpeed': 'Velocidad ×', 'fxParts': 'Partes incluidas', 'fxKf': 'Keyframes: {a} → {b}', 'prevFrom': 'Desde', 'prevTo': 'Hasta'});
Object.assign(T['pt-BR'], {'download': 'Baixar .lua', 'histTitle': 'Histórico', 'histEmpty': 'Nenhuma animação salva ainda.', 'histSearch': 'Buscar animações…', 'histOpen': 'Abrir', 'histDelete': 'Excluir', 'histClear': 'Limpar tudo', 'histCompressed': 'Compactado', 'histKf': '{n} keyframes', 'histOpened': 'Aberto do histórico', 'histConfirm': 'Apagar todo o histórico?', 'fxTitle': 'Ajustes da animação', 'fxMirror': 'Espelhar esquerda/direita', 'fxSeamless': 'Loop contínuo', 'fxDedupe': 'Remover keyframes duplicados', 'fxSpeed': 'Velocidade ×', 'fxParts': 'Partes incluídas', 'fxKf': 'Keyframes: {a} → {b}', 'prevFrom': 'De', 'prevTo': 'Até'});
// only fully translated languages show in the picker (a language with missing strings would look half-English)
const LANGS = LANGS_ALL.filter(l => l.code === 'en-GB' || (T[l.code] && T[l.code].errNoKf));

/* ---------- STATE ---------- */
const MODES = ['dark', 'light'];
const ACCENTS = ['red', 'blue', 'green', 'orange'];
// [accent, accent 2 (gradient end)] — page bg is set in CSS
const ACC = { // [accent, accent 2, page bg]
  dark: { red: ['#ff3355', '#ff7a3d', '#0a0305'], blue: ['#3d8bff', '#22d3ee', '#02060d'], green: ['#1fe27a', '#b8f53a', '#020a05'], orange: ['#ff8a1f', '#ffd23d', '#0a0602'] },
  light: { red: ['#e0233a', '#ff6a4d', '#fcf7f7'], blue: ['#2a5bf0', '#12b5d6', '#f5f8fe'], green: ['#0e9455', '#7cc04a', '#f5faf6'], orange: ['#e2670a', '#f0a020', '#fcf8f3'] }
};
const OLDMAP = { crimson: ['dark', 'red'], aurora: ['dark', 'blue'], matrix: ['dark', 'green'], synth: ['dark', 'orange'], paper: ['light', 'orange'], mist: ['light', 'blue'], sage: ['light', 'green'], peach: ['light', 'red'] };
const SERVICES = ['ServerScriptService','ServerStorage','ReplicatedStorage','Workspace','ReplicatedFirst','Lighting','StarterPack','StarterGui','StarterPlayer'];
const PRIORITIES = ['Core','Idle','Movement','Action','Action2','Action3','Action4'];
const ui = { mode: 'dark', accent: 'red', lang: 'en-US' };
const state = { parsed: null, warns: [], err: null, folders: [], nameDirty: false, loopDirty: false };

try {
  const s = JSON.parse(localStorage.getItem('kff.ui') || 'null');
  if (s) {
    const o = OLDMAP[s.accent];
    if (o) { ui.mode = o[0]; ui.accent = o[1]; }
    else { if (MODES.includes(s.mode)) ui.mode = s.mode; if (ACCENTS.includes(s.accent)) ui.accent = s.accent; }
    if (LANGS.some(l => l.code === s.lang)) ui.lang = s.lang;
  }
} catch (_) {}
function save() { try { localStorage.setItem('kff.ui', JSON.stringify(ui)); } catch (_) {} }

function t(k, p) {
  let s = (T[ui.lang] && T[ui.lang][k]) || T['en-US'][k] || k;
  if (p) s = s.replace(/\{(\w+)\}/g, (m, n) => (p[n] !== undefined ? p[n] : m));
  return s;
}
const isMobile = () => window.matchMedia('(max-width: 820px)').matches;

/* ---------- PARSER (unchanged logic) ---------- */
class AppErr extends Error { constructor(key, params) { super(key); this.key = key; this.params = params || {}; } }
const NUM = '[-+]?(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?';
const RE_HEAD = /^==\s*(.+?)\s*==$/;
const RE_DUR  = /Duration:\s*([\d.]+)/i;
const RE_CNT  = /Keyframes:\s*(\d+)/i;
const RE_LOOP = /Loop:\s*(true|false)/i;
const RE_KF   = new RegExp('^\\[Keyframe[^\\]]*\\]\\s*t\\s*=\\s*(' + NUM + ')\\s*s?\\s*(?:\\((.*)\\))?\\s*$', 'i');
const RE_POSE = /^([^:]+?):\s+(.+)$/;
const RE_VAL  = new RegExp('^rot\\s+(' + NUM + ')\\s*°?\\s*axis\\(\\s*(' + NUM + ')\\s*,\\s*(' + NUM + ')\\s*,\\s*(' + NUM + ')\\s*\\)(?:\\s*pos\\(\\s*x\\s*=\\s*(' + NUM + ')\\s*,\\s*y\\s*=\\s*(' + NUM + ')\\s*,\\s*z\\s*=\\s*(' + NUM + ')\\s*\\))?\\s*$', 'i');

function clean(s) {
  if (!Number.isFinite(Number(s))) throw new AppErr('errNum', { v: s });
  return String(s).trim().replace(/^\+/, '');
}

/* ---------- DENSIFY (v1.0.6) ----------
   Roblox's docs are explicit that a joint doesn't need a Pose in every
   Keyframe ("...without needing to define every frame") — BUT they're
   equally explicit that "each Pose is parented to the Pose corresponding
   to the part it is attached to", i.e. the hierarchy path has to be
   consistent. When a descendant (e.g. the Head) has real data in a
   keyframe but its ancestor (e.g. the Torso) doesn't, we can't just skip
   the ancestor (v1.0.5) — that silently changes WHICH pose object the
   Head attaches to from one keyframe to the next, which fragments what
   should be one continuous track for that joint into several disconnected
   one-point tracks (nothing to interpolate between = hard snaps). We also
   can't fill the gap with a placeholder CFrame (v1.0.3's hold, v1.0.4's
   Weight=0) without corrupting that ancestor's OWN motion with a fake
   waypoint that isn't really part of its animation curve.

   The fix that satisfies both requirements at once: compute what the
   ancestor's real value WOULD be at that timestamp by interpolating
   between its own two nearest real keyframes — position lerped linearly,
   rotation slerped via quaternion (matching exactly how CFrame:Lerp
   itself interpolates) — and bake that in as genuine data. Every joint
   then has a real, correctly-weighted Pose at every keyframe, so the
   hierarchy is always consistent AND every value already sits exactly on
   the curve Roblox would draw anyway, so nothing about the motion
   actually changes — gaps are just filled with points already on their
   own curve rather than left as structurally-inconsistent holes. */
function axisAngleToQuat(angleDeg, axis) {
  let [x, y, z] = axis;
  let mag = Math.sqrt(x * x + y * y + z * z);
  if (mag > 0.0001) { x /= mag; y /= mag; z /= mag; } else { x = 0; y = 1; z = 0; }
  const half = (angleDeg * Math.PI / 180) / 2;
  const s = Math.sin(half);
  return { w: Math.cos(half), x: x * s, y: y * s, z: z * s };
}
function quatToAxisAngle(q) {
  let { w, x, y, z } = q;
  const mag = Math.sqrt(w * w + x * x + y * y + z * z);
  if (mag > 0.0001) { w /= mag; x /= mag; y /= mag; z /= mag; }
  const wc = Math.min(1, Math.max(-1, w));
  const angle = 2 * Math.acos(wc);
  const s = Math.sqrt(1 - wc * wc);
  let axis;
  if (s < 0.0001) axis = [0, 1, 0];
  else axis = [x / s, y / s, z / s];
  return { angle: angle * 180 / Math.PI, axis };
}
function slerpQuat(a, b, t) {
  let dot = a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z;
  let bb = b;
  if (dot < 0) { bb = { w: -b.w, x: -b.x, y: -b.y, z: -b.z }; dot = -dot; }
  if (dot > 0.9995) {
    return {
      w: a.w + (bb.w - a.w) * t, x: a.x + (bb.x - a.x) * t,
      y: a.y + (bb.y - a.y) * t, z: a.z + (bb.z - a.z) * t
    };
  }
  const theta0 = Math.acos(Math.min(1, Math.max(-1, dot)));
  const theta = theta0 * t;
  const s0 = Math.cos(theta) - dot * Math.sin(theta) / Math.sin(theta0);
  const s1 = Math.sin(theta) / Math.sin(theta0);
  return {
    w: s0 * a.w + s1 * bb.w, x: s0 * a.x + s1 * bb.x,
    y: s0 * a.y + s1 * bb.y, z: s0 * a.z + s1 * bb.z
  };
}
function round4(n) { return Math.round(n * 10000) / 10000; }

function densifyKeyframes(p) {
  const times = p.keyframes.map(k => Number(k.t));
  // path -> sorted [{t, angle, axis:[x,y,z], pos:[x,y,z]|null}]
  const tracks = {};
  p.keyframes.forEach(kf => {
    kf.poses.forEach(po => {
      if (po.idle) return;
      (tracks[po.path] ||= []).push({
        t: Number(kf.t),
        angle: Number(po.angle),
        axis: po.axis.map(Number),
        pos: po.pos ? po.pos.map(Number) : [0, 0, 0]
      });
    });
  });
  Object.keys(tracks).forEach(path => tracks[path].sort((a, b) => a.t - b.t));

  p.keyframes.forEach(kf => {
    const t = Number(kf.t);
    const hadPath = new Set(kf.poses.map(po => po.path));
    const newPoses = [];
    kf.poses.forEach(po => { if (po.idle && !(po.path in tracks)) newPoses.push(po); });
    Object.keys(tracks).forEach(path => {
      const pts = tracks[path];
      if (pts.length === 1) {
        const only = pts[0];
        newPoses.push({ path, angle: String(only.angle), axis: only.axis.map(String), pos: only.pos.map(String) });
        return;
      }
      let lo = pts[0], hi = pts[pts.length - 1];
      for (let i = 0; i < pts.length - 1; i++) {
        if (t >= pts[i].t - 1e-6 && t <= pts[i + 1].t + 1e-6) { lo = pts[i]; hi = pts[i + 1]; break; }
      }
      if (Math.abs(t - lo.t) < 1e-6) {
        newPoses.push({ path, angle: String(lo.angle), axis: lo.axis.map(String), pos: lo.pos.map(String) });
        return;
      }
      if (Math.abs(t - hi.t) < 1e-6) {
        newPoses.push({ path, angle: String(hi.angle), axis: hi.axis.map(String), pos: hi.pos.map(String) });
        return;
      }
      if (t < lo.t || t > hi.t) {
        // Outside this joint's own recorded range: hold nearest edge
        // rather than extrapolate.
        const edge = t < lo.t ? lo : hi;
        newPoses.push({ path, angle: String(edge.angle), axis: edge.axis.map(String), pos: edge.pos.map(String) });
        return;
      }
      const f = (t - lo.t) / (hi.t - lo.t);
      const qa = axisAngleToQuat(lo.angle, lo.axis);
      const qb = axisAngleToQuat(hi.angle, hi.axis);
      const q = slerpQuat(qa, qb, f);
      const { angle, axis } = quatToAxisAngle(q);
      const pos = [0, 1, 2].map(i => round4(lo.pos[i] + (hi.pos[i] - lo.pos[i]) * f));
      newPoses.push({ path, angle: String(round4(angle)), axis: axis.map(n => String(round4(n))), pos: pos.map(String) });
    });
    kf.poses = newPoses;
  });
}

function parseDump(text) {
  const p = { name: null, duration: null, declared: null, loop: null, keyframes: [] };
  const warns = [];
  let cur = null, bad = 0;
  text.replace(/\r/g, '').split('\n').forEach(raw => {
    const line = raw.trim();
    if (!line) return;
    let m;
    if ((m = line.match(RE_KF))) {
      cur = { t: clean(m[1]), name: ((m[2] || '').trim() || 'Keyframe'), poses: [] };
      p.keyframes.push(cur);
      return;
    }
    if (!cur) {
      if ((m = line.match(RE_HEAD))) { p.name = m[1]; return; }
      if ((m = line.match(RE_DUR))) p.duration = parseFloat(m[1]);
      if ((m = line.match(RE_CNT))) p.declared = parseInt(m[1], 10);
      if ((m = line.match(RE_LOOP))) p.loop = m[1].toLowerCase() === 'true';
      return;
    }
    const pm = line.match(RE_POSE);
    if (!pm) { bad++; return; }
    const path = pm[1].split('/').map(x => x.trim()).filter(Boolean).join('/');
    if (!path) { bad++; return; }
    const val = pm[2].trim();
    if (/^idle$/i.test(val)) { cur.poses.push({ path, idle: true }); return; }
    const vm = val.match(RE_VAL);
    if (!vm) { bad++; return; }
    cur.poses.push({
      path,
      angle: clean(vm[1]),
      axis: [clean(vm[2]), clean(vm[3]), clean(vm[4])],
      pos: vm[5] !== undefined ? [clean(vm[5]), clean(vm[6]), clean(vm[7])] : null
    });
  });

  if (!p.keyframes.length) throw new AppErr('errNoKf');
  if (bad) warns.push({ key: 'warnBad', params: { n: bad } });
  if (p.declared !== null && p.declared !== p.keyframes.length) warns.push({ key: 'warnCount', params: { a: p.declared, b: p.keyframes.length } });
  const lastT = Math.max(...p.keyframes.map(k => Number(k.t)));
  if (p.duration !== null && Math.abs(p.duration - lastT) > 0.005) warns.push({ key: 'warnDur', params: { a: p.duration, b: lastT } });
  const empty = p.keyframes.filter(k => !k.poses.length).length;
  if (empty) warns.push({ key: 'warnEmpty', params: { n: empty } });
  densifyKeyframes(p);
  return { parsed: p, warns };
}

/* ---------- GENERATOR ---------- */
const luaStr = s => '"' + String(s).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';

/* NOTE (v1.0.6): the logic below (only ever create a Pose when the source
   entry has real angle/axis data, nest under the nearest real ancestor)
   is unchanged from v1.0.5 — it was correct on its own. What was missing
   was upstream: DATA itself used to be sparse (a joint's path only
   appeared with real numbers on the keyframes where it was actually
   moved), so an ancestor with real data on some keyframes and none on
   others made its descendants attach to a DIFFERENT parent Pose from one
   keyframe to the next, fragmenting what should be one continuous track
   into several disconnected single-point ones (nothing to interpolate
   between = a hard snap). See the densifyKeyframes() comment near the
   top of the script: DATA is now pre-filled so every joint that's
   animated at all has real, correctly-interpolated data at every single
   keyframe, so the code below now always finds a real ancestor to nest
   under, and every hierarchy path stays consistent from start to
   finish. */
const LUA_TAIL = `
-- ===== CHECK SETTINGS AND DATA =====
local folders = FOLDERS or {}
assert(type(SEQUENCE_NAME) == "string", "[KeyframeSequence] The SEQUENCE_NAME line is missing at the top of the script.")
assert(type(SERVICE) == "string", "[KeyframeSequence] The SERVICE line is missing at the top of the script.")
assert(type(DATA) == "table" and #DATA > 0, "[KeyframeSequence] DATA is missing or empty.")
for i = 1, #DATA do
	local kf = DATA[i]
	assert(
		type(kf) == "table" and type(kf.poses) == "table",
		("[KeyframeSequence] Keyframe #%d is broken. The data was probably cut off or edited."):format(i)
	)
end

local function buildOffsetCFrame(angle, axis, pos)
	local axisVec = Vector3.new(axis[1], axis[2], axis[3])
	if axisVec.Magnitude > 0.0001 then
		axisVec = axisVec.Unit
	else
		axisVec = Vector3.new(0, 1, 0)
	end
	local posVec = pos and Vector3.new(pos[1], pos[2], pos[3]) or Vector3.new(0, 0, 0)
	return CFrame.new(posVec) * CFrame.fromAxisAngle(axisVec, math.rad(angle))
end

-- ===== FIND DESTINATION (folders must already exist) =====
local target = game:GetService(SERVICE)
for _, folderName in ipairs(folders) do
	local nextTarget = target:FindFirstChild(folderName)
	if not nextTarget then
		warn(("[KeyframeSequence] Folder '%s' was not found in %s. Create it manually first."):format(folderName, target:GetFullName()))
		return
	end
	target = nextTarget
end

-- ===== BUILD KEYFRAMESEQUENCE =====
local sequence = Instance.new("KeyframeSequence")
sequence.Name = SEQUENCE_NAME
sequence.Loop = LOOP == true
sequence.Priority = Enum.AnimationPriority.__PRI__

for _, kf in ipairs(DATA) do
	local keyframe = Instance.new("Keyframe")
	keyframe.Name = kf.name
	keyframe.Time = kf.t

	-- Only the joints THIS keyframe actually has authored angle/axis data
	-- for. A hierarchy-only entry (no angle/axis) means this joint isn't
	-- being keyed here, so it's simply not added to this table.
	local dataAt = {}
	for _, entry in ipairs(kf.poses) do
		if entry[2] then
			dataAt[entry[1]] = entry
		end
	end

	local poses = {}
	local function getPose(path)
		local existing = poses[path]
		if existing ~= nil then
			return existing or nil
		end
		local entry = dataAt[path]
		if not entry then
			-- No authored data for this joint at this keyframe: don't
			-- fabricate one. Mark as visited (false, not a Pose) so we
			-- don't re-check it, and its own track keeps interpolating
			-- smoothly between whichever real keyframes DO define it.
			poses[path] = false
			return nil
		end
		local pose = Instance.new("Pose")
		pose.Name = path:match("([^/]+)$")
		pose.CFrame = buildOffsetCFrame(entry[2], entry[3], entry[4])
		pose.Weight = 1
		pose.EasingStyle = Enum.PoseEasingStyle.Linear
		pose.EasingDirection = Enum.PoseEasingDirection.In
		poses[path] = pose
		-- Walk up to the nearest ancestor that ALSO has real data at this
		-- same keyframe; skip straight past any ancestor that doesn't,
		-- rather than inventing a stand-in for it.
		local parentPath = path:match("^(.+)/[^/]+$")
		local parentPose = parentPath and getPose(parentPath)
		pose.Parent = parentPose or keyframe
		return pose
	end

	for path in pairs(dataAt) do
		getPose(path)
	end

	keyframe.Parent = sequence
end

sequence.Parent = target
print(("[KeyframeSequence] Created '%s' in %s"):format(sequence.Name, target:GetFullName()))
`;

function generate(p, s) {
  const svc = SERVICES.includes(s.service) ? s.service : 'ServerScriptService';
  const pri = PRIORITIES.includes(s.priority) ? s.priority : 'Action';
  const lastT = Math.max(...p.keyframes.map(k => Number(k.t)));
  const L = [];
  L.push('-- Generated by KEYFRAME//FORGE v' + APP_VERSION + ' | ' + p.keyframes.length + ' keyframes | duration ' + (p.duration ?? lastT) + 's');
  L.push('local SEQUENCE_NAME = ' + luaStr(s.name));
  L.push('local SERVICE = ' + luaStr(svc));
  L.push('local FOLDERS = {' + s.folders.map(luaStr).join(', ') + '}');
  L.push('local LOOP = ' + (s.loop ? 'true' : 'false'));
  L.push('');
  L.push('-- ===== ANIMATION DATA =====');
  L.push('local DATA = {');
  p.keyframes.forEach(kf => {
    L.push('\t{t = ' + kf.t + ', name = ' + luaStr(kf.name) + ', poses = {');
    kf.poses.forEach(po => {
      if (po.idle) {
        L.push('\t\t{' + luaStr(po.path) + '},');
      } else {
        let row = '{' + luaStr(po.path) + ', ' + po.angle + ', {' + po.axis.join(', ') + '}';
        if (po.pos) row += ', {' + po.pos.join(', ') + '}';
        L.push('\t\t' + row + '},');
      }
    });
    L.push('\t}},');
  });
  L.push('}');
  return L.join('\n') + '\n' + LUA_TAIL.replace('__PRI__', pri);
}

/* ---------- UI HELPERS ---------- */
function chip(l, v) {
  const d = document.createElement('div'); d.className = 'chip';
  const a = document.createElement('small'); a.textContent = l;
  const b = document.createElement('strong'); b.textContent = v;
  d.append(a, b); return d;
}
function msg(cls, text) {
  const m = document.createElement('div'); m.className = 'msg ' + cls; m.textContent = text; return m;
}

function renderStatus() {
  const box = $('status'); box.replaceChildren();
  if (state.err) {
    box.appendChild(msg('err', '✖ ' + (state.err.key ? t(state.err.key, state.err.params) : state.err.raw)));
    return;
  }
  const p = state.parsed; if (!p) return;
  const paths = new Set();
  p.keyframes.forEach(k => k.poses.forEach(o => paths.add(o.path)));
  const lastT = Math.max(...p.keyframes.map(k => Number(k.t)));
  const chips = document.createElement('div'); chips.className = 'chips';
  chips.append(
    chip(t('chipName'), p.name || 'Animation'),
    chip(t('chipDur'), (p.duration ?? lastT) + 's'),
    chip(t('chipKf'), p.keyframes.length),
    chip(t('chipPose'), paths.size),
    chip(t('chipLoop'), p.loop === null ? '-' : (p.loop ? t('yes') : t('no')))
  );
  box.appendChild(chips);
  state.warns.forEach(w => box.appendChild(msg('warn', '⚠ ' + t(w.key, w.params))));
  const go = document.createElement('button');
  go.type = 'button'; go.className = 'btn ghost only-mobile'; go.textContent = t('goOutput') + ' →';
  go.addEventListener('click', () => setTab('output'));
  box.appendChild(go);
}

function getSettings() {
  return {
    service: $('service').value,
    folders: state.folders.map(s => s.trim()).filter(Boolean),
    name: $('seqName').value.trim() || (state.parsed && state.parsed.name) || 'Animation',
    priority: $('priority').value,
    loop: $('loop').checked,
    mirror: $('fxMirror').checked, seamless: $('fxSeamless').checked, dedupe: $('fxDedupe').checked,
    speed: Number($('fxSpeed').value) || 1, exclude: [...(state.exclude || [])]
  };
}

/* Location tree: Service > folders > KeyframeSequence, with Explorer-style icons */
function updatePathPreview() {
  const s = getSettings();
  const tree = $('tree'); tree.replaceChildren();
  const rows = [{ kind: 'svc', name: s.service, icon: SVC_ICONS[s.service] || SVC_ICONS.Workspace }]
    .concat(s.folders.map(n => ({ kind: 'folder', name: n, icon: FOLDER_ICON })))
    .concat([{ kind: 'seq', name: s.name, icon: SEQ_ICON }]);
  rows.forEach((r, d) => {
    const row = document.createElement('div');
    row.className = 'tn' + (d ? ' child' : '');
    row.style.setProperty('--d', d);
    row.setAttribute('role', 'listitem');
    const ic = document.createElement('span'); ic.className = 'ti ti-' + r.kind; ic.innerHTML = r.icon;
    const lb = document.createElement('span'); lb.className = 'tl' + (r.kind === 'seq' ? ' seq' : ''); lb.textContent = r.name;
    row.append(ic, lb); tree.appendChild(row);
  });
}
function updateLines() {
  const v = $('out').value;
  $('lines').textContent = t('lines', { n: v ? v.split('\n').length : 0 });
}
function regen() {
  if (!state.parsed) return;
  const s = getSettings(); state.eff = effective(state.parsed, s);
  $('out').value = generate(state.eff, s);
  updateLines();
  $('copy').disabled = false; $('dl').disabled = false;
  $('fxStat').textContent = t('fxKf', { a: state.parsed.keyframes.length, b: state.eff.keyframes.length });
}
function refresh() { updatePathPreview(); regen(); }
function clearOutput() { $('out').value = ''; $('copy').disabled = true; $('dl').disabled = true; updateLines(); }

function renderFolders() {
  const box = $('folders'); box.replaceChildren();
  if (!state.folders.length) {
    const e = document.createElement('div'); e.className = 'empty'; e.textContent = t('noFolder');
    box.appendChild(e); return;
  }
  state.folders.forEach((val, i) => {
    const row = document.createElement('div'); row.className = 'frow';
    const idx = document.createElement('span'); idx.className = 'fidx'; idx.textContent = String(i + 1).padStart(2, '0');
    const inp = document.createElement('input');
    inp.type = 'text'; inp.value = val; inp.placeholder = t('folderPh'); inp.spellcheck = false; inp.autocomplete = 'off';
    inp.addEventListener('input', () => { state.folders[i] = inp.value; refresh(); });
    const del = document.createElement('button');
    del.type = 'button'; del.className = 'btn ghost sm'; del.textContent = '✕'; del.title = t('removeFolder'); del.setAttribute('aria-label', t('removeFolder'));
    del.addEventListener('click', () => { state.folders.splice(i, 1); renderFolders(); refresh(); });
    row.append(idx, inp, del); box.appendChild(row);
  });
}

function run(fromBtn) {
  const txt = $('raw').value;
  if (!txt.trim()) {
    state.parsed = null; state.warns = []; state.err = { key: 'errEmpty' };
    clearOutput(); renderStatus(); updatePathPreview(); previewOnDataChanged(); return;
  }
  try {
    const { parsed, warns } = parseDump(txt);
    state.parsed = parsed; state.warns = warns; state.err = null;
    if (!state.nameDirty) $('seqName').value = parsed.name || 'Animation';
    if (!state.loopDirty && parsed.loop !== null) $('loop').checked = parsed.loop;
    buildParts(); renderStatus(); refresh(); if (fromBtn) histAdd(); previewOnDataChanged();
    if (fromBtn && isMobile() && !warns.length) setTab('output');
  } catch (e) {
    state.parsed = null; state.warns = [];
    state.err = e.key ? { key: e.key, params: e.params } : { raw: e.message };
    clearOutput(); renderStatus(); updatePathPreview(); previewOnDataChanged();
  }
}

/* ---------- TABS / TOAST / COPY ---------- */
function setTab(name) {
  document.body.dataset.tab = name;
  document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', b.dataset.go === name ? 'true' : 'false'));
  window.scrollTo({ top: 0 });
}
let toastTimer;
function toast(txt) {
  const el = $('toast'); el.textContent = txt; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 1600);
}
async function copyOut() {
  const o = $('out'); if (!o.value) return;
  try { await navigator.clipboard.writeText(o.value); }
  catch (_) { o.removeAttribute('readonly'); o.select(); document.execCommand('copy'); o.setAttribute('readonly', ''); }
  toast(t('copied'));
}

/* ---------- THEME / LANGUAGE / SETTINGS ---------- */
function applyTheme() {
  const r = document.documentElement;
  r.dataset.mode = ui.mode; r.dataset.accent = ui.accent;
  $('metaTheme').setAttribute('content', ACC[ui.mode][ui.accent][2]);
  document.querySelectorAll('.sw').forEach(b => b.setAttribute('aria-pressed', (b.dataset.mode === ui.mode && b.dataset.accent === ui.accent) ? 'true' : 'false'));
}

const norm = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
function fillLangList(el, q) {
  el.replaceChildren();
  const nq = norm(q || '').trim();
  const list = LANGS.filter(L => !nq || norm(L.label + ' ' + L.en + ' ' + L.code + ' ' + L.short).includes(nq));
  if (!list.length) { const e = document.createElement('div'); e.className = 'lang-empty'; e.textContent = t('noLang'); el.appendChild(e); return; }
  list.forEach(L => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'lang-item'; b.setAttribute('role', 'option');
    b.setAttribute('aria-selected', L.code === ui.lang ? 'true' : 'false');
    const f = document.createElement('span'); f.className = 'flag'; f.innerHTML = FLAGS[L.code];
    const n = document.createElement('span'); n.className = 'ln';
    const nm = document.createElement('span'); nm.textContent = L.label; n.appendChild(nm);
    if (L.en !== L.label) { const s = document.createElement('small'); s.textContent = L.en; n.appendChild(s); }
    const c = document.createElement('span'); c.className = 'chk'; c.textContent = '✓';
    b.append(f, n, c);
    b.addEventListener('click', () => { ui.lang = L.code; save(); $('langSearch').value = ''; $('setupLangSearch').value = ''; applyLang(); closePop(); });
    el.appendChild(b);
  });
}

const EXAMPLE = '== AnimName ==\nDuration: 0.48s | Keyframes: 30\nLoop: false\n\n[Keyframe 1] t=0.00s (Keyframe)\n  HumanoidRootPart: idle\n  HumanoidRootPart/Torso: rot 94.3° axis(0.35, -0.22, -0.91)  pos(x=-0.40, y=-0.01, z=-0.98)';

function applyLang() {
  const cur = LANGS.find(l => l.code === ui.lang) || LANGS[0];
  document.documentElement.lang = cur.code; document.documentElement.dir = cur.rtl ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
  document.querySelectorAll('[data-i18n-aria]').forEach(el => { const s = t(el.dataset.i18nAria); el.setAttribute('aria-label', s); el.title = s; });
  $('raw').placeholder = t('rawPh') + '\n\n' + EXAMPLE;
  $('langFlag').innerHTML = FLAGS[cur.code];
  $('langCode').textContent = cur.short;
  fillLangList($('langList'), $('langSearch').value); fillLangList($('setupLangList'), $('setupLangSearch').value);
  $('seqIc').innerHTML = SEQ_ICON;
  renderFolders(); renderStatus(); updateLines();
}

function closePop() { $('langPop').hidden = true; $('langSearch').value = ''; fillLangList($('langList')); $('langBtn').setAttribute('aria-expanded', 'false'); }
function togglePop() {
  const open = $('langPop').hidden;
  $('langPop').hidden = !open; $('langBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
  if (open) {
    const sel = $('langList').querySelector('[aria-selected="true"]'); if (sel) sel.scrollIntoView({ block: 'nearest' });
    if (!isMobile()) $('langSearch').focus();
  }
}
function openSetup() { closePop(); $('modal').hidden = false; document.body.style.overflow = 'hidden'; }
function closeSetup() { $('modal').hidden = true; document.body.style.overflow = ''; }

function buildThemes() {
  const box = $('themes'); box.replaceChildren();
  MODES.forEach(mode => {
    const g = document.createElement('div'); g.className = 'sw-group';
    const h = document.createElement('div'); h.className = 'sw-title'; h.dataset.i18n = mode === 'dark' ? 'themeDark' : 'themeLight';
    const grid = document.createElement('div'); grid.className = 'sw-grid';
    ACCENTS.forEach(a => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'sw'; b.dataset.mode = mode; b.dataset.accent = a;
      b.style.setProperty('--sb', ACC[mode][a][2]); b.style.setProperty('--sa', ACC[mode][a][0]); b.style.setProperty('--sc', ACC[mode][a][1]);
      const p = document.createElement('span'); p.className = 'sw-prev';
      const l = document.createElement('span'); l.dataset.i18n = a;
      b.append(p, l);
      b.addEventListener('click', () => { ui.mode = mode; ui.accent = a; applyTheme(); save(); });
      grid.appendChild(b);
    });
    g.append(h, grid); box.appendChild(g);
  });
}

/* ---------- PREVIEW (3D) ----------
   R6/R15 box-rig used to check timing and smoothness of the parsed
   keyframe data. Pivot points, mesh offsets and part sizes below are
   measured (not eyeballed) from two reference Blender rigs built to
   Roblox Studio's real stud scale, so proportions and joint placement
   line up with an actual Roblox character. Reuses the same
   axisAngleToQuat/slerpQuat math as densifyKeyframes() above so what
   you see here matches exactly what Roblox itself will interpolate. */
const ROOT_Y = 3;
const RIG_SPECS = {
  r6: [
    { name: 'Torso', parent: null, piv: [0, 0, 0], mesh: [0, 0, 0], size: [2, 2, 1], color: 0x3a6bd8 },
    { name: 'Head', parent: 'Torso', piv: [0, 1, 0], mesh: [0, 0.5, 0], size: [1.2, 1.2, 1.2], color: 0xe8b978 },
    { name: 'Left Arm', parent: 'Torso', piv: [-1, 0.5, 0], mesh: [-0.5, -0.5, 0], size: [1, 2, 1], color: 0xe8b978 },
    { name: 'Right Arm', parent: 'Torso', piv: [1, 0.5, 0], mesh: [0.5, -0.5, 0], size: [1, 2, 1], color: 0xe8b978 },
    { name: 'Left Leg', parent: 'Torso', piv: [-0.5, -1, 0], mesh: [0, -1, 0], size: [1, 2, 1], color: 0x1c2b52 },
    { name: 'Right Leg', parent: 'Torso', piv: [0.5, -1, 0], mesh: [0, -1, 0], size: [1, 2, 1], color: 0x1c2b52 }
  ],
  r15: [
    { name: 'LowerTorso', parent: null, piv: [0, -1, 0], mesh: [0, 0.2, 0], size: [2, 0.4, 1], color: 0x3a6bd8 },
    { name: 'UpperTorso', parent: 'LowerTorso', piv: [0, 0.4, 0], mesh: [0, 0.8, 0], size: [2, 1.6, 1], color: 0x3a6bd8 },
    { name: 'Head', parent: 'UpperTorso', piv: [0, 1.6, 0], mesh: [0, 0.5, 0], size: [1.2, 1.2, 1.2], color: 0xe8b978 },
    { name: 'LeftUpperArm', parent: 'UpperTorso', piv: [-1, 1.363, 0], mesh: [-0.5, -0.394, 0], size: [1, 1.169, 1], color: 0xe8b978 },
    { name: 'LeftLowerArm', parent: 'LeftUpperArm', piv: [-0.5, -0.728, 0], mesh: [0, -0.259, 0], size: [1, 1.052, 1], color: 0xe8b978 },
    { name: 'LeftHand', parent: 'LeftLowerArm', piv: [0, -0.76, 0], mesh: [0, -0.125, 0], size: [1, 0.3, 1], color: 0xe8b978 },
    { name: 'RightUpperArm', parent: 'UpperTorso', piv: [1, 1.363, 0], mesh: [0.5, -0.394, 0], size: [1, 1.169, 1], color: 0xe8b978 },
    { name: 'RightLowerArm', parent: 'RightUpperArm', piv: [0.5, -0.728, 0], mesh: [0, -0.259, 0], size: [1, 1.052, 1], color: 0xe8b978 },
    { name: 'RightHand', parent: 'RightLowerArm', piv: [0, -0.76, 0], mesh: [0, -0.125, 0], size: [1, 0.3, 1], color: 0xe8b978 },
    { name: 'LeftUpperLeg', parent: 'LowerTorso', piv: [-0.5, 0, 0], mesh: [0, -0.421, 0], size: [1, 1.217, 1], color: 0x1c2b52 },
    { name: 'LeftLowerLeg', parent: 'LeftUpperLeg', piv: [0, -0.822, 0], mesh: [0, -0.379, 0], size: [1, 1.193, 1], color: 0x1c2b52 },
    { name: 'LeftFoot', parent: 'LeftLowerLeg', piv: [0, -0.926, 0], mesh: [0, -0.102, 0], size: [1, 0.3, 1], color: 0x1c2b52 },
    { name: 'RightUpperLeg', parent: 'LowerTorso', piv: [0.5, 0, 0], mesh: [0, -0.421, 0], size: [1, 1.217, 1], color: 0x1c2b52 },
    { name: 'RightLowerLeg', parent: 'RightUpperLeg', piv: [0, -0.822, 0], mesh: [0, -0.379, 0], size: [1, 1.193, 1], color: 0x1c2b52 },
    { name: 'RightFoot', parent: 'RightLowerLeg', piv: [0, -0.926, 0], mesh: [0, -0.102, 0], size: [1, 0.3, 1], color: 0x1c2b52 }
  ]
};

function detectRigType(parsed) {
  if (!parsed) return 'r6';
  const paths = new Set();
  parsed.keyframes.forEach(kf => kf.poses.forEach(po => paths.add(po.path)));
  for (const p of paths) {
    if (/UpperTorso|LowerTorso|UpperArm|LowerArm|UpperLeg|LowerLeg|Hand|Foot/.test(p)) return 'r15';
  }
  return 'r6';
}

function tintColor(base, tint, amount) {
  const b = { r: (base >> 16) & 255, g: (base >> 8) & 255, b: base & 255 };
  const t = { r: (tint >> 16) & 255, g: (tint >> 8) & 255, b: tint & 255 };
  const mix = (a, c) => Math.round(a * (1 - amount) + c * amount);
  return (mix(b.r, t.r) << 16) | (mix(b.g, t.g) << 8) | mix(b.b, t.b);
}

function buildRig(type) {
  const spec = RIG_SPECS[type] || RIG_SPECS.r6;
  const group = new THREE.Group();
  const rootPivot = new THREE.Group();
  rootPivot.position.set(0, ROOT_Y, 0);
  group.add(rootPivot);
  const joints = { HumanoidRootPart: { pivot: rootPivot, rest: new THREE.Vector3(0, 0, 0), path: 'HumanoidRootPart' } };
  const byName = {};
  spec.forEach(node => {
    const parentInfo = node.parent ? byName[node.parent] : joints.HumanoidRootPart;
    const pivot = new THREE.Group();
    pivot.position.set(node.piv[0], node.piv[1], node.piv[2]);
    parentInfo.pivot.add(pivot);
    const geo = new THREE.BoxGeometry(node.size[0], node.size[1], node.size[2]);
    // Left/right is easy to mix up once the camera has orbited around (and
    // the head's face marker is out of view) — tint Left limbs blue and
    // Right limbs red, the common rigging-tool convention, so the side is
    // readable from any angle without having to find the face first.
    let boxColor = node.color;
    if (/^Left/.test(node.name)) boxColor = tintColor(node.color, 0x2255ff, 0.28);
    else if (/^Right/.test(node.name)) boxColor = tintColor(node.color, 0xff3322, 0.28);
    const mat = new THREE.MeshStandardMaterial({ color: boxColor, roughness: 0.65, metalness: 0.05 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(node.mesh[0], node.mesh[1], node.mesh[2]);
    pivot.add(mesh);
    // Roblox's front is -Z (LookVector). The box rig is otherwise perfectly
    // symmetric front/back, so without a visible marker there's no way to
    // tell "forward" from "sideways" just by looking at it — add a small
    // dark "face" patch on the head's front face, same as every Roblox
    // avatar has, so orientation in the preview is never ambiguous.
    if (node.name === 'Head') {
      const faceGeo = new THREE.PlaneGeometry(node.size[0] * 0.5, node.size[1] * 0.4);
      const faceMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.8 });
      const face = new THREE.Mesh(faceGeo, faceMat);
      face.position.set(node.mesh[0], node.mesh[1], node.mesh[2] - node.size[2] / 2 - 0.01);
      face.rotation.y = Math.PI; // PlaneGeometry's default normal is +Z; flip it to face -Z (forward)
      pivot.add(face);
    }
    // A plain colored box looks identical no matter how it's spun — there's
    // nothing on it to reveal a rotation, which is exactly why the "spin
    // 180 and see" tests on the legs showed no visible difference either
    // way. Paint one narrow stripe on the FRONT (-Z) face and a differently
    // placed one on the TOP (+Y) face of every limb box, so any twist or
    // flip is something you can actually see happen instead of having to
    // infer it.
    if (/^(Left|Right)\s?(Arm|Leg|UpperArm|LowerArm|Hand|UpperLeg|LowerLeg|Foot)$/.test(node.name)) {
      const stripeMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.8 });
      const front = new THREE.Mesh(new THREE.PlaneGeometry(node.size[0] * 0.9, node.size[1] * 0.15), stripeMat);
      front.position.set(node.mesh[0], node.mesh[1] + node.size[1] * 0.25, node.mesh[2] - node.size[2] / 2 - 0.01);
      front.rotation.y = Math.PI;
      pivot.add(front);
      const top = new THREE.Mesh(new THREE.PlaneGeometry(node.size[0] * 0.15, node.size[2] * 0.9), stripeMat);
      top.position.set(node.mesh[0] - node.size[0] * 0.3, node.mesh[1] + node.size[1] / 2 + 0.01, node.mesh[2]);
      top.rotation.x = -Math.PI / 2;
      pivot.add(top);
    }
    const path = (node.parent ? parentInfo.path : 'HumanoidRootPart') + '/' + node.name;
    const info = { pivot, rest: new THREE.Vector3(node.piv[0], node.piv[1], node.piv[2]), path };
    byName[node.name] = info;
    joints[path] = info;
  });
  return { group, joints };
}

// PREVIEW-ONLY axis fix — derived from the REAL rig, not guessed.
//
// A KeyframeSequence Pose's CFrame is applied to Motor6D.Transform, and
// Roblox composes a joint as: Part1.CFrame = Part0.CFrame * C0 * Transform * C1:Inverse()
// (confirmed on the Pose and Motor6D reference pages). Transform is exactly
// the axis-angle this tool parses — but it's expressed in the joint's own
// C0/C1-defined frame, not directly in Torso's plain axes. Every earlier
// attempt at a single "Blender -> Roblox" axis swap was treating Transform
// as if C0 and C1 were both identity, which they are NOT.
//
// Pulled the actual C0/C1 for every R6 joint straight from a live rig via
// the command bar (see the Lua snippet from earlier in this conversation).
// The key simplification: for every joint checked, C0's rotation and C1's
// rotation are IDENTICAL. When they match like that, C0 * Transform * C1⁻¹
// reduces to conjugating Transform by that shared rotation R — which, for
// an axis-angle input, works out to simply rotating the AXIS by R and
// leaving the angle untouched: R * axisAngleToQuat(angle, axis) * R⁻¹  ==
// axisAngleToQuat(angle, R * axis). So each joint just needs its own fixed
// 3x3 axis remap, no per-frame matrix math required. Measured directly
// from C0's basis vectors (X/Y/Z columns) for each joint:
//
//   Neck                    (x,y,z) -> (-x, z, y)
//   Right Shoulder/Hip      (x,y,z) -> (z, y, -x)
//   Left Shoulder/Hip       (x,y,z) -> (-z, y, x)
//
// Root Joint (HumanoidRootPart -> Torso) WAS assumed identity earlier
// ("Root and Torso share a CFrame" — true for position, wrongly assumed to
// mean no rotation either). Pulled straight from the rig: RootJoint's C0
// and C1 rotation is IDENTICAL to Neck's. So Torso needs the same (-x,z,y)
// conversion as Head, not the raw pass-through it had before.
//
// R15 uses AnimationConstraint/Motor6D joints with their OWN C0/C1 that
// haven't been captured yet, so it reuses these R6 mappings by name as a
// best guess, not something confirmed the same way.
//
// This ONLY affects what gets fed to the three.js preview; the original
// numbers (and anything copied/exported) are left untouched.
const JOINT_AXIS_MAP = {
  neck: v => [-v[0], v[2], v[1]],
  right: v => [v[2], v[1], -v[0]],
  left: v => [-v[2], v[1], v[0]],
  identity: v => v
};
// C1's own POSITION per joint (p1), read straight off the same rig dump as
// the rotations above — Neck (0,-0.5,0), Right Shoulder (-0.5,0.5,0), Left
// Shoulder (0.5,0.5,0), Left Hip (-0.5,1,0). Right Hip's C1 got cut off in
// the capture; mirroring Left Hip across X (0.5,1,0) — everything else
// mirrored cleanly between sides, so this is a reasonable stand-in, not a
// confirmed value.
//
// This matters because pos(x,y,z) isn't just "R * delta" — the exact
// composition (C0*Transform*C1⁻¹) adds a second term, (I - Local.Rotation)
// * p1, that only vanishes when p1 is zero or the rotation is small.
// Checked directly against Left Shoulder's own worst keyframe (a 173.8°
// swing): the dropped term alone was 1.25 studs — bigger than the arm box
// — which lines up with exactly the pose that looked most wrong.
// RootJoint's C0/C1 position is (0,0,0) on both sides (confirmed from the
// rig too) so its p1 term is genuinely zero — unlike the identity-ROTATION
// assumption above, the identity-POSITION assumption for root was right.
const JOINT_C1_POS = {
  neck: [0, -0.5, 0],
  rightArm: [-0.5, 0.5, 0],
  rightLeg: [0.5, 1, 0], // confirmed from the rig
  leftArm: [0.5, 0.5, 0],
  leftLeg: [-0.5, 1, 0],
  root: [0, 0, 0] // confirmed from the rig
};
function jointInfoFor(path) {
  if (/(^|\/)Head$/i.test(path)) return { conv: JOINT_AXIS_MAP.neck, p1: JOINT_C1_POS.neck };
  if (/(^|\/)Right\s?(Arm|UpperArm|LowerArm|Hand)$/i.test(path)) return { conv: JOINT_AXIS_MAP.right, p1: JOINT_C1_POS.rightArm };
  if (/(^|\/)Right\s?(Leg|UpperLeg|LowerLeg|Foot)$/i.test(path)) return { conv: JOINT_AXIS_MAP.right, p1: JOINT_C1_POS.rightLeg };
  if (/(^|\/)Left\s?(Arm|UpperArm|LowerArm|Hand)$/i.test(path)) return { conv: JOINT_AXIS_MAP.left, p1: JOINT_C1_POS.leftArm };
  if (/(^|\/)Left\s?(Leg|UpperLeg|LowerLeg|Foot)$/i.test(path)) return { conv: JOINT_AXIS_MAP.left, p1: JOINT_C1_POS.leftLeg };
  return { conv: JOINT_AXIS_MAP.neck, p1: JOINT_C1_POS.root }; // Torso / LowerTorso / UpperTorso / root — same rotation as Neck, confirmed from the rig
}
function jointConvFor(path) { return jointInfoFor(path).conv; }

function buildTracks(parsed) {
  const tracks = {};
  if (!parsed) return tracks;
  parsed.keyframes.forEach(kf => {
    kf.poses.forEach(po => {
      if (po.idle) return;
      const conv = jointConvFor(po.path);
      (tracks[po.path] ||= []).push({
        t: Number(kf.t), angle: Number(po.angle),
        axis: conv(po.axis.map(Number)),
        pos: conv(po.pos ? po.pos.map(Number) : [0, 0, 0])
      });
    });
  });
  Object.keys(tracks).forEach(p => tracks[p].sort((a, b) => a.t - b.t));
  return tracks;
}

function sampleTrack(track, tm) {
  if (!track || !track.length) return null;
  if (track.length === 1) return { q: axisAngleToQuat(track[0].angle, track[0].axis), pos: track[0].pos };
  let lo = track[0], hi = track[track.length - 1];
  for (let i = 0; i < track.length - 1; i++) {
    if (tm >= track[i].t - 1e-6 && tm <= track[i + 1].t + 1e-6) { lo = track[i]; hi = track[i + 1]; break; }
  }
  if (tm <= lo.t) return { q: axisAngleToQuat(lo.angle, lo.axis), pos: lo.pos };
  if (tm >= hi.t) return { q: axisAngleToQuat(hi.angle, hi.axis), pos: hi.pos };
  const f = (tm - lo.t) / (hi.t - lo.t);
  const q = slerpQuat(axisAngleToQuat(lo.angle, lo.axis), axisAngleToQuat(hi.angle, hi.axis), f);
  const pos = [0, 1, 2].map(i => lo.pos[i] + (hi.pos[i] - lo.pos[i]) * f);
  return { q, pos };
}

const preview = {
  inited: false, pendingRebuild: false,
  scene: null, camera: null, renderer: null, rigGroup: null,
  joints: {}, tracks: {}, duration: 0, playing: false, time: 0, lastFrame: 0,
  // Roblox forward is -Z. theta=-0.7 (the old default) parked the camera on
  // the +Z side, i.e. looking at the rig's BACK — from there, a swing that's
  // actually front-to-back projects mostly onto the screen's left-right axis,
  // which is exactly the "maju-mundur keliatan kanan-kiri" symptom. Math.PI-0.7
  // mirrors the same 3/4 elevated angle onto the -Z (front) side instead, so
  // depth motion reads as depth. Drag still orbits freely either way.
  cam: { theta: Math.PI - 0.7, phi: 1.15, dist: 9 }
};

const _c1PosCache = {};
function applyPoseToRig() {
  Object.keys(preview.joints).forEach(path => {
    if (path === 'HumanoidRootPart') return;
    const info = preview.joints[path];
    const sample = sampleTrack(preview.tracks[path], preview.time);
    if (sample) {
      info.pivot.quaternion.set(sample.q.x, sample.q.y, sample.q.z, sample.q.w);
      // Exact position term: rest + R*pt (already baked into sample.pos by
      // buildTracks) + (I - Local.Rotation) * C1.Position — see JOINT_C1_POS
      // above for why that second part can't be dropped once the rotation
      // is large.
      const p1 = _c1PosCache[path] || (_c1PosCache[path] = jointInfoFor(path).p1);
      let extraX = 0, extraY = 0, extraZ = 0;
      if (p1[0] || p1[1] || p1[2]) {
        const p1v = new THREE.Vector3(p1[0], p1[1], p1[2]);
        const rotated = p1v.clone().applyQuaternion(info.pivot.quaternion);
        extraX = p1v.x - rotated.x; extraY = p1v.y - rotated.y; extraZ = p1v.z - rotated.z;
      }
      const ms = preview.modelScale || 1; // keyframe offsets are in studs; the holder's scale would multiply them
      info.pivot.position.set(
        info.rest.x + (sample.pos[0] + extraX) / ms,
        info.rest.y + (sample.pos[1] + extraY) / ms,
        info.rest.z + (sample.pos[2] + extraZ) / ms
      );
    } else {
      info.pivot.quaternion.identity();
      info.pivot.position.copy(info.rest);
    }
  });
}

function updatePrevTimeLabel() {
  $('prevTime').textContent = preview.time.toFixed(2) + ' / ' + preview.duration.toFixed(2) + 's';
}

function updatePreviewCamera() {
  const { theta, phi, dist } = preview.cam;
  const tx = 0, ty = 3, tz = 0;
  preview.camera.position.set(
    tx + dist * Math.sin(phi) * Math.sin(theta),
    ty + dist * Math.cos(phi),
    tz + dist * Math.sin(phi) * Math.cos(theta)
  );
  preview.camera.lookAt(tx, ty, tz);
}

function resizePreview() {
  if (!preview.inited) return;
  const stage = $('prevStage');
  const w = stage.clientWidth, h = stage.clientHeight;
  if (!w || !h) return;
  preview.camera.aspect = w / h;
  preview.camera.updateProjectionMatrix();
  preview.renderer.setSize(w, h);
}

const BUILD = 1; // shown in the status line so a stale cached page is obvious

// Builds the same { pivot, rest, path } joint map buildRig() produces, but
// from a loaded .glb scene — so applyPoseToRig() (which only touches
// .pivot.quaternion/.position and .rest) doesn't care where the rig came from.
// Finding a node by name (ModelLoader.findNode) is not the same as it
// being in the right place in the scene graph. Rotating "Torso" only
// carries "Left Arm" along with it if Left Arm's Object3D is actually a
// CHILD of Torso's in three.js's own parent/child tree — and a model
// exported by someone else (Sketchfab etc.) has approximately zero chance
// of already matching Roblox's exact Torso -> Left Arm -> ... chain. Most
// often everything sits as siblings under one root/armature node instead,
// so setting Torso's rotation visibly spins Torso in place while every
// other part just sits there — exactly the "rotates but doesn't move"
// symptom this was built to fix.
//
// Fix: re-parent each found node under its RIG_SPECS parent using
// THREE.Object3D.attach(), which reparents while preserving the object's
// current WORLD position/rotation/scale (unlike .add(), which would keep
// its old LOCAL transform and jump to a new world position/orientation
// under the new parent). That gives our conceptual hierarchy real teeth in
// the actual scene graph, while every part stays exactly where it visually
// was at load time — .rest is then recorded fresh in that new parent's
// local space, which is what applyPoseToRig's rest+offset math needs.
function buildJointsFromGLB(rootObj, glbScene, type) {
  const spec = RIG_SPECS[type] || RIG_SPECS.r6;
  const nameMap = (typeof ModelLoader !== 'undefined' && ModelLoader.BONE_NAME_MAP[type]) || {};
  const joints = { HumanoidRootPart: { pivot: rootObj, rest: new THREE.Vector3(0, 0, 0), path: 'HumanoidRootPart' } };
  const pathByName = {};
  const missing = [];
  spec.forEach(node => {
    const parentPath = node.parent ? pathByName[node.parent] : 'HumanoidRootPart';
    const path = parentPath + '/' + node.name;
    pathByName[node.name] = path;
    const glbName = nameMap[node.name] || node.name;
    const obj = ModelLoader.findNode(glbScene, glbName);
    if (!obj) { missing.push(node.name); return; }
    const parentObj = joints[parentPath] ? joints[parentPath].pivot : rootObj;
    if (obj.parent !== parentObj) parentObj.attach(obj); // reparent, preserving world transform
    joints[path] = { pivot: obj, rest: obj.position.clone(), path };
  });
  return { joints, missing, total: spec.length };
}

// Models from elsewhere (Sketchfab etc.) rarely come stud-sized or standing
// on the origin — a 1.8-unit-tall model would be a speck and a 180-unit one
// would swallow the camera. Scale to ~5 studs tall (an R6/R15 character) only
// when it's clearly off, and stand it on the grid. A model that's already
// stud-sized (like the Blender rigs) is left exactly as-is.
function fitModelToStage(model) {
  model.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(model);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const TARGET_H = 5;
  let s = 1;
  if (isFinite(size.y) && size.y > 1e-6 && Math.abs(size.y - TARGET_H) / TARGET_H > 0.25) s = TARGET_H / size.y;
  const holder = new THREE.Group();
  holder.scale.setScalar(s);
  holder.position.set(-center.x * s, -box.min.y * s, -center.z * s);
  holder.add(model);
  return { holder, scale: s };
}

// Status is shown ON THE PAGE (#prevModelStatus), not just the console —
// the console isn't always reachable (e.g. testing on a phone).
function setModelStatus(text, ok) {
  // Status line under the preview was removed from the UI; keep it in the console for debugging.
  console.info(`[forge build ${BUILD}] ` + text);
}
function setModelNodes(names) {
  const wrap = $('prevModelNodesWrap'), pre = $('prevModelNodes');
  if (!wrap || !pre) return;
  if (!names || !names.length) { wrap.style.display = 'none'; return; }
  const shown = names.slice(0, 250);
  pre.textContent = shown.join('\n') + (names.length > shown.length ? `\n… +${names.length - shown.length} more` : '');
  wrap.querySelector('summary').textContent = `Node names inside the model (${names.length})`;
  wrap.style.display = '';
}

async function rebuildPreviewRig() {
  if (!preview.inited) return;
  const currentType = () => ($('rigType').value === 'auto' ? detectRigType(state.parsed) : $('rigType').value);
  const type = currentType();
  // Debug escape hatch only: add ?box=1 to the URL to see the old box rig.
  // Normal use is 100% from assets/*.glb — nothing is drawn if it can't load.
  const useBoxRig = /[?&]box=1\b/.test(location.search);
  $('r15Wip').hidden = !(type === 'r15' && !useBoxRig);

  let group = new THREE.Group();
  let joints = {};
  preview.modelScale = 1;
  setModelNodes(null);

  if (type === 'r15' && !useBoxRig) {
    // R15 is WIP: nothing to load, nothing to configure — just say so.
    setModelStatus(t('rigWipNote'), null);
  } else if (useBoxRig) {
    const built = buildRig(type);
    group = built.group;
    joints = built.joints;
    setModelStatus('debug box rig (?box=1) — NOT using any .glb', false);
  } else {
    const glbUrl = `assets/${type.toUpperCase()}.glb`;
    setModelStatus(`loading ${glbUrl}…`, null);
    const res = (typeof ModelLoader !== 'undefined')
      ? await ModelLoader.loadWithStatus(glbUrl)
      : { model: null, status: 'model-loader.js not loaded (check <script> order in index.html)' };
    if (type !== currentType()) return; // rig type changed mid-load; the newer rebuild handles it

    if (res.model) {
      const fitted = fitModelToStage(res.model);
      group.add(fitted.holder);
      preview.modelScale = fitted.scale;
      const built = buildJointsFromGLB(fitted.holder, res.model, type);
      joints = built.joints;
      setModelNodes(ModelLoader.listNodeNames(res.model));
      const scaleNote = fitted.scale === 1 ? '' : ` · auto-scaled ×${fitted.scale.toFixed(3)}`;
      // Matched-or-not is still shown (green/red), but without naming
      // individual parts or singling it out as a "warning" — just a plain
      // count.
      if (built.missing.length) {
        console.warn(`[model-loader] parts not found in ${glbUrl}:`, built.missing);
        setModelStatus(`loaded ${glbUrl} ✓ (${built.total - built.missing.length}/${built.total} parts matched)${scaleNote}`, false);
      } else {
        setModelStatus(`loaded ${glbUrl} ✓ all ${built.total} parts matched${scaleNote}`, true);
      }
    } else {
      setModelStatus(`could NOT load ${glbUrl} — ${res.status}`, false);
    }
  }

  if (preview.rigGroup) preview.scene.remove(preview.rigGroup);
  preview.scene.add(group);
  preview.rigGroup = group;
  preview.joints = joints;
  const e = state.eff || state.parsed;
  preview.tracks = buildTracks(e);
  const lastT = (e && e.keyframes.length) ? Math.max(...e.keyframes.map(k => Number(k.t))) : 0;
  preview.duration = (e && e.duration) || lastT || 0;
  preview.time = 0;
  setRange();
  $('prevScrub').value = '0';
  applyPoseToRig();
  updatePrevTimeLabel();
}

function updateR15Banner() {
  const ty = $('rigType').value === 'auto' ? detectRigType(state.parsed) : $('rigType').value;
  $('r15Wip').hidden = !(ty === 'r15' && !/[?&]box=1\b/.test(location.search));
}
function previewOnDataChanged() {
  updateR15Banner();
  if (!preview.inited) { preview.pendingRebuild = true; return; }
  rebuildPreviewRig();
}

function setPreviewPlaying(v) {
  preview.playing = v;
  $('prevPlayIcon').innerHTML = v ? '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>';
  $('prevPlay').setAttribute('aria-label', v ? 'Pause' : 'Play');
}

function previewLoop(now) {
  requestAnimationFrame(previewLoop);
  if (!preview.inited) return;
  const dt = preview.lastFrame ? Math.min(0.05, (now - preview.lastFrame) / 1000) : 0;
  preview.lastFrame = now;
  if (preview.playing && preview.duration > 0) {
    preview.time += dt * (preview.speed || 1);
    const lo = preview.rA || 0, hi = preview.rB > lo ? preview.rB : preview.duration;
    if (preview.time > hi) preview.time = lo + (preview.time - hi) % Math.max(hi - lo, 0.001);
    else if (preview.time < lo) preview.time = lo;
    applyPoseToRig();
    updatePrevTimeLabel();
    $('prevScrub').value = String(Math.round((preview.time / preview.duration) * 1000));
  }
  preview.renderer.render(preview.scene, preview.camera);
}

function initPreviewScene() {
  if (preview.inited) return;
  const stage = $('prevStage');
  const w = stage.clientWidth, h = stage.clientHeight;
  if (!w || !h) return;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 100);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(w, h);
  stage.appendChild(renderer.domElement);

  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const dir = new THREE.DirectionalLight(0xffffff, 0.9);
  dir.position.set(4, 8, 5);
  scene.add(dir);
  scene.add(new THREE.GridHelper(20, 20, 0x333344, 0x1c1c24));

  preview.scene = scene; preview.camera = camera; preview.renderer = renderer;
  preview.inited = true;
  updatePreviewCamera();

  let dragging = false, lastX = 0, lastY = 0;
  stage.addEventListener('pointerdown', e => { dragging = true; lastX = e.clientX; lastY = e.clientY; stage.setPointerCapture(e.pointerId); });
  stage.addEventListener('pointerup', () => { dragging = false; });
  stage.addEventListener('pointercancel', () => { dragging = false; });
  stage.addEventListener('pointermove', e => {
    if (!dragging) return;
    const dx = e.clientX - lastX, dy = e.clientY - lastY;
    lastX = e.clientX; lastY = e.clientY;
    preview.cam.theta -= dx * 0.008;
    preview.cam.phi = Math.min(2.6, Math.max(0.3, preview.cam.phi - dy * 0.008));
    updatePreviewCamera();
  });
  stage.addEventListener('wheel', e => {
    e.preventDefault();
    preview.cam.dist = Math.min(24, Math.max(3, preview.cam.dist + e.deltaY * 0.01));
    updatePreviewCamera();
  }, { passive: false });

  if (preview.pendingRebuild) { preview.pendingRebuild = false; rebuildPreviewRig(); }
  requestAnimationFrame(previewLoop);
}

function watchPreviewStage() {
  const stage = $('prevStage');
  if (!('ResizeObserver' in window)) { initPreviewScene(); return; }
  new ResizeObserver(entries => {
    const { width, height } = entries[0].contentRect;
    if (width > 0 && height > 0) {
      if (!preview.inited) initPreviewScene(); else resizePreview();
    }
  }).observe(stage);
}

$('prevPlay').addEventListener('click', () => setPreviewPlaying(!preview.playing));
$('prevScrub').addEventListener('input', () => {
  setPreviewPlaying(false);
  const frac = Number($('prevScrub').value) / 1000;
  preview.time = preview.duration > 0 ? frac * preview.duration : 0;
  applyPoseToRig();
  updatePrevTimeLabel();
});
$('rigType').addEventListener('change', () => {
  updateR15Banner();
  if (preview.inited) rebuildPreviewRig(); else preview.pendingRebuild = true;
});
// The visible rig picker is a button group now; it just drives the hidden
// <select> so every existing rebuildPreviewRig()/detectRigType() call keeps
// working unchanged.
$('rigSwitch').querySelectorAll('.rig-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    $('rigSwitch').querySelectorAll('.rig-btn').forEach(b => b.classList.toggle('active', b === btn));
    $('rigType').value = btn.dataset.rig;
    $('rigType').dispatchEvent(new Event('change'));
  });
});

/* ---------- SAMPLE + EVENTS ---------- */
const SAMPLE = `== SampleWalk ==
Duration: 0.67s | Keyframes: 22
Loop: true

[Keyframe 1] t=0.00s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.6° axis(0.65, 0.01, 0.76)
  HumanoidRootPart/Torso/Left Arm: rot 55.8° axis(-0.06, 0.04, -1.00)  pos(x=-0.29, y=-0.04, z=0.02)
  HumanoidRootPart/Torso/Left Leg: rot 59.4° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.13, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 45.0° axis(-0.03, -0.09, -1.00)  pos(x=-0.20, y=0.07, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 45.3° axis(0.02, 0.05, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 2] t=0.03s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.6° axis(0.66, 0.01, 0.75)
  HumanoidRootPart/Torso/Left Arm: rot 53.6° axis(-0.06, 0.04, -1.00)  pos(x=-0.27, y=-0.05, z=0.02)
  HumanoidRootPart/Torso/Left Leg: rot 65.7° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.14, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 40.5° axis(-0.04, -0.09, -0.99)  pos(x=-0.19, y=0.07, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 42.9° axis(0.02, 0.05, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 3] t=0.07s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.6° axis(0.67, 0.01, 0.74)
  HumanoidRootPart/Torso/Left Arm: rot 47.6° axis(-0.07, 0.04, -1.00)  pos(x=-0.24, y=-0.06, z=0.02)
  HumanoidRootPart/Torso/Left Leg: rot 65.7° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.17, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 29.1° axis(-0.08, -0.12, -0.99)  pos(x=-0.17, y=0.05, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 36.2° axis(0.02, 0.06, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 4] t=0.10s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.5° axis(0.69, 0.01, 0.72)
  HumanoidRootPart/Torso/Left Arm: rot 39.3° axis(-0.07, 0.04, -1.00)  pos(x=-0.18, y=-0.08, z=0.02)
  HumanoidRootPart/Torso/Left Leg: rot 60.7° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.19, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 14.2° axis(-0.25, -0.19, -0.95)  pos(x=-0.14, y=0.04, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 26.2° axis(0.01, 0.09, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 5] t=0.13s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.4° axis(0.72, 0.01, 0.70)
  HumanoidRootPart/Torso/Left Arm: rot 30.0° axis(-0.09, 0.04, -1.00)  pos(x=-0.13, y=-0.09, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 51.6° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.20, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 5.2° axis(-0.83, -0.32, 0.46)  pos(x=-0.10, y=0.02, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 13.6° axis(0.01, 0.17, 0.99)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 6] t=0.17s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 1.1° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.3° axis(0.74, 0.01, 0.67)
  HumanoidRootPart/Torso/Left Arm: rot 21.0° axis(-0.12, 0.04, -0.99)  pos(x=-0.08, y=-0.10, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 39.8° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.16, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 16.2° axis(-0.29, -0.04, 0.96)  pos(x=-0.06, y=-0.00, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 2.4° axis(-0.07, 0.94, -0.34)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 7] t=0.18s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 1.4° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.2° axis(0.77, 0.01, 0.63)
  HumanoidRootPart/Torso/Left Arm: rot 12.3° axis(-0.20, 0.07, -0.98)  pos(x=-0.04, y=-0.09, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 26.2° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.07, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 25.4° axis(-0.18, -0.00, 0.98)  pos(x=-0.02, y=-0.02, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 16.0° axis(-0.03, 0.14, -0.99)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 8] t=0.22s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 1.7° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.2° axis(0.80, 0.02, 0.60)
  HumanoidRootPart/Torso/Left Arm: rot 3.0° axis(-0.72, 0.32, -0.62)  pos(x=0.01, y=-0.05, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 12.0° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=0.01, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 34.8° axis(-0.12, 0.02, 0.99)  pos(x=0.01, y=-0.04, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 30.9° axis(-0.02, 0.07, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 9] t=0.25s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 2.0° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.1° axis(0.83, 0.02, 0.56)
  HumanoidRootPart/Torso/Left Arm: rot 8.7° axis(-0.21, 0.12, 0.97)  pos(x=0.04, y=0.01, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 1.6° axis(0.03, -0.03, -1.00)  pos(x=-0.03, y=0.04, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 43.7° axis(-0.08, 0.03, 1.00)  pos(x=0.04, y=-0.06, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 44.9° axis(-0.02, 0.05, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 10] t=0.28s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 2.2° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.0° axis(0.85, 0.02, 0.53)
  HumanoidRootPart/Torso/Left Arm: rot 17.5° axis(-0.09, 0.07, 0.99)  pos(x=0.07, y=0.05, z=0.00)
  HumanoidRootPart/Torso/Left Leg: rot 16.3° axis(0.00, -0.00, -1.00)  pos(x=-0.03, y=-0.02, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 51.7° axis(-0.06, 0.03, 1.00)  pos(x=0.06, y=-0.08, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 57.1° axis(-0.02, 0.03, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 11] t=0.32s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 2.3° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.0° axis(0.86, 0.02, 0.52)
  HumanoidRootPart/Torso/Left Arm: rot 24.3° axis(-0.07, 0.07, 1.00)  pos(x=0.08, y=0.09, z=0.00)
  HumanoidRootPart/Torso/Left Leg: rot 30.9° axis(0.00, -0.00, -1.00)  pos(x=-0.03, y=-0.10, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 58.0° axis(-0.04, 0.03, 1.00)  pos(x=0.08, y=-0.09, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 66.6° axis(-0.02, 0.03, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 12] t=0.35s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 2.3° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.0° axis(0.86, 0.02, 0.52)
  HumanoidRootPart/Torso/Left Arm: rot 28.7° axis(-0.06, 0.11, 0.99)  pos(x=0.08, y=0.12, z=0.00)
  HumanoidRootPart/Torso/Left Leg: rot 41.6° axis(0.00, -0.00, -1.00)  pos(x=-0.03, y=-0.20, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 61.9° axis(-0.02, 0.03, 1.00)  pos(x=0.09, y=-0.10, z=0.03)
  HumanoidRootPart/Torso/Right Leg: rot 72.6° axis(-0.02, 0.03, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 13] t=0.38s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 2.2° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.0° axis(0.85, 0.02, 0.53)
  HumanoidRootPart/Torso/Left Arm: rot 29.9° axis(-0.08, 0.13, 0.99)  pos(x=0.08, y=0.13, z=0.00)
  HumanoidRootPart/Torso/Left Leg: rot 44.7° axis(0.00, -0.00, -1.00)  pos(x=-0.03, y=-0.23, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 62.9° axis(-0.02, 0.02, 1.00)  pos(x=0.09, y=-0.10, z=0.03)
  HumanoidRootPart/Torso/Right Leg: rot 73.9° axis(-0.02, 0.02, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 14] t=0.42s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 2.0° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.1° axis(0.83, 0.02, 0.56)
  HumanoidRootPart/Torso/Left Arm: rot 26.1° axis(-0.13, 0.15, 0.98)  pos(x=0.06, y=0.11, z=0.00)
  HumanoidRootPart/Torso/Left Leg: rot 40.9° axis(0.00, -0.00, -1.00)  pos(x=-0.03, y=-0.20, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 58.1° axis(-0.01, 0.02, 1.00)  pos(x=0.07, y=-0.10, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 65.2° axis(-0.02, 0.03, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 15] t=0.45s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 1.7° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.2° axis(0.80, 0.02, 0.60)
  HumanoidRootPart/Torso/Left Arm: rot 18.2° axis(-0.27, 0.21, 0.94)  pos(x=0.03, y=0.09, z=0.00)
  HumanoidRootPart/Torso/Left Leg: rot 32.5° axis(0.00, -0.00, -1.00)  pos(x=-0.03, y=-0.14, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 47.6° axis(-0.01, 0.01, 1.00)  pos(x=0.05, y=-0.08, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 47.0° axis(-0.02, 0.04, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 16] t=0.48s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 1.4° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.2° axis(0.77, 0.01, 0.63)
  HumanoidRootPart/Torso/Left Arm: rot 9.4° axis(-0.68, 0.35, 0.65)  pos(x=-0.01, y=0.05, z=0.00)
  HumanoidRootPart/Torso/Left Leg: rot 19.7° axis(0.00, -0.00, -1.00)  pos(x=-0.03, y=-0.06, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 33.1° axis(-0.02, -0.00, 1.00)  pos(x=0.01, y=-0.05, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 23.9° axis(-0.03, 0.09, -1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 17] t=0.50s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: rot 1.1° axis(0.00, 0.00, -1.00)
  HumanoidRootPart/Torso/Head: rot 2.3° axis(0.74, 0.01, 0.67)
  HumanoidRootPart/Torso/Left Arm: rot 9.7° axis(-0.77, 0.26, -0.58)  pos(x=-0.06, y=0.02, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 1.4° axis(0.03, -0.03, -1.00)  pos(x=-0.03, y=0.06, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 16.2° axis(-0.04, -0.05, 1.00)  pos(x=-0.04, y=-0.03, z=0.02)
  HumanoidRootPart/Torso/Right Leg: rot 2.3° axis(-0.07, 1.00, 0.06)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 18] t=0.53s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.4° axis(0.72, 0.01, 0.70)
  HumanoidRootPart/Torso/Left Arm: rot 18.3° axis(-0.44, 0.09, -0.89)  pos(x=-0.11, y=-0.01, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 15.6° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=0.12, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 2.2° axis(-0.38, -0.70, -0.60)  pos(x=-0.08, y=0.00, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 20.6° axis(0.01, 0.11, 0.99)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 19] t=0.57s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.5° axis(0.69, 0.01, 0.72)
  HumanoidRootPart/Torso/Left Arm: rot 28.5° axis(-0.26, 0.04, -0.96)  pos(x=-0.16, y=-0.02, z=0.01)
  HumanoidRootPart/Torso/Left Leg: rot 28.2° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=0.08, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 18.0° axis(-0.05, -0.13, -0.99)  pos(x=-0.13, y=0.03, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 32.8° axis(0.01, 0.07, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 20] t=0.60s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.6° axis(0.67, 0.01, 0.74)
  HumanoidRootPart/Torso/Left Arm: rot 40.9° axis(-0.14, 0.03, -0.99)  pos(x=-0.22, y=-0.03, z=0.02)
  HumanoidRootPart/Torso/Left Leg: rot 39.5° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.00, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 31.9° axis(-0.03, -0.10, -0.99)  pos(x=-0.16, y=0.05, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 39.0° axis(0.02, 0.06, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 21] t=0.63s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.6° axis(0.66, 0.01, 0.75)
  HumanoidRootPart/Torso/Left Arm: rot 51.4° axis(-0.08, 0.04, -1.00)  pos(x=-0.27, y=-0.04, z=0.02)
  HumanoidRootPart/Torso/Left Leg: rot 49.8° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.09, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 41.5° axis(-0.03, -0.09, -1.00)  pos(x=-0.19, y=0.07, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 43.5° axis(0.02, 0.05, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)

[Keyframe 22] t=0.67s (Keyframe)
  HumanoidRootPart: idle
  HumanoidRootPart/Torso: idle
  HumanoidRootPart/Torso/Head: rot 2.6° axis(0.65, 0.01, 0.76)
  HumanoidRootPart/Torso/Left Arm: rot 55.8° axis(-0.06, 0.04, -1.00)  pos(x=-0.29, y=-0.04, z=0.02)
  HumanoidRootPart/Torso/Left Leg: rot 59.4° axis(0.00, -0.00, 1.00)  pos(x=-0.03, y=-0.13, z=-0.01)
  HumanoidRootPart/Torso/Right Arm: rot 45.0° axis(-0.03, -0.09, -1.00)  pos(x=-0.20, y=0.07, z=0.01)
  HumanoidRootPart/Torso/Right Leg: rot 45.3° axis(0.02, 0.05, 1.00)  pos(x=0.01, y=-0.20, z=-0.01)`;

$('go').addEventListener('click', () => run(true));
$('raw').addEventListener('paste', () => setTimeout(() => run(false), 0));
$('sample').addEventListener('click', () => { $('raw').value = SAMPLE; run(false); });
$('clear').addEventListener('click', () => {
  $('raw').value = ''; state.parsed = null; state.warns = []; state.err = null;
  state.nameDirty = false; state.loopDirty = false;
  $('seqName').value = ''; $('loop').checked = false;
  clearOutput(); renderStatus(); updatePathPreview(); previewOnDataChanged();
});
$('service').addEventListener('change', refresh);
$('seqName').addEventListener('input', () => { state.nameDirty = $('seqName').value !== ''; refresh(); });
$('priority').addEventListener('change', regen);
$('loop').addEventListener('change', () => { state.loopDirty = true; regen(); });
$('addFolder').addEventListener('click', () => {
  state.folders.push(''); renderFolders(); updatePathPreview();
  const ins = $('folders').querySelectorAll('input'); if (ins.length) ins[ins.length - 1].focus();
});
$('copy').addEventListener('click', copyOut);
document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => setTab(b.dataset.go)));

$('langBtn').addEventListener('click', e => { e.stopPropagation(); togglePop(); });
document.addEventListener('click', e => { if (!e.target.closest('.lang-wrap')) closePop(); });
$('settingsBtn').addEventListener('click', openSetup);
$('done').addEventListener('click', closeSetup);
$('modal').addEventListener('click', e => { if (e.target === $('modal')) closeSetup(); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeDD(); closePop(); if (!$('modal').hidden) closeSetup(); }
});

/* ---------- CUSTOM DROPDOWNS ---------- */
const CHEV = '<svg class="dd-chev" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>';
function closeDD() { document.querySelectorAll('.dd.open').forEach(d => { d.classList.remove('open'); d.querySelector('.dd-menu').hidden = true; d.querySelector('.dd-btn').setAttribute('aria-expanded', 'false'); }); }
function enhanceSelect(sel, render) {
  sel.classList.add('visually-hidden'); sel.tabIndex = -1; sel.setAttribute('aria-hidden', 'true');
  const wrap = document.createElement('div'); wrap.className = 'dd';
  const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'dd-btn'; btn.setAttribute('aria-haspopup', 'listbox'); btn.setAttribute('aria-expanded', 'false');
  const menu = document.createElement('div'); menu.className = 'dd-menu'; menu.setAttribute('role', 'listbox'); menu.hidden = true;
  sel.before(wrap); wrap.append(btn, menu, sel);
  const vals = [...sel.options].map(o => o.value || o.text);
  const pick = v => { sel.value = v; sel.dispatchEvent(new Event('change')); paint(); };
  function paint() {
    btn.innerHTML = '<span class="dd-it">' + render(sel.value) + '</span>' + CHEV;
    menu.replaceChildren();
    vals.forEach(v => {
      const o = document.createElement('button'); o.type = 'button'; o.className = 'dd-opt'; o.setAttribute('role', 'option');
      o.setAttribute('aria-selected', v === sel.value ? 'true' : 'false');
      o.innerHTML = '<span class="dd-it">' + render(v) + '</span><span class="dd-ck">✓</span>';
      o.addEventListener('click', () => { pick(v); closeDD(); btn.focus(); });
      menu.appendChild(o);
    });
  }
  btn.addEventListener('click', e => {
    e.stopPropagation(); const willOpen = menu.hidden; closeDD();
    if (willOpen) { menu.hidden = false; wrap.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); const s = menu.querySelector('[aria-selected="true"]'); if (s) s.scrollIntoView({ block: 'nearest' }); }
  });
  btn.addEventListener('keydown', e => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    e.preventDefault(); const i = vals.indexOf(sel.value) + (e.key === 'ArrowDown' ? 1 : -1);
    if (i >= 0 && i < vals.length) pick(vals[i]);
  });
  paint();
}
const PRI_LEVEL = { Idle: 1, Movement: 2, Action: 3, Action2: 4, Action3: 5, Action4: 6, Core: 7 };
enhanceSelect($('service'), v => '<span class="ti ti-svc">' + (SVC_ICONS[v] || '') + '</span><span>' + v + '</span>');
enhanceSelect($('priority'), v => { let b = ''; for (let i = 1; i <= 7; i++) b += '<i style="--k:' + i + '"' + (i <= (PRI_LEVEL[v] || 0) ? ' class="on"' : '') + '></i>'; return '<span class="pri">' + b + '</span><span>' + v + '</span>'; });
document.addEventListener('click', e => { if (!e.target.closest('.dd')) closeDD(); });

/* ---------- LANGUAGE SEARCH / EXPAND / NAME RESET ---------- */
const EXP_ON = '<svg viewBox="0 0 24 24"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>';
const EXP_OFF = '<svg viewBox="0 0 24 24"><path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/></svg>';
$('langExpand').innerHTML = EXP_ON;
$('langExpand').addEventListener('click', e => { e.stopPropagation(); const big = $('langPop').classList.toggle('big'); $('langExpand').innerHTML = big ? EXP_OFF : EXP_ON; });
$('langSearch').addEventListener('input', () => fillLangList($('langList'), $('langSearch').value));
$('setupLangSearch').addEventListener('input', () => fillLangList($('setupLangList'), $('setupLangSearch').value));
$('seqReset').addEventListener('click', () => { state.nameDirty = false; $('seqName').value = (state.parsed && state.parsed.name) || ''; refresh(); });

/* ---------- ANIMATION TWEAKS (applied to the generated script AND the preview) ---------- */
const neg = s => (/^-?0(\.0+)?$/.test(s) ? s : (s[0] === '-' ? s.slice(1) : '-' + s));
const swapLR = p => p.replace(/Left|Right/g, x => (x === 'Left' ? 'Right' : 'Left'));
const nearPose = (a, b) => a.length === b.length && a.every((x, i) => {
  const y = b[i]; if (!y || x.path !== y.path || !!x.idle !== !!y.idle) return false;
  if (x.idle) return true;
  const px = x.pos || [0, 0, 0], py = y.pos || [0, 0, 0];
  return Math.abs(x.angle - y.angle) < 0.3 && x.axis.every((v, j) => Math.abs(v - y.axis[j]) < 0.02) && px.every((v, j) => Math.abs(v - py[j]) < 0.005);
});
function effective(p, s) {
  const q = JSON.parse(JSON.stringify(p));
  const ex = new Set(s.exclude);
  q.keyframes.forEach(kf => {
    kf.poses = kf.poses.filter(po => !ex.has(po.path.split('/').pop()));
    // Mirror across the body's left/right plane: swap Left/Right and reflect axis (x,-y,-z) and offset (-x,y,z)
    if (s.mirror) kf.poses.forEach(po => {
      po.path = swapLR(po.path);
      if (!po.idle) { po.axis = [po.axis[0], neg(po.axis[1]), neg(po.axis[2])]; if (po.pos) po.pos = [neg(po.pos[0]), po.pos[1], po.pos[2]]; }
    });
  });
  const k = q.keyframes;
  if (s.seamless && k.length > 1) k[k.length - 1].poses = JSON.parse(JSON.stringify(k[0].poses));
  if (s.dedupe && k.length > 2) {
    const out = [k[0]];
    for (let i = 1; i < k.length - 1; i++) if (!(nearPose(k[i].poses, out[out.length - 1].poses) && nearPose(k[i].poses, k[i + 1].poses))) out.push(k[i]);
    out.push(k[k.length - 1]); q.keyframes = out;
  }
  if (s.speed !== 1) {
    q.keyframes.forEach(kf => { kf.t = String(round4(Number(kf.t) / s.speed)); });
    if (q.duration != null) q.duration = round4(q.duration / s.speed);
  }
  return q;
}
function buildParts() {
  const names = new Set();
  state.parsed.keyframes.forEach(kf => kf.poses.forEach(po => { const n = po.path.split('/').pop(); if (n !== 'HumanoidRootPart') names.add(n); }));
  const box = $('parts'); box.replaceChildren();
  names.forEach(n => {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'part-chip'; b.textContent = n;
    b.setAttribute('aria-pressed', state.exclude.has(n) ? 'false' : 'true');
    b.addEventListener('click', () => { state.exclude.has(n) ? state.exclude.delete(n) : state.exclude.add(n); b.setAttribute('aria-pressed', state.exclude.has(n) ? 'false' : 'true'); optChange(); });
    box.appendChild(b);
  });
}
state.exclude = new Set();
function kfTimes() { const e = state.eff || state.parsed; return e ? e.keyframes.map(k => Number(k.t)).sort((a, b) => a - b) : []; }
function setRange() {
  const ts = kfTimes(), n = ts.length;
  $('rngA').max = $('rngB').max = String(n || 1);
  let a = Math.max(1, Math.min(n || 1, parseInt($('rngA').value) || 1)), b = Math.max(1, Math.min(n || 1, parseInt($('rngB').value) || n || 1));
  if (b > n || b <= a) b = n || 1;
  if (a >= b) a = 1;
  $('rngA').value = a; $('rngB').value = b;
  const full = a === 1 && b === n;
  preview.rA = full ? 0 : ts[a - 1]; preview.rB = full ? 0 : ts[b - 1];
}
function syncPreviewData() {
  if (!preview.inited || !preview.rigGroup) return;
  const e = state.eff || state.parsed;
  preview.tracks = buildTracks(e);
  const lastT = (e && e.keyframes.length) ? Math.max(...e.keyframes.map(k => Number(k.t))) : 0;
  preview.duration = (e && e.duration) || lastT || 0;
  preview.time = Math.min(preview.time, preview.duration);
  setRange(); applyPoseToRig(); updatePrevTimeLabel();
}
function optChange() { regen(); syncPreviewData(); }
['fxMirror', 'fxSeamless', 'fxDedupe'].forEach(id => $(id).addEventListener('change', optChange));
$('fxSpeed').addEventListener('input', optChange);
['rngA', 'rngB'].forEach(id => $(id).addEventListener('change', () => { setRange(); preview.time = preview.rA || 0; applyPoseToRig(); updatePrevTimeLabel(); }));
const SPEEDS = [1, 0.5, 0.25, 2];
$('prevSpeed').addEventListener('click', () => {
  const i = (SPEEDS.indexOf(preview.speed || 1) + 1) % SPEEDS.length;
  preview.speed = SPEEDS[i]; $('prevSpeed').textContent = preview.speed + '×';
});
function stepKf(dir) {
  const ts = kfTimes(); if (!ts.length) return;
  setPreviewPlaying(false);
  const cur = preview.time, EPS = 0.001;
  preview.time = dir > 0 ? (ts.find(x => x > cur + EPS) ?? ts[0]) : ([...ts].reverse().find(x => x < cur - EPS) ?? ts[ts.length - 1]);
  applyPoseToRig(); updatePrevTimeLabel();
  $('prevScrub').value = String(Math.round((preview.time / (preview.duration || 1)) * 1000));
}
$('prevBack').addEventListener('click', () => stepKf(-1));
$('prevFwd').addEventListener('click', () => stepKf(1));

/* ---------- DOWNLOAD .lua ---------- */
$('dl').addEventListener('click', () => {
  const v = $('out').value; if (!v) return;
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([v], { type: 'text/plain' }));
  a.download = (getSettings().name || 'Animation').replace(/[^\w\-. ]+/g, '_') + '.lua';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});

/* ---------- HISTORY (animations only: raw + generated script; stored in this browser) ---------- */
const HK = 'kff.hist', HMAX = 100, HAGE = 30 * 864e5;
const hload = () => { try { return JSON.parse(localStorage.getItem(HK)) || []; } catch (_) { return []; } };
function hsave(list) { for (;;) { try { localStorage.setItem(HK, JSON.stringify(list)); return true; } catch (_) { if (list.length <= 1) return false; list.pop(); } } }
const canZ = typeof CompressionStream === 'function' && typeof DecompressionStream === 'function';
async function zipStr(str) {
  const buf = new Uint8Array(await new Response(new Blob([str]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
  let b = ''; for (let i = 0; i < buf.length; i += 8192) b += String.fromCharCode.apply(null, buf.subarray(i, i + 8192));
  return btoa(b);
}
async function unzipStr(b64) {
  const bin = atob(b64), u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
}
function histAdd() {
  if (!state.parsed) return;
  const name = getSettings().name;
  const list = hload().filter(e => e.name !== name);
  list.unshift({ id: Date.now().toString(36), name, ts: Date.now(), kf: state.parsed.keyframes.length, raw: $('raw').value, out: $('out').value });
  hsave(list.slice(0, HMAX));
}
async function histSweep() {
  if (!canZ) return;
  const list = hload(); let ch = false;
  for (const e of list) if (!e.z && Date.now() - e.ts > HAGE) { e.z = await zipStr(JSON.stringify({ raw: e.raw, out: e.out })); delete e.raw; delete e.out; ch = true; }
  if (ch) hsave(list);
}
async function histOpen(id, copyOnly) {
  const list = hload(), e = list.find(x => x.id === id); if (!e) return;
  try {
    let d = e;
    if (e.z) { d = JSON.parse(await unzipStr(e.z)); e.raw = d.raw; e.out = d.out; delete e.z; e.ts = Date.now(); hsave(list); }
    if (copyOnly) { await navigator.clipboard.writeText(d.out); toast(t('copied')); return; }
    closeHist(); $('raw').value = d.raw; state.nameDirty = false; run(false);
    if (d.out) { $('out').value = d.out; updateLines(); $('copy').disabled = false; $('dl').disabled = false; }
    toast(t('histOpened')); if (isMobile()) setTab('output');
  } catch (_) { toast('Error'); }
}
function histRender() {
  const q = norm($('histSearch').value).trim(), box = $('histList'); box.replaceChildren();
  const list = hload().filter(e => !q || norm(e.name).includes(q));
  if (!list.length) { const d = document.createElement('div'); d.className = 'lang-empty'; d.textContent = t('histEmpty'); box.appendChild(d); return; }
  list.forEach(e => {
    const r = document.createElement('div'); r.className = 'h-item';
    const info = document.createElement('div'); info.className = 'h-info';
    const n = document.createElement('b'); n.textContent = e.name;
    const s = document.createElement('small'); s.textContent = new Date(e.ts).toLocaleDateString(ui.lang) + ' · ' + t('histKf', { n: e.kf }) + (e.z ? ' · ' + t('histCompressed') : '');
    info.append(n, s);
    const acts = document.createElement('div'); acts.className = 'h-acts';
    const mk = (label, cls, fn) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'hb ' + cls; b.textContent = label; b.addEventListener('click', fn); acts.appendChild(b); };
    mk(t('histOpen'), 'primary', () => histOpen(e.id));
    if (!e.z) mk(t('copy'), '', () => histOpen(e.id, true));
    mk(t('histDelete'), 'danger', () => { hsave(hload().filter(x => x.id !== e.id)); histRender(); });
    r.append(info, acts); box.appendChild(r);
  });
}
function closeHist() { $('histModal').hidden = true; document.body.style.overflow = ''; }
$('histBtn').addEventListener('click', () => { closePop(); $('histSearch').value = ''; histRender(); $('histModal').hidden = false; document.body.style.overflow = 'hidden'; });
$('histClose').addEventListener('click', closeHist);
$('histModal').addEventListener('click', e => { if (e.target === $('histModal')) closeHist(); });
$('histSearch').addEventListener('input', histRender);
$('histClear').addEventListener('click', () => { if (confirm(t('histConfirm'))) { hsave([]); histRender(); } });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeHist(); });
histSweep();

/* ---------- INIT ---------- */
document.querySelectorAll('[data-ver]').forEach(el => { el.textContent = 'v' + APP_VERSION; });
buildThemes();
applyTheme();
applyLang();
updatePathPreview();
watchPreviewStage();
})();
